package xiroc.dungeonsall.dungeon;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.QuartPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.structure.Structure.GenerationContext;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.generator.DefaultDungeonGenerator;
import xiroc.dungeonsall.dungeon.generator.DungeonGenerator;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.piece.DungeonEntrance;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.Position2D;

public class DungeonBuilder {
    public static final DungeonGenerator DEFAULT_GENERATOR = new DefaultDungeonGenerator();
    public Position2D start;
    public DungeonLayer[] layers;
    public BlockPos groundPos;
    public BlockPos startPos;
    public GenerationContext generationContext;
    public Biome biome;
    public Theme theme;
    public Theme catacombsTheme;
    public Theme lowerCatacombsTheme;
    public Theme bottomTheme;
    public SecondaryTheme secondaryTheme;
    public SecondaryTheme catacombsSecondaryTheme;
    public SecondaryTheme lowerCatacombsSecondaryTheme;
    public SecondaryTheme bottomSecondaryTheme;
    private static final int GRID_SIZE = 17;
    private static final int HALF_GRID_SIZE = 8;

    public DungeonBuilder(GenerationContext generationContext, int startHeight, BlockPos groundPos) {
        this.generationContext = generationContext;
        this.groundPos = groundPos;
        this.startPos = new BlockPos(generationContext.chunkPos().x() * 16 - 72 - 4, startHeight, generationContext.chunkPos().z() * 16 - 72 - 4);
        DungeonsAll.LOGGER.debug("Creating a dungeon at (" + this.startPos.getX() + " | " + this.startPos.getY() + " | " + this.startPos.getZ() + ").");
    }

    public List<DungeonPiece> build() {
        if (this.startPos.getY() < 16) {
            return Lists.newArrayList();
        }

        this.biome = (Biome)xiroc.dungeonsall.compat.Compat26.noiseBiome(
                this.generationContext.chunkGenerator().getBiomeSource(),
                QuartPos.fromBlock(this.groundPos.getX()),
                QuartPos.fromBlock(this.groundPos.getY()),
                QuartPos.fromBlock(this.groundPos.getZ()),
                this.generationContext.randomState()
            )
            .value();
        DungeonType type = DungeonType.randomType(
            this.generationContext.registryAccess().lookupOrThrow(Registries.BIOME).getKey(this.biome), this.generationContext.random()
        );
        this.generateLayout(type, DEFAULT_GENERATOR);
        List<DungeonPiece> pieces = Lists.newArrayList();
        DungeonPiece entrance = new DungeonEntrance();
        entrance.setWorldPosition(
            this.startPos.getX() + this.layers[0].start.x * 9, this.startPos.getY() + 9, this.startPos.getZ() + this.layers[0].start.z * 9
        );
        entrance.stage = 0;
        entrance.model = type.entrances().roll(this.generationContext.random());
        entrance.createBoundingBox();
        this.determineThemes();
        entrance.theme = this.theme;
        entrance.secondaryTheme = this.secondaryTheme;
        pieces.add(entrance);
        this.postProcessDungeon(pieces, type, this.generationContext.random());
        return pieces;
    }

    private void generateLayout(DungeonType type, DungeonGenerator generator) {
        generator.initializeDungeon(type, this, this.generationContext.chunkPos(), this.generationContext.random());
        this.start = new Position2D(8, 8);
        int layerCount = generator.layerCount(this.generationContext.random(), this.startPos.getY() - this.generationContext.chunkGenerator().getMinY());
        this.layers = new DungeonLayer[layerCount];

        for (int layer = 0; layer < this.layers.length; layer++) {
            this.layers[layer] = new DungeonLayer(17);
        }

        for (int layer = 0; layer < this.layers.length && (layer <= 0 || this.layers[layer - 1].end != null); layer++) {
            generator.initializeLayer(type.getLayer(layer).settings(), this, this.generationContext.random(), layer, layer == layerCount - 1);
            generator.generateLayer(this, this.layers[layer], layer, this.generationContext.random(), layer == 0 ? this.start : this.layers[layer - 1].end);
        }

        for (int layer = 0; layer < this.layers.length; layer++) {
            this.processCorridors(this.layers[layer], layer);
        }
    }

    private void processCorridors(DungeonLayer layer, int lyr) {
        int stage = Math.min(lyr, 4);

        for (int x = 0; x < layer.width; x++) {
            for (int z = 0; z < layer.length; z++) {
                if (layer.grid[x][z] != null && !layer.grid[x][z].hasFlag(Tile.Flag.PLACEHOLDER)) {
                    layer.grid[x][z].piece.stage = stage;
                    if (layer.grid[x][z].piece.getDungeonPieceType() == 0) {
                        DungeonFeatures.processCorridor(this, layer, x, z, this.generationContext.random(), lyr, stage, this.startPos);
                    }
                }
            }
        }
    }

    private void determineThemes() {
        Identifier registryName = this.generationContext.registryAccess().lookupOrThrow(Registries.BIOME).getKey(this.biome);
        if (registryName != null) {
            if (this.theme == null) {
                this.theme = Theme.randomTheme(registryName.toString(), this.generationContext.random());
            }
        } else if (this.theme == null) {
            this.theme = Theme.getBuiltinDefaultTheme();
        }

        if (this.secondaryTheme == null) {
            if (this.theme.secondaryTheme != null) {
                this.secondaryTheme = this.theme.secondaryTheme.roll(this.generationContext.random());
            } else {
                this.secondaryTheme = registryName != null
                    ? Theme.randomSecondaryTheme(registryName.toString(), this.generationContext.random())
                    : Theme.getBuiltinDefaultSecondaryTheme();
            }
        }

        if (this.catacombsTheme == null) {
            this.catacombsTheme = Theme.randomCatacombsTheme(this.generationContext.random());
        }

        if (this.catacombsSecondaryTheme == null) {
            if (this.catacombsTheme.secondaryTheme != null) {
                this.catacombsSecondaryTheme = this.catacombsTheme.secondaryTheme.roll(this.generationContext.random());
            } else {
                this.catacombsSecondaryTheme = Theme.randomCatacombsSecondaryTheme(this.generationContext.random());
            }
        }

        if (this.lowerCatacombsTheme == null) {
            this.lowerCatacombsTheme = Theme.randomLowerCatacombsTheme(this.generationContext.random());
        }

        if (this.lowerCatacombsSecondaryTheme == null) {
            if (this.lowerCatacombsTheme.secondaryTheme != null) {
                this.lowerCatacombsSecondaryTheme = this.lowerCatacombsTheme.secondaryTheme.roll(this.generationContext.random());
            } else {
                this.lowerCatacombsSecondaryTheme = Theme.randomLowerCatacombsSecondaryTheme(this.generationContext.random());
            }
        }

        if (this.bottomTheme == null) {
            this.bottomTheme = Config.NO_NETHER_STUFF.get() ? Theme.getTheme(Theme.PRIMARY_HELL_MOSSY) : Theme.randomHellTheme(this.generationContext.random());
        }

        if (this.bottomTheme.secondaryTheme != null && this.bottomSecondaryTheme == null) {
            this.bottomSecondaryTheme = this.bottomTheme.secondaryTheme.roll(this.generationContext.random());
        } else {
            this.bottomSecondaryTheme = Theme.randomHellSecondaryTheme(this.generationContext.random());
        }
    }

    private void postProcessDungeon(List<DungeonPiece> pieces, DungeonType type, RandomSource rand) {
        for (int i = 0; i < this.layers.length; i++) {
            DungeonLayer layer = this.layers[i];
            ModelSelector modelSelector = type.getLayer(i).modelSelector();

            for (int x = 0; x < layer.width; x++) {
                for (int z = 0; z < layer.length; z++) {
                    Tile tile = layer.grid[x][z];
                    if (tile != null && !tile.hasFlag(Tile.Flag.PLACEHOLDER)) {
                        switch (i) {
                            case 2:
                                tile.piece.theme = this.catacombsTheme;
                                tile.piece.secondaryTheme = this.catacombsSecondaryTheme;
                                break;
                            case 3:
                                tile.piece.theme = this.lowerCatacombsTheme;
                                tile.piece.secondaryTheme = this.lowerCatacombsSecondaryTheme;
                                break;
                            default:
                                if (i >= 4) {
                                    tile.piece.theme = this.bottomTheme;
                                    tile.piece.secondaryTheme = this.bottomSecondaryTheme;
                                } else {
                                    tile.piece.theme = this.theme;
                                    tile.piece.secondaryTheme = this.secondaryTheme;
                                }
                        }

                        if (!tile.hasFlag(Tile.Flag.FIXED_MODEL)) {
                            tile.piece.setupModel(this, modelSelector, pieces, rand);
                        }

                        if (!tile.hasFlag(Tile.Flag.FIXED_POSITION)) {
                            tile.piece.setWorldPosition(this.startPos.getX() + x * 9, this.startPos.getY() - i * 9, this.startPos.getZ() + z * 9);
                        }

                        tile.piece.createBoundingBox();
                        if (tile.piece.getDungeonPieceType() == 10) {
                            layer.rotateNode(tile, rand);
                        }

                        if (tile.piece.hasChildPieces()) {
                            tile.piece.addChildPieces(pieces, this, type, modelSelector, i, rand);
                        }

                        tile.piece.setup(rand);
                        pieces.add(tile.piece);
                    }
                }
            }
        }
    }

    public static boolean isBlockProtected(LevelAccessor world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        return state.getDestroySpeed(world, pos) < 0.0F;
    }
}
