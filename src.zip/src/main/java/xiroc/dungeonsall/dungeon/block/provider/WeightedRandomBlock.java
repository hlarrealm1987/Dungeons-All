package xiroc.dungeonsall.dungeon.block.provider;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.WeightedRandom;

public class WeightedRandomBlock implements BlockStateProvider {
    protected static final String TYPE = "random_block";
    private final WeightedRandom<BlockState> randomBlockState;

    public WeightedRandomBlock(WeightedRandom<BlockState> randomBlockState) {
        this.randomBlockState = randomBlockState;
    }

    @Override
    public BlockState get(LevelAccessor world, BlockPos pos, RandomSource random, Rotation rotation) {
        return this.randomBlockState.roll(random);
    }

    @Override
    public JsonObject serialize() {
        JsonObject object = new JsonObject();
        object.addProperty("type", "random_block");
        JsonArray blocks = new JsonArray();
        this.randomBlockState.getEntries().forEach(entry -> {
            JsonObject block = JSONUtils.serializeBlockState(new JsonObject(), (BlockState)entry.left());
            block.addProperty("weight", (Number)entry.right());
            blocks.add(block);
        });
        object.add("blocks", blocks);
        return object;
    }

    public static WeightedRandomBlock.Builder builder() {
        return new WeightedRandomBlock.Builder();
    }

    public static class Builder {
        private WeightedRandom.Builder<BlockState> builder = new WeightedRandom.Builder<>();

        public WeightedRandomBlock.Builder add(Block block) {
            return this.add(block.defaultBlockState(), 1);
        }

        public WeightedRandomBlock.Builder add(Block block, int weight) {
            return this.add(block.defaultBlockState(), weight);
        }

        public WeightedRandomBlock.Builder add(BlockState state) {
            return this.add(state, 1);
        }

        public WeightedRandomBlock.Builder add(BlockState state, int weight) {
            this.builder.add(state, weight);
            return this;
        }

        public WeightedRandomBlock build() {
            return new WeightedRandomBlock(this.builder.build());
        }
    }
}
