package xiroc.dungeonsall.dungeon.block;

import com.google.common.collect.ImmutableSet;
import java.util.Optional;
import java.util.Set;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ProblemReporter;
import net.minecraft.util.RandomSource;
import net.minecraft.util.random.WeightedList;
import net.minecraft.util.random.WeightedList.Builder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EntityEquipment;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.SpawnData;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.TagValueOutput;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.monster.RandomEquipment;
import xiroc.dungeonsall.dungeon.monster.RandomMonster;
import xiroc.dungeonsall.dungeon.monster.RandomPotionEffect;
import xiroc.dungeonsall.dungeon.monster.SpawnRates;
import xiroc.dungeonsall.dungeon.treasure.RandomItems;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.IBlockPlacementHandler;
import xiroc.dungeonsall.util.Range;

public class Spawner implements IBlockPlacementHandler {
    public static final Set<EntityType<?>> RANGED_INVENTORY_ENTITIES = ImmutableSet.builder()
        .add(EntityTypes.SKELETON)
        .add(EntityTypes.STRAY)
        .add(EntityTypes.BOGGED)
        .build();
    public static final Set<EntityType<?>> INVENTORY_ENTITIES = ImmutableSet.builder()
        .add(EntityTypes.ZOMBIE)
        .add(EntityTypes.HUSK)
        .add(EntityTypes.WITHER_SKELETON)
        .addAll(RANGED_INVENTORY_ENTITIES)
        .build();

    @Override
    public void place(LevelAccessor world, BlockState state, BlockPos pos, RandomSource rand, Theme theme, SecondaryTheme secondaryTheme, int stage) {
        world.setBlock(pos, Blocks.SPAWNER.defaultBlockState(), 2);
        if (world.getBlockEntity(pos) instanceof SpawnerBlockEntity spawner) {
            EntityType<?> type = RandomMonster.randomMonster(rand, stage);
            spawner.getSpawner().setEntityId(type, null, rand, pos);
            if ((Boolean)Config.CUSTOM_SPAWNERS.get() && INVENTORY_ENTITIES.contains(type)) {
                TagValueOutput spawnerNBTOutput = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, world.registryAccess());
                spawner.getSpawner().save(spawnerNBTOutput);
                Builder<SpawnData> spawnPotentials = WeightedList.builder();

                for (int i = 0; i < Config.SPAWNER_ENTITIES.get(); i++) {
                    SpawnData entity = createSpawnData(type, rand, stage, world.registryAccess());
                    spawnPotentials.add(entity);
                    if (i == 0) {
                        spawnerNBTOutput.store("SpawnData", SpawnData.CODEC, entity);
                    }
                }

                spawnerNBTOutput.store("SpawnPotentials", SpawnData.LIST_CODEC, spawnPotentials.build());
                Range delay = SpawnRates.getDelay(stage);
                spawnerNBTOutput.putShort("MinSpawnDelay", (short)delay.min());
                spawnerNBTOutput.putShort("MaxSpawnDelay", (short)delay.max());
                spawnerNBTOutput.putShort("SpawnCount", (short)SpawnRates.getAmount(stage).nextInt(rand));
                spawnerNBTOutput.putShort("RequiredPlayerRange", ((Integer)Config.SPAWNER_RANGE.get()).shortValue());
                spawner.getSpawner()
                    .load(spawner.getLevel(), pos, TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), spawnerNBTOutput.buildResult()));
            }
        } else {
            DungeonsAll.LOGGER.error("Failed to fetch a mob spawner at ({}, {}, {})", pos.getX(), pos.getY(), pos.getZ());
        }
    }

    public static SpawnData createSpawnData(@Nullable EntityType<?> type, RandomSource rand, int stage, RegistryAccess registryAccess) {
        if (type == null) {
            type = RandomMonster.randomMonster(rand, stage);
        }

        Identifier registryName = BuiltInRegistries.ENTITY_TYPE.getKey(type);
        TagValueOutput nbt = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, registryAccess);
        nbt.putString("id", registryName.toString());
        if (INVENTORY_ENTITIES.contains(type)) {
            EntityEquipment equipment = new EntityEquipment();
            RandomEquipment.createArmor(equipment, rand, stage, registryAccess);
            ItemStack mainHand = RANGED_INVENTORY_ENTITIES.contains(type)
                ? RandomEquipment.getRangedWeapon(rand, stage, registryAccess)
                : RandomEquipment.getMeleeWeapon(rand, stage, registryAccess);
            equipment.set(EquipmentSlot.MAINHAND, mainHand);
            if (rand.nextDouble() < 0.25) {
                equipment.set(EquipmentSlot.OFFHAND, RandomItems.createShield(rand, stage, registryAccess));
            }

            nbt.store("equipment", EntityEquipment.CODEC, equipment);
            if (!(Boolean)Config.NATURAL_DESPAWN.get()) {
                nbt.putBoolean("PersistenceRequired", true);
            }

            RandomPotionEffect.createPotionEffects(nbt.list("active_effects", MobEffectInstance.CODEC), rand, stage);
        }

        if ((Boolean)Config.OVERWRITE_ENTITY_LOOT_TABLES.get() && RandomMonster.NBT_PATCHERS.containsKey(type)) {
            ((RandomMonster.MobNBTPatcher)RandomMonster.NBT_PATCHERS.get(type)).patch(nbt, rand, stage);
        }

        return new SpawnData(nbt.buildResult(), Optional.empty(), Optional.empty());
    }
}
