package xiroc.dungeonsall.dungeon.block.provider.pattern;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;

public record CheckerboardPattern(BlockStateProvider block1, BlockStateProvider block2) implements BlockStateProvider {
    public static final String TYPE = "pattern";
    public static final String PATTERN_TYPE = "checkerboard_pattern";

    @Override
    public BlockState get(LevelAccessor world, BlockPos pos, RandomSource random, Rotation rotation) {
        return (pos.getX() & 1 ^ pos.getZ() & 1) == 1 ? this.block1.get(world, pos, random, rotation) : this.block2.get(world, pos, random, rotation);
    }

    @Override
    public JsonObject serialize() {
        JsonObject object = new JsonObject();
        object.addProperty("type", "pattern");
        object.addProperty("pattern_type", "checkerboard_pattern");
        object.add("block_1", this.block1.serialize());
        object.add("block_2", this.block2.serialize());
        return object;
    }
}
