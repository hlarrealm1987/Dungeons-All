package xiroc.dungeonsall.dungeon.block;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import xiroc.dungeonsall.util.WeightedRandom;

public class DungeonBlocks {
    public static final Block[] CARPET = new Block[]{
        (Block)Blocks.CARPET.orange(),
        (Block)Blocks.CARPET.magenta(),
        (Block)Blocks.CARPET.lightBlue(),
        (Block)Blocks.CARPET.yellow(),
        (Block)Blocks.CARPET.lime(),
        (Block)Blocks.CARPET.pink(),
        (Block)Blocks.CARPET.cyan(),
        (Block)Blocks.CARPET.blue(),
        (Block)Blocks.CARPET.purple(),
        (Block)Blocks.CARPET.green(),
        (Block)Blocks.CARPET.brown(),
        (Block)Blocks.CARPET.red()
    };
    public static final WeightedRandom<Block> CROPS = new WeightedRandom.Builder<Block>()
        .add(Blocks.POTATOES, 2)
        .add(Blocks.WHEAT, 2)
        .add(Blocks.CARROTS, 1)
        .add(Blocks.BEETROOTS, 1)
        .build();
    public static final WeightedRandom<Block> POTTED_FLOWERS = new WeightedRandom.Builder<Block>()
        .add(Blocks.POTTED_ACACIA_SAPLING, 1)
        .add(Blocks.POTTED_ALLIUM, 1)
        .add(Blocks.POTTED_AZALEA, 1)
        .add(Blocks.POTTED_AZURE_BLUET, 1)
        .add(Blocks.POTTED_BAMBOO, 1)
        .add(Blocks.POTTED_BIRCH_SAPLING, 1)
        .add(Blocks.POTTED_BLUE_ORCHID, 1)
        .add(Blocks.POTTED_BROWN_MUSHROOM, 1)
        .add(Blocks.POTTED_CACTUS, 1)
        .add(Blocks.POTTED_CORNFLOWER, 1)
        .add(Blocks.POTTED_CHERRY_SAPLING, 1)
        .add(Blocks.POTTED_DANDELION, 1)
        .add(Blocks.POTTED_DARK_OAK_SAPLING, 1)
        .add(Blocks.POTTED_DEAD_BUSH, 1)
        .add(Blocks.POTTED_FERN, 1)
        .add(Blocks.POTTED_JUNGLE_SAPLING, 1)
        .add(Blocks.POTTED_LILY_OF_THE_VALLEY, 1)
        .add(Blocks.POTTED_OAK_SAPLING, 1)
        .add(Blocks.POTTED_ORANGE_TULIP, 1)
        .add(Blocks.POTTED_OXEYE_DAISY, 1)
        .add(Blocks.POTTED_POPPY, 1)
        .add(Blocks.POTTED_PINK_TULIP, 1)
        .add(Blocks.POTTED_RED_MUSHROOM, 1)
        .add(Blocks.POTTED_RED_TULIP, 1)
        .add(Blocks.POTTED_SPRUCE_SAPLING, 1)
        .add(Blocks.POTTED_WHITE_TULIP, 1)
        .build();
    public static final WeightedRandom<Block> TALL_FLOWERS = new WeightedRandom.Builder<Block>()
        .add(Blocks.ROSE_BUSH, 1)
        .add(Blocks.LILAC, 1)
        .add(Blocks.PEONY, 1)
        .build();
    public static final BlockState SPAWNER = Blocks.SPAWNER.defaultBlockState();
    public static final BlockState CHEST = Blocks.CHEST.defaultBlockState();
    public static final BlockState CAVE_AIR = Blocks.CAVE_AIR.defaultBlockState();

    public static <T extends Comparable<T>, V extends T> BlockState applyProperty(BlockState state, Property<T> property, V value) {
        return state.hasProperty(property) ? (BlockState)state.setValue(property, value) : state;
    }
}
