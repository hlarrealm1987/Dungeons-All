package xiroc.dungeonsall.dungeon.block.provider;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

public interface BlockStateProvider {
    default BlockState get(LevelAccessor world, BlockPos pos, RandomSource random) {
        return this.get(world, pos, random, Rotation.NONE);
    }

    BlockState get(LevelAccessor var1, BlockPos var2, RandomSource var3, Rotation var4);

    JsonObject serialize();
}
