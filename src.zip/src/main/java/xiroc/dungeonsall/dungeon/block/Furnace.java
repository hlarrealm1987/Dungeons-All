package xiroc.dungeonsall.dungeon.block;

import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.FurnaceBlockEntity;
import net.minecraft.world.level.block.entity.SmokerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.IBlockPlacementHandler;

public class Furnace implements IBlockPlacementHandler {
    private static final Item[] FOOD = new Item[]{
        Items.COOKED_BEEF,
        Items.COOKED_CHICKEN,
        Items.COOKED_MUTTON,
        Items.COOKED_COD,
        Items.COOKED_PORKCHOP,
        Items.COOKED_RABBIT,
        Items.COOKED_SALMON,
        Items.BAKED_POTATO
    };

    @Override
    public void place(LevelAccessor world, BlockState state, BlockPos pos, RandomSource rand, Theme theme, SecondaryTheme secondaryTheme, int lootLevel) {
        world.setBlock(pos, state, 2);
        if (world.getBlockEntity(pos) instanceof FurnaceBlockEntity furnace) {
            furnace.setItem(1, new ItemStack(Items.COAL, coalAmount(rand)));
        } else {
            DungeonsAll.LOGGER.warn("Failed to fetch a furnace entity at {}", pos.toString());
        }
    }

    private static int coalAmount(RandomSource rand) {
        return Mth.nextInt(rand, 2, 8);
    }

    public static class Smoker implements IBlockPlacementHandler {
        @Override
        public void place(LevelAccessor world, BlockState state, BlockPos pos, RandomSource rand, Theme theme, SecondaryTheme secondaryTheme, int lootLevel) {
            world.setBlock(pos, state, 2);
            if (world.getBlockEntity(pos) instanceof SmokerBlockEntity smoker) {
                smoker.setItem(1, new ItemStack(Items.CHARCOAL, Furnace.coalAmount(rand)));
                smoker.setItem(2, new ItemStack(Furnace.FOOD[rand.nextInt(Furnace.FOOD.length)], 1 + rand.nextInt(16)));
            } else {
                DungeonsAll.LOGGER.warn("Failed to fetch a smoker entity at {}", pos.toString());
            }
        }
    }
}
