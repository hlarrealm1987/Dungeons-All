package xiroc.dungeonsall.dungeon;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Rotation;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.generator.layer.SideRoomData;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.piece.DungeonCorridor;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.dungeon.piece.room.DungeonNodeRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSecretRoom;
import xiroc.dungeonsall.util.Orientation;
import xiroc.dungeonsall.util.Position2D;

public class DungeonLayer {
    public final Tile[][] grid;
    public Position2D start;
    public Position2D end;
    public int width;
    public int length;
    public List<Position2D> distantNodes;
    public DungeonLayerMap map;

    public DungeonLayer(int size) {
        this(size, size);
    }

    public DungeonLayer(int width, int length) {
        this.width = width;
        this.length = length;
        this.grid = new Tile[this.width][this.length];
        this.distantNodes = Lists.newArrayList();
        this.map = new DungeonLayerMap(width, length);
    }

    public boolean isTileFree(Position2D pos) {
        return this.grid[pos.x][pos.z] == null && this.map.isPositionFree(pos.x, pos.z);
    }

    public boolean isTileFree(int x, int z) {
        return this.grid[x][z] == null && this.map.isPositionFree(x, z);
    }

    public int distance(Position2D a, Position2D b) {
        return Math.abs(a.x - b.x) + Math.abs(a.z - b.z);
    }

    public boolean canPlaceNode(Position2D center) {
        for (int x = -1; x < 2; x++) {
            for (int z = -1; z < 2; z++) {
                Position2D currentPos = new Position2D(center.x + x, center.z + z);
                if (x == 0 && z == 0) {
                    if (!currentPos.isValid(this.width, this.length)) {
                        return false;
                    }

                    if (!this.isTileFree(currentPos)) {
                        return false;
                    }
                } else if (currentPos.isValid(this.width, this.length) && !this.isTileFree(currentPos)) {
                    return false;
                }
            }
        }

        return true;
    }

    public SideRoomData findStarterRoomData(Position2D start, RandomSource rand) {
        int index = rand.nextInt(4);

        for (int i = 0; i < 4; i++) {
            index = (index + i) % 4;

            for (int j = 0; j < 2; j++) {
                Position2D current = start.shift(Orientation.HORIZONTAL_FACINGS[index], j + 1);
                if (current.isValid(this.width, this.length)
                    && this.grid[current.x][current.z] != null
                    && this.grid[current.x][current.z].piece.getDungeonPieceType() == 0
                    && this.grid[current.x][current.z].piece.connectedSides < 4) {
                    SideRoomData data = this.findSideRoomData(new Position2D(current.x, current.z), rand);
                    if (data != null) {
                        return data;
                    }
                }
            }
        }

        return null;
    }

    public SideRoomData findSideRoomData(Position2D base, RandomSource rand) {
        Position2D north = base.shift(Direction.NORTH, 1);
        Position2D east = base.shift(Direction.EAST, 1);
        Position2D south = base.shift(Direction.SOUTH, 1);
        Position2D west = base.shift(Direction.WEST, 1);
        if (rand.nextBoolean()) {
            if (north.isValid(this.width, this.length) && this.isTileFree(north)) {
                return new SideRoomData(north, Rotation.COUNTERCLOCKWISE_90);
            }

            if (east.isValid(this.width, this.length) && this.isTileFree(east)) {
                return new SideRoomData(east, Rotation.NONE);
            }

            if (south.isValid(this.width, this.length) && this.isTileFree(south)) {
                return new SideRoomData(south, Rotation.CLOCKWISE_90);
            }

            if (west.isValid(this.width, this.length) && this.isTileFree(west)) {
                return new SideRoomData(west, Rotation.CLOCKWISE_180);
            }
        } else {
            if (west.isValid(this.width, this.length) && this.isTileFree(west)) {
                return new SideRoomData(west, Rotation.CLOCKWISE_180);
            }

            if (south.isValid(this.width, this.length) && this.isTileFree(south)) {
                return new SideRoomData(south, Rotation.CLOCKWISE_90);
            }

            if (east.isValid(this.width, this.length) && this.isTileFree(east)) {
                return new SideRoomData(east, Rotation.NONE);
            }

            if (north.isValid(this.width, this.length) && this.isTileFree(north)) {
                return new SideRoomData(north, Rotation.COUNTERCLOCKWISE_90);
            }
        }

        return null;
    }

    public void openSideIfPresent(Position2D position, Direction side) {
        if (position.isValid(this.width, this.length) && this.grid[position.x][position.z] != null) {
            this.grid[position.x][position.z].piece.openSide(side);
        }
    }

    public void rotatePiece(Tile placeHolder, RandomSource rand) {
        if (!placeHolder.hasFlag(Tile.Flag.FIXED_ROTATION)) {
            DungeonPiece piece = placeHolder.piece;
            switch (piece.connectedSides) {
                case 1:
                    piece.setRotation(Orientation.getRotationFromFacing(DungeonPiece.getOneWayDirection(piece)));
                    break;
                case 2:
                    if (piece.sides[0] && piece.sides[2]) {
                        piece.setRotation(Orientation.getRotationFromFacing(rand.nextBoolean() ? Direction.NORTH : Direction.SOUTH));
                    } else if (piece.sides[1] && piece.sides[3]) {
                        piece.setRotation(Orientation.getRotationFromFacing(rand.nextBoolean() ? Direction.EAST : Direction.WEST));
                    } else {
                        piece.setRotation(Orientation.getRotationFromCW90DoubleFacing(DungeonPiece.getOpenSide(piece, 0), DungeonPiece.getOpenSide(piece, 1)));
                    }
                    break;
                case 3:
                    piece.setRotation(
                        Orientation.getRotationFromTripleFacing(
                            DungeonPiece.getOpenSide(piece, 0), DungeonPiece.getOpenSide(piece, 1), DungeonPiece.getOpenSide(piece, 2)
                        )
                    );
                    break;
                default:
                    piece.setRotation(Rotation.getRandom(rand));
            }
        }
    }

    public void rotateNode(Tile placeHolder, RandomSource rand) {
        if (!placeHolder.hasFlag(Tile.Flag.FIXED_ROTATION)) {
            DungeonNodeRoom node = (DungeonNodeRoom)placeHolder.piece;
            Rotation randomization = Rotation.getRandom(rand);
            Rotation rotation = Node.ofNodeRoom(node).rotate(randomization).compare(new Node(node.sides[0], node.sides[1], node.sides[2], node.sides[3]), rand);
            if (rotation != null) {
                node.rotation = rotation.getRotated(randomization);
            } else {
                DungeonsAll.LOGGER
                    .error("Could not find a proper node rotation for [{} {} {} {}].", node.sides[0], node.sides[1], node.sides[2], node.sides[3]);
            }
        }
    }

    public boolean placeSecretRoom(DungeonCorridor corridor, Position2D position, RandomSource rand) {
        Direction direction = corridor.rotation != Rotation.NONE && corridor.rotation != Rotation.CLOCKWISE_180
            ? (rand.nextBoolean() ? Direction.EAST : Direction.WEST)
            : (rand.nextBoolean() ? Direction.NORTH : Direction.SOUTH);
        Position2D pos = position.shift(direction, 2);
        if (this.attemptSecretRoomPlacement(corridor, position, direction, pos)) {
            return true;
        }

        direction = direction.getOpposite();
        pos = position.shift(direction, 2);
        return this.attemptSecretRoomPlacement(corridor, position, direction, pos);
    }

    public boolean attemptSecretRoomPlacement(DungeonCorridor corridor, Position2D corridorPos, Direction direction, Position2D outerPosition) {
        if (outerPosition.isValid(this.width, this.length)) {
            Position2D innerPosition = corridorPos.shift(direction, 1);
            if (this.isTileFree(outerPosition) && this.isTileFree(innerPosition)) {
                DungeonSecretRoom room = new DungeonSecretRoom();
                int x = Math.min(outerPosition.x, innerPosition.x);
                int z = Math.min(outerPosition.z, innerPosition.z);
                room.setGridPosition(x, z);
                room.setRotation(Orientation.getRotationFromFacing(direction));
                this.grid[x][z] = new Tile(room);
                Position2D other = getOther(x, z, direction);
                this.grid[other.x][other.z] = new Tile(room).addFlag(Tile.Flag.PLACEHOLDER);
                corridor.rotation = Orientation.getRotationFromFacing(direction).getRotated(Rotation.CLOCKWISE_90);
                corridor.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(DungeonModels.SECRET_ROOM_ENTRANCE);
                this.grid[corridorPos.x][corridorPos.z].addFlag(Tile.Flag.FIXED_MODEL);
                return true;
            }
        }

        return false;
    }

    private static Position2D getOther(int x, int z, Direction direction) {
        return switch (direction) {
            case EAST, WEST -> new Position2D(x + 1, z);
            case SOUTH, NORTH -> new Position2D(x, z + 1);
            default -> throw new UnsupportedOperationException("Can't get other position from direction " + direction);
        };
    }
}
