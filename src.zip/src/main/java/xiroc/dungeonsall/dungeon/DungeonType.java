package xiroc.dungeonsall.dungeon;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.RandomSource;
import net.neoforged.fml.ModList;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.generator.DungeonGeneratorSettings;
import xiroc.dungeonsall.dungeon.generator.layer.LayerGeneratorSettings;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.model.MultipartModelData;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.WeightedRandom;

public record DungeonType(Identifier source, DungeonGeneratorSettings dungeonSettings, DungeonType.Layer[] layers, WeightedRandom<DungeonModel> entrances) {
    private static final Hashtable<Identifier, DungeonType> KEY_TO_TYPE = new Hashtable();
    private static final Hashtable<String, WeightedRandom<DungeonType>> BIOME_TO_TYPE = new Hashtable();
    private static WeightedRandom<DungeonType> DEFAULT_TYPE;
    private static final String TYPES_DIRECTORY = "dungeon/types";
    private static final String MAPPINGS_DIRECTORY = "dungeon/biome_mappings";

    public DungeonType.Layer getLayer(int layer) {
        return this.layers[Math.min(this.layers.length - 1, layer)];
    }

    public static void load(ResourceManager resourceManager) {
        resourceManager.listResources("dungeon/types", path -> path.getPath().endsWith(".json")).forEach((file, resource) -> {
            try {
                DungeonsAll.LOGGER.debug("Loading {}", file);
                JsonObject type = JsonParser.parseReader(new InputStreamReader(resource.open())).getAsJsonObject();
                DungeonType.Builder builder = new DungeonType.Builder(file);
                builder.settings(DungeonGeneratorSettings.fromJson(type.getAsJsonObject("settings"), file));
                builder.entrances(ModelSelector.loadRandom("entrances", type, file));
                JsonArray layers = type.getAsJsonArray("layers");
                if (layers.size() == 0) {
                    throw new DatapackLoadException("Empty layer list in " + file);
                }

                layers.forEach(element -> {
                    JsonObject layer = element.getAsJsonObject();
                    String typeKey = layer.get("type").getAsString();
                    if (!DungeonLayerType.NAME_TO_TYPE.containsKey(typeKey)) {
                        throw new DatapackLoadException("Invalid layer type " + typeKey + " in " + resource);
                    }

                    DungeonLayerType layerType = (DungeonLayerType)DungeonLayerType.NAME_TO_TYPE.get(layer.get("type").getAsString());
                    LayerGeneratorSettings layerSettings = LayerGeneratorSettings.fromJson(layer.getAsJsonObject("settings"), file);
                    ModelSelector modelSelector = ModelSelector.fromJson(layer.getAsJsonObject("models"), file);
                    builder.layer(layerType, layerSettings, modelSelector, getMultipartOverrides(layer, file));
                });
                Identifier key = DungeonsAll.key(file, "dungeon/types", ".json");
                KEY_TO_TYPE.put(key, builder.build());
            } catch (IOException e) {
                DungeonsAll.LOGGER.error("Failed to load dungeon type " + resource);
                e.printStackTrace();
            }
        });
        WeightedRandom.Builder<DungeonType> defaultType = new WeightedRandom.Builder<>();
        resourceManager.listResources("dungeon/biome_mappings", path -> path.getPath().endsWith(".json")).forEach((file, resource) -> {
            try {
                DungeonsAll.LOGGER.debug("Loading {}", file);
                JsonObject rawMapping = JsonParser.parseReader(new InputStreamReader(resource.open())).getAsJsonObject();
                if (rawMapping.has("conditions")) {
                    JsonObject conditions = rawMapping.getAsJsonObject("conditions");
                    if (conditions.has("present")) {
                        for (JsonElement element : conditions.getAsJsonArray("present")) {
                            if (!ModList.get().isLoaded(element.getAsString())) {
                                return;
                            }
                        }
                    }

                    if (conditions.has("absent")) {
                        for (JsonElement element : conditions.getAsJsonArray("absent")) {
                            if (ModList.get().isLoaded(element.getAsString())) {
                                return;
                            }
                        }
                    }
                }

                if (rawMapping.has("default")) {
                    addEntries(defaultType, rawMapping.getAsJsonArray("default"), file);
                }

                JsonObject mapping = rawMapping.getAsJsonObject("mapping");
                mapping.entrySet().forEach(entry -> {
                    String biome = (String)entry.getKey();
                    BIOME_TO_TYPE.put(biome, dungeonTypeWeightedRandom(((JsonElement)entry.getValue()).getAsJsonArray(), file));
                });
            } catch (IOException e) {
                DungeonsAll.LOGGER.error("Failed to load {}", resource);
                e.printStackTrace();
            }
        });
        DEFAULT_TYPE = defaultType.build();
        if (DEFAULT_TYPE.isEmpty()) {
            throw new DatapackLoadException("No default case was specified in the dungeon type biome mappings.");
        }
    }

    private static WeightedRandom<DungeonType> dungeonTypeWeightedRandom(JsonArray entries, Identifier resource) {
        WeightedRandom.Builder<DungeonType> builder = new WeightedRandom.Builder<>();
        addEntries(builder, entries, resource);
        return builder.build();
    }

    private static void addEntries(WeightedRandom.Builder<DungeonType> builder, JsonArray entries, Identifier resource) {
        entries.forEach(element -> {
            JsonObject entry = element.getAsJsonObject();
            Identifier key = Identifier.parse(entry.get("key").getAsString());
            if (!KEY_TO_TYPE.containsKey(key)) {
                throw new DatapackLoadException("Cannot resolve dungeon type " + key + " in " + resource);
            }

            builder.add((DungeonType)KEY_TO_TYPE.get(key), JSONUtils.getWeight(entry));
        });
    }

    public static DungeonType randomType(Identifier biome, RandomSource rand) {
        return biome == null ? DEFAULT_TYPE.roll(rand) : (DungeonType)((WeightedRandom)BIOME_TO_TYPE.getOrDefault(biome.toString(), DEFAULT_TYPE)).roll(rand);
    }

    private static ImmutableMap<Identifier, List<MultipartModelData>> getMultipartOverrides(JsonObject layer, Identifier file) {
        if (layer.has("multipart")) {
            com.google.common.collect.ImmutableMap.Builder<Identifier, List<MultipartModelData>> builder = new com.google.common.collect.ImmutableMap.Builder();
            JsonObject multipart = layer.getAsJsonObject("multipart");
            multipart.entrySet()
                .forEach(
                    entry -> {
                        JsonObject object = ((JsonElement)entry.getValue()).getAsJsonObject();
                        Identifier target = Identifier.parse((String)entry.getKey());
                        if (DungeonModels.KEY_TO_MODEL.containsKey(target)) {
                            String action = object.get("action").getAsString();
                            switch (action) {
                                case "override":
                                    List<MultipartModelData> multipartData = DungeonModel.parseMultipartData(object.getAsJsonObject("data"), file);
                                    if (multipartData != null) {
                                        builder.put(target, multipartData);
                                    }
                                    break;
                                case "add":
                                    HashMap<String, Pair<List<Pair<MultipartModelData.Instance, Integer>>, List<Pair<MultipartModelData.Instance, Integer>>>> additions = new HashMap();
                                    object.getAsJsonObject("additions")
                                        .entrySet()
                                        .forEach(
                                            entry1 -> {
                                                JsonObject object1 = ((JsonElement)entry1.getValue()).getAsJsonObject();
                                                List<Pair<MultipartModelData.Instance, Integer>> models = (List<Pair<MultipartModelData.Instance, Integer>>)(object1.has(
                                                        "models"
                                                    )
                                                    ? MultipartModelData.getRawInstancesFromJson(object1.getAsJsonArray("models"), file)
                                                    : new ArrayList(0));
                                                List<Pair<MultipartModelData.Instance, Integer>> alternatives = (List<Pair<MultipartModelData.Instance, Integer>>)(object1.has(
                                                        "alternatives"
                                                    )
                                                    ? MultipartModelData.getRawInstancesFromJson(object1.getAsJsonArray("alternatives"), file)
                                                    : new ArrayList(0));
                                                additions.put((String)entry1.getKey(), new Pair<>(models, alternatives));
                                            }
                                        );
                                    DungeonModel model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(target);
                                    if (model.hasMultipart()) {
                                        List<MultipartModelData> multipartData = model.getMultipartData();
                                        com.google.common.collect.ImmutableList.Builder<MultipartModelData> newDataBuilder = new com.google.common.collect.ImmutableList.Builder();
                                        multipartData.forEach(
                                            data -> {
                                                if (additions.containsKey(data.name)) {
                                                    Pair<List<Pair<MultipartModelData.Instance, Integer>>, List<Pair<MultipartModelData.Instance, Integer>>> addition = (Pair<List<Pair<MultipartModelData.Instance, Integer>>, List<Pair<MultipartModelData.Instance, Integer>>>)additions.get(
                                                        data.name
                                                    );
                                                    newDataBuilder.add(data.combine(addition.left(), addition.right()));
                                                } else {
                                                    newDataBuilder.add(data);
                                                }
                                            }
                                        );
                                        builder.put(target, newDataBuilder.build());
                                    } else {
                                        DungeonsAll.LOGGER.warn(target + " doesn't have multipart data, but " + file + " adds to it.");
                                    }
                                    break;
                                default:
                                    throw new DatapackLoadException("Unknown multipart action " + action + " in " + file);
                            }
                        } else {
                            throw new DatapackLoadException("Cannot resolve model key " + (String)entry.getKey() + " in " + file);
                        }
                    }
                );
            return builder.build();
        } else {
            return ImmutableMap.of();
        }
    }

    public static class Builder {
        private final Identifier source;
        private final List<DungeonType.Layer> layers;
        private WeightedRandom<DungeonModel> entrances;
        private DungeonGeneratorSettings settings;

        public Builder(Identifier source) {
            this.source = source;
            this.layers = new ArrayList();
        }

        public DungeonType.Builder entrances(WeightedRandom<DungeonModel> entrances) {
            this.entrances = entrances;
            return this;
        }

        public DungeonType.Builder settings(DungeonGeneratorSettings settings) {
            this.settings = settings;
            return this;
        }

        public DungeonType.Builder layer(
            DungeonLayerType type,
            LayerGeneratorSettings settings,
            ModelSelector modelSelector,
            ImmutableMap<Identifier, List<MultipartModelData>> multipartOverrides
        ) {
            this.layers.add(new DungeonType.Layer(type, settings, modelSelector, multipartOverrides));
            return this;
        }

        public DungeonType build() {
            if (this.settings != null && this.layers.size() != 0) {
                return new DungeonType(this.source, this.settings, (DungeonType.Layer[])this.layers.toArray(new DungeonType.Layer[0]), this.entrances);
            } else {
                throw new DatapackLoadException("Incomplete Dungeon Type " + this.source);
            }
        }
    }

    public record Layer(
        DungeonLayerType layerType,
        LayerGeneratorSettings settings,
        ModelSelector modelSelector,
        ImmutableMap<Identifier, List<MultipartModelData>> multipartOverrides
    ) {
        public boolean hasMultipartOverride(DungeonModel model) {
            return this.multipartOverrides.containsKey(model.getKey());
        }

        public List<MultipartModelData> getMultipartData(DungeonModel model) {
            return (List<MultipartModelData>)this.multipartOverrides.getOrDefault(model.getKey(), model.getMultipartData());
        }
    }
}
