package xiroc.dungeonsall.dungeon;

import com.mojang.serialization.MapCodec;
import java.util.Optional;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.QuartPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.levelgen.GenerationStep.Decoration;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.Structure.GenerationContext;
import net.minecraft.world.level.levelgen.structure.Structure.GenerationStub;
import net.minecraft.world.level.levelgen.structure.Structure.StructureSettings;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePiecesBuilder;
import xiroc.dungeonsall.init.ModStructureTypes;

public class Dungeon extends Structure {
    public static final Decoration GENERATION_STEP = Decoration.UNDERGROUND_STRUCTURES;
    public static final MapCodec<Structure> CODEC = simpleCodec(Dungeon::new);
    private static final int BIOME_CHECK_RADIUS = 1;

    public Dungeon(StructureSettings settings) {
        super(settings);
    }

    public Optional<GenerationStub> findGenerationPoint(GenerationContext context) {
        int centerX = context.chunkPos().getBlockX(7);
        int centerZ = context.chunkPos().getBlockZ(7);
        int centerHeight = context.chunkGenerator()
            .getFirstOccupiedHeight(centerX, centerZ, Types.WORLD_SURFACE_WG, context.heightAccessor(), context.randomState());
        if (isInvalidSpot(context, 1)) {
            return Optional.empty();
        }

        int minGroundHeight = minHeight(context, centerX, centerZ, centerHeight);
        int marginToBottom = minGroundHeight - context.heightAccessor().getMinY();
        if (marginToBottom < 45) {
            return Optional.empty();
        }

        int startHeight = minGroundHeight - 24;
        BlockPos position = new BlockPos(centerX, centerHeight, centerZ);
        return Optional.of(new GenerationStub(position, structurePiecesBuilder -> this.generatePieces(structurePiecesBuilder, context, position, startHeight)));
    }

    private void generatePieces(StructurePiecesBuilder structurePiecesBuilder, GenerationContext context, BlockPos position, int startHeight) {
        DungeonBuilder builder = new DungeonBuilder(context, startHeight, position);
        builder.build().forEach(structurePiecesBuilder::addPiece);
    }

    public StructureType<?> type() {
        return ModStructureTypes.dungeon();
    }

    private static boolean isInvalidSpot(GenerationContext context, int radius) {
        for (int x = -radius; x <= radius; x++) {
            for (int z = -radius; z <= radius; z++) {
                ChunkPos pos = new ChunkPos(context.chunkPos().x() + x, context.chunkPos().z() + z);
                int centerX = QuartPos.fromBlock(pos.getBlockX(7));
                int centerZ = QuartPos.fromBlock(pos.getBlockZ(7));
                Holder<Biome> centerBiome = xiroc.dungeonsall.compat.Compat26.noiseBiome(
                        context.chunkGenerator().getBiomeSource(),
                        centerX,
                        context.chunkGenerator()
                            .getFirstOccupiedHeight(centerX, centerZ, Types.WORLD_SURFACE_WG, context.heightAccessor(), context.randomState()),
                        centerZ,
                        context.randomState()
                    );
                if (centerBiome != null && !context.validBiome().test(centerBiome)) {
                    return true;
                }
            }
        }

        return false;
    }

    private static int minHeight(GenerationContext context, int centerX, int centerZ, int centerHeight) {
        int minHeight = centerHeight;

        for (int i = 1; i < 9; i++) {
            int size = i * 5;
            minHeight = Math.min(minHeight, lowestCornerHeight(context, centerX - size, size << 1, centerZ - size, size << 1));
        }

        return minHeight;
    }

    private static int lowestCornerHeight(GenerationContext context, int x, int sizeX, int z, int sizeZ) {
        int height = context.chunkGenerator().getFirstFreeHeight(x, z, Types.OCEAN_FLOOR_WG, context.heightAccessor(), context.randomState());
        height = Math.min(
            height, context.chunkGenerator().getFirstFreeHeight(x + sizeX, z, Types.OCEAN_FLOOR_WG, context.heightAccessor(), context.randomState())
        );
        height = Math.min(
            height, context.chunkGenerator().getFirstFreeHeight(x, z + sizeZ, Types.OCEAN_FLOOR_WG, context.heightAccessor(), context.randomState())
        );
        return Math.min(
            height, context.chunkGenerator().getFirstFreeHeight(x + sizeX, z + sizeZ, Types.OCEAN_FLOOR_WG, context.heightAccessor(), context.randomState())
        );
    }

    public Decoration step() {
        return GENERATION_STEP;
    }
}
