package xiroc.dungeonsall.dungeon.decoration;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModelBlockType;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;

public record FloorDecoration(BlockStateProvider blockStateProvider, float chance) implements DungeonDecoration {
    @Override
    public void decorate(
        DungeonModel model,
        LevelAccessor world,
        BlockPos origin,
        RandomSource random,
        BoundingBox worldGenBounds,
        BoundingBox structureBounds,
        DungeonPiece piece
    ) {
        model.blocks
            .forEach(
                block -> {
                    BlockPos pos = DungeonDecoration.getRotatedBlockPos(
                        block.position.getX(), block.position.getY() + 1, block.position.getZ(), origin, model, piece.rotation
                    );
                    if (block.type == DungeonModelBlockType.FLOOR
                        && block.position.getY() < model.height - 1
                        && worldGenBounds.isInside(pos)
                        && structureBounds.isInside(pos)
                        && !DungeonBuilder.isBlockProtected(world, origin)
                        && world.isEmptyBlock(origin.offset(block.position).above())
                        && checkSolid(world, origin.offset(block.position), worldGenBounds, structureBounds)
                        && random.nextFloat() < this.chance) {
                        world.setBlock(pos, this.blockStateProvider.get(world, pos, random), 2);
                    }
                }
            );
    }

    private static boolean checkSolid(LevelAccessor world, BlockPos pos, BoundingBox worldGenBounds, BoundingBox structureBounds) {
        return worldGenBounds.isInside(pos) && structureBounds.isInside(pos) && world.getBlockState(pos).canOcclude();
    }

    @Override
    public JsonObject serialize() {
        JsonObject object = new JsonObject();
        object.addProperty("type", "floor");
        object.addProperty("chance", this.chance);
        object.add("block", this.blockStateProvider.serialize());
        return object;
    }

    public record NextToSolid(BlockStateProvider blockStateProvider, float chance) implements DungeonDecoration {
        @Override
        public void decorate(
            DungeonModel model,
            LevelAccessor world,
            BlockPos origin,
            RandomSource random,
            BoundingBox worldGenBounds,
            BoundingBox structureBounds,
            DungeonPiece piece
        ) {
            model.blocks
                .forEach(
                    block -> {
                        if (block.type == DungeonModelBlockType.FLOOR && block.position.getY() < model.height - 1) {
                            BlockPos pos = DungeonDecoration.getRotatedBlockPos(
                                block.position.getX(), block.position.getY() + 1, block.position.getZ(), origin, model, piece.rotation
                            );
                            if (worldGenBounds.isInside(pos)
                                && structureBounds.isInside(pos)
                                && world.isEmptyBlock(pos)
                                && world.getBlockState(pos.below()).canOcclude()
                                && !DungeonBuilder.isBlockProtected(world, pos)
                                && (
                                    FloorDecoration.checkSolid(world, pos.north(), worldGenBounds, structureBounds)
                                        || FloorDecoration.checkSolid(world, pos.east(), worldGenBounds, structureBounds)
                                        || FloorDecoration.checkSolid(world, pos.south(), worldGenBounds, structureBounds)
                                        || FloorDecoration.checkSolid(world, pos.west(), worldGenBounds, structureBounds)
                                )
                                && random.nextFloat() < this.chance) {
                                world.setBlock(pos, this.blockStateProvider.get(world, pos, random), 2);
                            }
                        }
                    }
                );
        }

        @Override
        public JsonObject serialize() {
            JsonObject object = new JsonObject();
            object.addProperty("type", "floor_next_to_solid");
            object.addProperty("chance", this.chance);
            object.add("block", this.blockStateProvider.serialize());
            return object;
        }
    }
}
