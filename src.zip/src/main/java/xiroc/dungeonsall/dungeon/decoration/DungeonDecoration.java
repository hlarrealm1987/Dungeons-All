package xiroc.dungeonsall.dungeon.decoration;

import com.google.gson.JsonObject;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.theme.JsonTheming;

public interface DungeonDecoration {
    String VINE_DECORATION = "vines";
    String SCATTERED_DECORATION = "scattered";
    String FLOOR_DECORATION = "floor";
    String FLOOR_NEXT_TO_SOLID_DECORATION = "floor_next_to_solid";

    void decorate(DungeonModel var1, LevelAccessor var2, BlockPos var3, RandomSource var4, BoundingBox var5, BoundingBox var6, DungeonPiece var7);

    JsonObject serialize();

    static DungeonDecoration fromJson(JsonObject object, Identifier file) {
        if (object.has("type")) {
            String type = object.get("type").getAsString().toLowerCase();
            switch (type) {
                case "vines":
                    return new VineDecoration(object.has("chance") ? object.get("chance").getAsFloat() : 0.35F);
                case "scattered":
                    float chancexx = object.has("chance") ? object.get("chance").getAsFloat() : 0.25F;
                    if (!object.has("block")) {
                        DungeonsAll.LOGGER.warn("Missing entry 'block'");
                        return null;
                    } else {
                        BlockStateProvider blockStateProvider = JsonTheming.deserialize(object, "block", file);
                        if (blockStateProvider != null) {
                            return new ScatteredDecoration(blockStateProvider, chancexx);
                        }
                    }
                case "floor":
                    float chancex = object.has("chance") ? object.get("chance").getAsFloat() : 0.5F;
                    if (!object.has("block")) {
                        DungeonsAll.LOGGER.warn("Missing entry 'block'");
                        return null;
                    } else {
                        BlockStateProvider blockStateProvider = JsonTheming.deserialize(object, "block", file);
                        if (blockStateProvider != null) {
                            return new FloorDecoration(blockStateProvider, chancex);
                        }
                    }
                case "floor_next_to_solid":
                    float chance = object.has("chance") ? object.get("chance").getAsFloat() : 0.5F;
                    if (!object.has("block")) {
                        DungeonsAll.LOGGER.warn("Missing entry 'block'");
                        return null;
                    } else {
                        BlockStateProvider blockStateProvider = JsonTheming.deserialize(object, "block", file);
                        if (blockStateProvider != null) {
                            return new FloorDecoration.NextToSolid(blockStateProvider, chance);
                        }
                    }
                default:
                    DungeonsAll.LOGGER.warn("Unknown decoration type '{}'", type);
                    return null;
            }
        } else {
            return null;
        }
    }

    static BlockPos getRotatedBlockPos(int x, int y, int z, BlockPos base, DungeonModel model, Rotation rotation) {
        return switch (rotation) {
            case CLOCKWISE_90 -> new BlockPos(base.getX() + model.length - z - 1, base.getY() + y, base.getZ() + x);
            case CLOCKWISE_180 -> new BlockPos(base.getX() + model.width - x - 1, base.getY() + y, base.getZ() + model.length - z - 1);
            case COUNTERCLOCKWISE_90 -> new BlockPos(base.getX() + z, base.getY() + y, base.getZ() + model.width - x - 1);
            default -> new BlockPos(base.getX() + x, base.getY() + y, base.getZ() + z);
        };
    }
}
