package xiroc.dungeonsall.dungeon.monster;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffect;
import xiroc.dungeonsall.util.IRandom;
import xiroc.dungeonsall.util.Range;

public class WeightedRandomPotionEffect implements IRandom<WeightedRandomPotionEffect.WeightedEntry> {
    public static final WeightedRandomPotionEffect EMPTY = new WeightedRandomPotionEffect(new WeightedRandomPotionEffect.Builder.Entry[0]);
    private final WeightedRandomPotionEffect.WeightedEntry[] entries;

    private WeightedRandomPotionEffect(WeightedRandomPotionEffect.Builder.Entry[] entries) {
        int weight = 0;

        for (WeightedRandomPotionEffect.Builder.Entry entry : entries) {
            weight += entry.weight;
        }

        this.entries = new WeightedRandomPotionEffect.WeightedEntry[entries.length];
        this.assign(entries, weight);
    }

    private void assign(WeightedRandomPotionEffect.Builder.Entry[] entries, int totalWeight) {
        float f = 0.0F;
        int i = 0;

        for (WeightedRandomPotionEffect.Builder.Entry entry : entries) {
            float weight = (float)entry.weight / totalWeight;
            this.entries[i] = new WeightedRandomPotionEffect.WeightedEntry(
                (Holder<MobEffect>)BuiltInRegistries.MOB_EFFECT.get(Identifier.parse(entry.effect)).orElseThrow(), entry.duration, entry.amplifier, weight + f
            );
            f += weight;
            i++;
        }
    }

    public WeightedRandomPotionEffect.WeightedEntry roll(RandomSource rand) {
        float f = rand.nextFloat();

        for (WeightedRandomPotionEffect.WeightedEntry entry : this.entries) {
            if (entry.weight >= f) {
                return entry;
            }
        }

        return null;
    }

    public static WeightedRandomPotionEffect fromJson(JsonArray array) {
        if (array.size() == 0) {
            return EMPTY;
        }

        WeightedRandomPotionEffect.Builder builder = new WeightedRandomPotionEffect.Builder();
        array.forEach(
            element -> {
                JsonObject object = element.getAsJsonObject();
                int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
                int duration = object.get("duration").getAsInt();
                Range level = object.has("amplifier")
                    ? new Range(object.getAsJsonObject("amplifier").get("min").getAsInt(), object.getAsJsonObject("amplifier").get("max").getAsInt())
                    : new Range(0, 0);
                builder.add(object.get("effect").getAsString(), duration, level, weight);
            }
        );
        return builder.build();
    }

    public static class Builder {
        private final ArrayList<WeightedRandomPotionEffect.Builder.Entry> list = new ArrayList();

        public WeightedRandomPotionEffect.Builder add(String effect, int duration, Range level, int weight) {
            this.list.add(new WeightedRandomPotionEffect.Builder.Entry(effect, duration, level, weight));
            return this;
        }

        public WeightedRandomPotionEffect build() {
            return this.list.isEmpty()
                ? WeightedRandomPotionEffect.EMPTY
                : new WeightedRandomPotionEffect((WeightedRandomPotionEffect.Builder.Entry[])this.list.toArray(new WeightedRandomPotionEffect.Builder.Entry[0]));
        }

        private static class Entry {
            public final String effect;
            public final int duration;
            public final Range amplifier;
            public final int weight;

            public Entry(String effect, int duration, Range amplifier, Integer weight) {
                this.effect = effect;
                this.duration = duration;
                this.amplifier = amplifier;
                this.weight = weight;
            }
        }
    }

    public record WeightedEntry(Holder<MobEffect> effect, int duration, Range amplifier, float weight) {
    }
}
