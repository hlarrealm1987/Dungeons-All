package xiroc.dungeonsall.dungeon.monster;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.level.storage.ValueOutput;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.treasure.Loot;
import xiroc.dungeonsall.exception.DatapackLoadException;

public class RandomMonster {
    public static final Hashtable<EntityType<?>, RandomMonster.MobNBTPatcher> NBT_PATCHERS = new Hashtable();
    public static WeightedRandomEntity[] COMMON;
    public static WeightedRandomEntity[] RARE;

    public static void loadJson(ResourceManager resourceManager) {
        COMMON = new WeightedRandomEntity[5];
        RARE = new WeightedRandomEntity[5];

        try {
            loadEntityFile(resourceManager, DungeonsAll.locate("monster/entities/stage_1.json"), 0);
            loadEntityFile(resourceManager, DungeonsAll.locate("monster/entities/stage_2.json"), 1);
            loadEntityFile(resourceManager, DungeonsAll.locate("monster/entities/stage_3.json"), 2);
            loadEntityFile(resourceManager, DungeonsAll.locate("monster/entities/stage_4.json"), 3);
            loadEntityFile(resourceManager, DungeonsAll.locate("monster/entities/stage_5.json"), 4);
        } catch (IOException e) {
            DungeonsAll.LOGGER.error("Failed to load the monster entity files.");
            e.printStackTrace();
        }
    }

    private static void loadEntityFile(ResourceManager resourceManager, Identifier file, int stage) throws IOException {
        DungeonsAll.LOGGER.debug("Loading {}", file.toString());
        Resource resource = (Resource)resourceManager.getResource(file).orElseThrow(() -> new DatapackLoadException("Missing file: " + file));
        JsonObject object = JsonParser.parseReader(new JsonReader(new InputStreamReader(resource.open()))).getAsJsonObject();
        if (object.has("common")) {
            COMMON[stage] = WeightedRandomEntity.fromJson(object.getAsJsonArray("common"));
        } else {
            DungeonsAll.LOGGER.warn("Missing entry 'common' in {}", file.toString());
            COMMON[stage] = WeightedRandomEntity.EMPTY;
        }

        if (object.has("rare")) {
            RARE[stage] = WeightedRandomEntity.fromJson(object.getAsJsonArray("rare"));
        } else {
            DungeonsAll.LOGGER.warn("Missing entry 'rare' in {}", file.toString());
            RARE[stage] = WeightedRandomEntity.EMPTY;
        }
    }

    public static EntityType<?> randomMonster(RandomSource rand, int stage) {
        if (stage > 4) {
            stage = 4;
        }

        if (rand.nextFloat() < 0.1) {
            EntityType<?> monster = RARE[stage].roll(rand);
            return monster != null ? monster : COMMON[stage].roll(rand);
        } else {
            return COMMON[stage].roll(rand);
        }
    }

    static {
        NBT_PATCHERS.put(EntityTypes.WITHER_SKELETON, (RandomMonster.MobNBTPatcher)(nbt, rand, stage) -> {
            nbt.putString("DeathLootTable", Loot.WITHER_SKELETON.identifier().toString());
            nbt.putLong("DeathLootTableSeed", rand.nextInt());
        });
    }

    @FunctionalInterface
    public interface MobNBTPatcher {
        void patch(ValueOutput var1, RandomSource var2, int var3);
    }
}
