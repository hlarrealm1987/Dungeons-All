package xiroc.dungeonsall.dungeon.monster;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import xiroc.dungeonsall.util.IRandom;
import xiroc.dungeonsall.util.Pair;

public class WeightedRandomEntity implements IRandom<EntityType<?>> {
    public static final WeightedRandomEntity EMPTY = new WeightedRandomEntity(List.of());
    private final List<Pair<EntityType<?>, Float>> entries;

    private WeightedRandomEntity(List<Pair<String, Integer>> entries) {
        int weight = 0;

        for (Pair<String, Integer> entry : entries) {
            weight += entry.right();
        }

        this.entries = new ArrayList(entries.size());
        this.assign(entries, weight);
    }

    private void assign(List<Pair<String, Integer>> entries, int totalWeight) {
        float f = 0.0F;

        for (Pair<String, Integer> entry : entries) {
            float weight = (float)entry.right().intValue() / totalWeight;
            this.entries
                .add(new Pair<>((EntityType)BuiltInRegistries.ENTITY_TYPE.get(Identifier.parse(entry.left())).map(Holder::value).orElseThrow(), weight + f));
            f += weight;
        }
    }

    public EntityType<?> roll(RandomSource rand) {
        float f = rand.nextFloat();

        for (Pair<EntityType<?>, Float> entry : this.entries) {
            if (entry.right() >= f) {
                return entry.left();
            }
        }

        return null;
    }

    public static WeightedRandomEntity fromJson(JsonArray array) {
        if (array.size() == 0) {
            return EMPTY;
        }

        WeightedRandomEntity.Builder builder = new WeightedRandomEntity.Builder();
        array.forEach(element -> {
            JsonObject object = element.getAsJsonObject();
            int weight = object.has("weight") ? object.get("weight").getAsInt() : 1;
            builder.add(object.get("entity").getAsString(), weight);
        });
        return builder.build();
    }

    public static class Builder {
        private final ArrayList<Pair<String, Integer>> list = new ArrayList();

        public WeightedRandomEntity.Builder add(String item, int weight) {
            this.list.add(new Pair<>(item, weight));
            return this;
        }

        public WeightedRandomEntity build() {
            return this.list.isEmpty() ? WeightedRandomEntity.EMPTY : new WeightedRandomEntity(this.list);
        }
    }
}
