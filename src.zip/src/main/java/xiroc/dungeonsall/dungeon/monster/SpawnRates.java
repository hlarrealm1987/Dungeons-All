package xiroc.dungeonsall.dungeon.monster;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStreamReader;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.Range;

public class SpawnRates {
    private static Range[] DELAY;
    private static Range[] AMOUNT;

    public static Range getAmount(int level) {
        if (level < 0) {
            return AMOUNT[0];
        } else {
            return level > 4 ? AMOUNT[4] : AMOUNT[level];
        }
    }

    public static Range getDelay(int level) {
        if (level < 0) {
            return DELAY[0];
        } else {
            return level > 4 ? DELAY[4] : DELAY[level];
        }
    }

    public static void loadJson(ResourceManager resourceManager) {
        DELAY = new Range[5];
        AMOUNT = new Range[5];
        Identifier file = DungeonsAll.locate("monster/spawn_rates.json");
        DungeonsAll.LOGGER.debug("Loading {}", file.toString());
        Resource resource = (Resource)resourceManager.getResource(file).orElseThrow(() -> new DatapackLoadException("Missing file: " + file));

        try {
            JsonObject data = JsonParser.parseReader(new InputStreamReader(resource.open())).getAsJsonObject();
            loadLevel(data, file, 0);
            loadLevel(data, file, 1);
            loadLevel(data, file, 2);
            loadLevel(data, file, 3);
            loadLevel(data, file, 4);
        } catch (IOException e) {
            DungeonsAll.LOGGER.error("An error occurred whilst trying to load {}", resource.toString());
            e.printStackTrace();
        }
    }

    private static void loadLevel(JsonObject object, Identifier resource, int level) {
        String entry = "level_" + (level + 1);
        if (object.has(entry)) {
            JsonObject data = object.getAsJsonObject(entry);
            JsonObject delay = data.getAsJsonObject("delay");
            JsonObject amount = data.getAsJsonObject("amount");
            DELAY[level] = new Range(delay.get("min").getAsInt(), delay.get("max").getAsInt());
            AMOUNT[level] = new Range(amount.get("min").getAsInt(), amount.get("max").getAsInt());
        } else {
            throw new DatapackLoadException("Missing entry " + entry + " in " + resource);
        }
    }
}
