package xiroc.dungeonsall.dungeon.monster;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityEquipment;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.WeightedRandom;

public class RandomEquipment {
    public static final int HIGHEST_STAGE = 4;
    public static final int[] ARMOR_COLORS = new int[]{
        11546150, 16701501, 3949738, 6192150, 16351261, 16383998, 15961002, 1908001, 8439583, 4673362, 1481884, 8991416, 3847130
    };
    public static Hashtable<Integer, WeightedRandom<Item>> HELMET;
    public static Hashtable<Integer, WeightedRandom<Item>> CHESTPLATE;
    public static Hashtable<Integer, WeightedRandom<Item>> LEGGINGS;
    public static Hashtable<Integer, WeightedRandom<Item>> BOOTS;
    public static Hashtable<Integer, WeightedRandom<Item>> MELEE_WEAPON;
    public static Hashtable<Integer, WeightedRandom<Item>> RANGED_WEAPON;

    public static void loadJson(ResourceManager resourceManager) {
        HELMET = new Hashtable(5);
        CHESTPLATE = new Hashtable(5);
        LEGGINGS = new Hashtable(5);
        BOOTS = new Hashtable(5);
        MELEE_WEAPON = new Hashtable(5);
        RANGED_WEAPON = new Hashtable(5);

        try {
            loadArmorFromJson(resourceManager, DungeonsAll.locate("monster/equipment/armor/stage_1.json"), 0);
            loadArmorFromJson(resourceManager, DungeonsAll.locate("monster/equipment/armor/stage_2.json"), 1);
            loadArmorFromJson(resourceManager, DungeonsAll.locate("monster/equipment/armor/stage_3.json"), 2);
            loadArmorFromJson(resourceManager, DungeonsAll.locate("monster/equipment/armor/stage_4.json"), 3);
            loadArmorFromJson(resourceManager, DungeonsAll.locate("monster/equipment/armor/stage_5.json"), 4);
            loadWeaponsFromJson(resourceManager, DungeonsAll.locate("monster/equipment/weapon/stage_1.json"), 0);
            loadWeaponsFromJson(resourceManager, DungeonsAll.locate("monster/equipment/weapon/stage_2.json"), 1);
            loadWeaponsFromJson(resourceManager, DungeonsAll.locate("monster/equipment/weapon/stage_3.json"), 2);
            loadWeaponsFromJson(resourceManager, DungeonsAll.locate("monster/equipment/weapon/stage_4.json"), 3);
            loadWeaponsFromJson(resourceManager, DungeonsAll.locate("monster/equipment/weapon/stage_5.json"), 4);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void loadArmorFromJson(ResourceManager resourceManager, Identifier file, int stage) throws IOException {
        Resource resource = (Resource)resourceManager.getResource(file).orElseThrow(() -> new DatapackLoadException("Missing file: " + file));

        try {
            DungeonsAll.LOGGER.debug("Loading {}", file.toString());
            JsonObject object = JsonParser.parseReader(new JsonReader(new InputStreamReader(resource.open()))).getAsJsonObject();
            if (object.has("helmet")) {
                HELMET.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("helmet")));
            } else {
                DungeonsAll.LOGGER.warn("Missing entry 'helmet' in {}", file.toString());
            }

            if (object.has("chestplate")) {
                CHESTPLATE.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("chestplate")));
            } else {
                DungeonsAll.LOGGER.warn("Missing entry 'chestplate' in {}", file.toString());
            }

            if (object.has("leggings")) {
                LEGGINGS.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("leggings")));
            } else {
                DungeonsAll.LOGGER.warn("Missing entry 'leggings' in {}", file.toString());
            }

            if (object.has("boots")) {
                BOOTS.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("boots")));
            } else {
                DungeonsAll.LOGGER.warn("Missing entry 'boots' in {}", file.toString());
            }
        } catch (Exception e) {
            DungeonsAll.LOGGER.error("Failed to load {}", file.toString());
            e.printStackTrace();
        }
    }

    private static void loadWeaponsFromJson(ResourceManager resourceManager, Identifier file, int stage) throws IOException {
        Resource resource = (Resource)resourceManager.getResource(file).orElseThrow(() -> new DatapackLoadException("Missing file: " + file));
        DungeonsAll.LOGGER.debug("Loading {}", file.toString());
        JsonObject object = JsonParser.parseReader(new JsonReader(new InputStreamReader(resource.open()))).getAsJsonObject();
        if (object.has("melee")) {
            MELEE_WEAPON.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("melee")));
        } else {
            DungeonsAll.LOGGER.error("Missing entry 'melee' in {}", file.toString());
        }

        if (object.has("ranged")) {
            RANGED_WEAPON.put(stage, WeightedRandom.ITEM.fromJson(object.getAsJsonArray("ranged")));
        } else {
            DungeonsAll.LOGGER.error("Missing entry 'ranged' in {}", file.toString());
        }
    }

    public static void createArmor(EntityEquipment equipment, RandomSource rand, int stage, RegistryAccess registryAccess) {
        if (stage > 4) {
            stage = 4;
        }

        float chance = 0.4F + 0.15F * stage;
        if (HELMET.containsKey(stage) && rand.nextFloat() < chance) {
            Item item = (Item)((WeightedRandom)HELMET.get(stage)).roll(rand);
            ItemStack helmet = createItemStack(rand, item, stage, registryAccess);
            setArmorColor(helmet, getRandomColor(rand));
            equipment.set(EquipmentSlot.HEAD, helmet);
        }

        if (CHESTPLATE.containsKey(stage) && rand.nextFloat() < chance) {
            Item item = (Item)((WeightedRandom)CHESTPLATE.get(stage)).roll(rand);
            ItemStack chestplate = createItemStack(rand, item, stage, registryAccess);
            setArmorColor(chestplate, getRandomColor(rand));
            equipment.set(EquipmentSlot.CHEST, chestplate);
        }

        if (LEGGINGS.containsKey(stage) && rand.nextFloat() < chance) {
            Item item = (Item)((WeightedRandom)LEGGINGS.get(stage)).roll(rand);
            ItemStack leggings = createItemStack(rand, item, stage, registryAccess);
            setArmorColor(leggings, getRandomColor(rand));
            equipment.set(EquipmentSlot.LEGS, leggings);
        }

        if (BOOTS.containsKey(stage) && rand.nextFloat() < chance) {
            Item item = (Item)((WeightedRandom)BOOTS.get(stage)).roll(rand);
            ItemStack boots = createItemStack(rand, item, stage, registryAccess);
            setArmorColor(boots, getRandomColor(rand));
            equipment.set(EquipmentSlot.FEET, boots);
        }
    }

    public static ItemStack createItemStack(RandomSource rand, Item item, int stage, RegistryAccess registryAccess) {
        ItemStack itemStack = EnchantmentHelper.enchantItem(rand, new ItemStack(item), 10 + 3 * stage, registryAccess, Optional.empty());
        applyDamage(itemStack, rand);
        return itemStack;
    }

    public static void applyDamage(ItemStack item, RandomSource rand) {
        if (item.isDamageableItem()) {
            item.setDamageValue(rand.nextInt(Math.max(1, item.getMaxDamage() / 2)));
        }
    }

    public static void setArmorColor(ItemStack item, int color) {
        DyedItemColor colorComponent = new DyedItemColor(color);
        item.set(DataComponents.DYED_COLOR, colorComponent);
    }

    public static ItemStack getMeleeWeapon(RandomSource rand, int stage, RegistryAccess registryAccess) {
        if (stage > 4) {
            stage = 4;
        }

        return MELEE_WEAPON.containsKey(stage)
            ? createItemStack(rand, (Item)((WeightedRandom)MELEE_WEAPON.get(stage)).roll(rand), stage, registryAccess)
            : ItemStack.EMPTY;
    }

    public static ItemStack getRangedWeapon(RandomSource rand, int stage, RegistryAccess registryAccess) {
        if (stage > 4) {
            stage = 4;
        }

        return RANGED_WEAPON.containsKey(stage)
            ? createItemStack(rand, (Item)((WeightedRandom)RANGED_WEAPON.get(stage)).roll(rand), stage, registryAccess)
            : ItemStack.EMPTY;
    }

    public static int getRandomColor(RandomSource rand) {
        return ARMOR_COLORS[rand.nextInt(ARMOR_COLORS.length)];
    }

    public static Item getItem(Identifier Identifier) {
        if (BuiltInRegistries.ITEM.containsKey(Identifier)) {
            return (Item)BuiltInRegistries.ITEM.get(Identifier).map(Holder::value).orElse(Items.AIR);
        }

        DungeonsAll.LOGGER.warn("Failed to get {} from the item registry.", Identifier.toString());
        return null;
    }
}
