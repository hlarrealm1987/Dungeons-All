package xiroc.dungeonsall.dungeon.piece;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonStairs extends DungeonPiece {
    public int stairType;

    public DungeonStairs() {
        super((StructurePieceType)ModStructurePieceTypes.STAIRS.get());
        this.stairType = 0;
    }

    public DungeonStairs(CompoundTag p_i51343_2_) {
        super((StructurePieceType)ModStructurePieceTypes.STAIRS.get(), p_i51343_2_);
        this.stairType = (Integer)p_i51343_2_.getInt("stairType").orElseThrow();
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
        switch (this.stairType) {
            case 0:
                this.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(DungeonModels.BOTTOM_STAIRS);
                break;
            case 1:
                this.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(DungeonModels.TOP_STAIRS);
        }
    }

    public void postProcess(
        WorldGenLevel worldIn,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource randomIn,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            BlockPos pos = new BlockPos(this.x, this.y, this.z).offset(this.model.getOffset(this.rotation));
            switch (this.stairType) {
                case 0:
                    this.buildModel(
                        this.model,
                        worldIn,
                        structureBoundingBoxIn,
                        pos,
                        randomIn,
                        PlacementConfiguration.BOTTOM_STAIRCASE,
                        this.theme,
                        this.secondaryTheme,
                        this.stage,
                        Rotation.NONE,
                        false,
                        false
                    );
                    this.ironBars(worldIn, structureBoundingBoxIn, this.model, randomIn);
                    this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
                    this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, this.boundingBox, this.model);
                    break;
                case 1:
                    this.buildModel(
                        this.model,
                        worldIn,
                        structureBoundingBoxIn,
                        pos,
                        randomIn,
                        PlacementConfiguration.DEFAULT,
                        this.theme,
                        this.secondaryTheme,
                        this.stage,
                        Rotation.NONE,
                        false,
                        false
                    );
                    this.entrances(worldIn, structureBoundingBoxIn, this.model, randomIn);
                    this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
                    this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, this.boundingBox, this.model);
            }
        }
    }

    public void ironBars(LevelAccessor world, BoundingBox bounds, DungeonModel model, RandomSource random) {
        int pathStartX = (model.width - 3) / 2;
        int pathStartZ = (model.length - 3) / 2;
        if (this.sides[0]) {
            for (int x0 = pathStartX; x0 < pathStartX + 3; x0++) {
                for (int y0 = 1; y0 < 4; y0++) {
                    this.replaceBlockState(
                        world,
                        this.theme.fencing.get(world, new BlockPos(this.x + x0, this.y + y0, this.z), random),
                        this.x + x0,
                        this.y + y0,
                        this.z,
                        bounds,
                        true
                    );
                }
            }
        }

        if (this.sides[1]) {
            for (int z0 = pathStartZ; z0 < pathStartZ + 3; z0++) {
                for (int y0 = 1; y0 < 4; y0++) {
                    this.replaceBlockState(
                        world,
                        this.theme.fencing.get(world, new BlockPos(this.x + model.width, this.y + y0, this.z + z0), random),
                        this.x + model.width - 1,
                        this.y + y0,
                        this.z + z0,
                        bounds,
                        true
                    );
                }
            }
        }

        if (this.sides[2]) {
            for (int x0 = pathStartX; x0 < pathStartX + 3; x0++) {
                for (int y0 = 1; y0 < 4; y0++) {
                    this.replaceBlockState(
                        world,
                        this.theme.fencing.get(world, new BlockPos(this.x + x0, this.y + y0, this.z + model.length), random),
                        this.x + x0,
                        this.y + y0,
                        this.z + model.length - 1,
                        bounds,
                        true
                    );
                }
            }
        }

        if (this.sides[3]) {
            for (int z0 = pathStartZ; z0 < pathStartZ + 3; z0++) {
                for (int y0 = 1; y0 < 4; y0++) {
                    this.replaceBlockState(
                        world,
                        this.theme.fencing.get(world, new BlockPos(this.x, this.y + y0, this.z + z0), random),
                        this.x,
                        this.y + y0,
                        this.z + z0,
                        bounds,
                        true
                    );
                }
            }
        }
    }

    @Override
    public void createBoundingBox() {
        if (this.model != null) {
            this.boundingBox = this.model.createBoundingBoxWithOffset(this.x, this.y, this.z, this.rotation);
        }
    }

    @Override
    public boolean canConnect(Direction side, int x, int z) {
        return true;
    }

    public DungeonStairs bottom() {
        this.stairType = 0;
        return this;
    }

    public DungeonStairs top() {
        this.stairType = 1;
        return this;
    }

    @Override
    public void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tagCompound) {
        super.addAdditionalSaveData(context, tagCompound);
        tagCompound.putInt("stairType", this.stairType);
    }

    @Override
    public int getDungeonPieceType() {
        return 1;
    }
}
