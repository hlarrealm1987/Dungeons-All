package xiroc.dungeonsall.dungeon.piece.room;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonSpiderRoom extends DungeonPiece {
    private BlockPos[] spawners;
    private BlockPos[] chests;

    public DungeonSpiderRoom(CompoundTag nbt) {
        super((StructurePieceType)ModStructurePieceTypes.SPIDER_ROOM.get(), nbt);
        if (nbt.contains("spawners")) {
            ListTag list = (ListTag)nbt.getList("spawners").orElseThrow();
            this.spawners = new BlockPos[list.size()];

            for (int i = 0; i < this.spawners.length; i++) {
                CompoundTag pos = (CompoundTag)list.getCompound(i).orElseThrow();
                this.spawners[i] = new BlockPos(
                    (Integer)pos.getInt("x").orElseThrow(), (Integer)pos.getInt("y").orElseThrow(), (Integer)pos.getInt("z").orElseThrow()
                );
            }
        }

        if (nbt.contains("chests")) {
            ListTag list = (ListTag)nbt.getList("chests").orElseThrow();
            this.chests = new BlockPos[list.size()];

            for (int i = 0; i < this.chests.length; i++) {
                CompoundTag pos = (CompoundTag)list.getCompound(i).orElseThrow();
                this.chests[i] = new BlockPos(
                    (Integer)pos.getInt("x").orElseThrow(), (Integer)pos.getInt("y").orElseThrow(), (Integer)pos.getInt("z").orElseThrow()
                );
            }
        }
    }

    @Override
    public void setup(RandomSource rand) {
        int floor = this.y + 1;
        int chests = 1 + rand.nextInt(2);
        int spawners = chests + rand.nextInt(2);
        this.chests = new BlockPos[chests];
        this.spawners = new BlockPos[spawners];
        int x = 0;
        int z = 0;

        for (int i = 0; i < spawners; i++) {
            x = (x + 1 + rand.nextInt(3)) % 9;
            z = (z + 1 + rand.nextInt(3)) % 9;
            this.spawners[i] = new BlockPos(this.x + x, floor + rand.nextInt(2), this.z + z);
            if (i < chests) {
                this.chests[i] = new BlockPos(this.spawners[i].getX(), this.spawners[i].getY() == floor ? floor + 1 : floor, this.spawners[i].getZ());
            }
        }
    }

    public void postProcess(
        WorldGenLevel p_230383_1_,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource p_230383_4_,
        BoundingBox p_230383_5_,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
    }

    @Override
    public int getDungeonPieceType() {
        return 15;
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
    }

    @Override
    public void createBoundingBox() {
        this.boundingBox = new BoundingBox(this.x, this.y, this.z, this.x + 8, this.y + 8, this.z + 8);
    }

    @Override
    public void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tagCompound) {
        super.addAdditionalSaveData(context, tagCompound);
        if (this.spawners != null) {
            tagCompound.put("spawners", positionsToNbt(this.spawners));
        }

        if (this.chests != null) {
            tagCompound.put("chests", positionsToNbt(this.chests));
        }
    }
}
