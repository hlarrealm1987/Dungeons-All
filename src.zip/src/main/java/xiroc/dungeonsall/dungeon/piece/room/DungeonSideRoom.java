package xiroc.dungeonsall.dungeon.piece.room;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonSideRoom extends DungeonPiece {
    public DungeonSideRoom() {
        super((StructurePieceType)ModStructurePieceTypes.SIDE_ROOM.get());
    }

    public DungeonSideRoom(CompoundTag p_i51343_2_) {
        super((StructurePieceType)ModStructurePieceTypes.SIDE_ROOM.get(), p_i51343_2_);
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
        this.model = modelSelector.rooms.roll(rand);
    }

    public void postProcess(
        WorldGenLevel worldIn,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource randomIn,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            BlockPos pos = new BlockPos(this.x, this.y, this.z).offset(this.model.getOffset(this.rotation));
            this.buildModel(
                this.model,
                worldIn,
                structureBoundingBoxIn,
                pos,
                randomIn,
                PlacementConfiguration.DEFAULT,
                this.theme,
                this.secondaryTheme,
                this.stage,
                this.rotation,
                false,
                false
            );
            this.entrances(worldIn, structureBoundingBoxIn, this.model, randomIn);
            this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
            this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, this.boundingBox, this.model);
        }
    }

    @Override
    public void createBoundingBox() {
        if (this.model != null) {
            this.boundingBox = this.model.createBoundingBoxWithOffset(this.x, this.y, this.z, this.rotation);
        }
    }

    @Override
    public int getDungeonPieceType() {
        return 9;
    }
}
