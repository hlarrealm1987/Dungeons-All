package xiroc.dungeonsall.dungeon.piece;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.StructurePiece;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.material.FluidState;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.DungeonType;
import xiroc.dungeonsall.dungeon.PillarGenerator;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.block.DungeonBlocks;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.decoration.DungeonDecoration;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModelBlock;
import xiroc.dungeonsall.dungeon.model.DungeonModelFeature;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.model.MultipartModelData;
import xiroc.dungeonsall.dungeon.model.PlacementBehaviour;
import xiroc.dungeonsall.dungeon.treasure.Loot;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.IBlockPlacementHandler;
import xiroc.dungeonsall.util.Orientation;
import xiroc.dungeonsall.util.Position2D;

public abstract class DungeonPiece extends StructurePiece {
    private static final BoundingBox EMPTY_BOX = new BoundingBox(0, 0, 0, 0, 0, 0);
    public static final int CORRIDOR = 0;
    public static final int STAIRS = 1;
    public static final int ENTRANCE = 6;
    public static final int ROOM = 8;
    public static final int SIDE_ROOM = 9;
    public static final int NODE_ROOM = 10;
    public static final int NODE_CONNECTOR = 11;
    public static final int MEGA_NODE_PART = 12;
    public static final int SECRET_ROOM = 14;
    public static final int SPIDER_ROOM = 15;
    public static final int MULTIPART_PIECE = 16;
    public Rotation rotation;
    public int connectedSides;
    public int x;
    public int y;
    public int z;
    public int stage;
    public boolean[] sides = new boolean[4];
    @Nullable
    public DungeonModelFeature.Instance[] features;
    public byte[] variation;
    public DungeonModel model;
    public Theme theme;
    public SecondaryTheme secondaryTheme;
    public Position2D gridPosition;

    public DungeonPiece(StructurePieceType p_i51343_1_) {
        super(p_i51343_1_, 0, EMPTY_BOX);
        this.connectedSides = 0;
        this.rotation = Rotation.NONE;
        this.gridPosition = new Position2D(0, 0);
    }

    public DungeonPiece(StructurePieceType p_i51343_1_, CompoundTag p_i51343_2_) {
        super(p_i51343_1_, p_i51343_2_);
        this.sides[0] = (Boolean)p_i51343_2_.getBoolean("north").orElseThrow();
        this.sides[1] = (Boolean)p_i51343_2_.getBoolean("east").orElseThrow();
        this.sides[2] = (Boolean)p_i51343_2_.getBoolean("south").orElseThrow();
        this.sides[3] = (Boolean)p_i51343_2_.getBoolean("west").orElseThrow();
        this.connectedSides = (Integer)p_i51343_2_.getInt("connectedSides").orElseThrow();
        this.gridPosition = new Position2D((Integer)p_i51343_2_.getInt("posX").orElseThrow(), (Integer)p_i51343_2_.getInt("posZ").orElseThrow());
        this.x = (Integer)p_i51343_2_.getInt("x").orElseThrow();
        this.y = (Integer)p_i51343_2_.getInt("y").orElseThrow();
        this.z = (Integer)p_i51343_2_.getInt("z").orElseThrow();
        this.stage = (Integer)p_i51343_2_.getInt("stage").orElseThrow();
        this.rotation = Orientation.getRotation((Integer)p_i51343_2_.getInt("rotation").orElseThrow());
        this.theme = Theme.getTheme(Identifier.parse((String)p_i51343_2_.getString("theme").orElseThrow()));
        this.secondaryTheme = Theme.getSecondaryTheme(Identifier.parse((String)p_i51343_2_.getString("secondaryTheme").orElseThrow()));
        this.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(Identifier.parse((String)p_i51343_2_.getString("model").orElseThrow()));
        if (p_i51343_2_.contains("features")) {
            this.features = readAllFeatures((ListTag)p_i51343_2_.getList("features").orElseThrow());
        }

        if (p_i51343_2_.contains("variation")) {
            this.variation = (byte[])p_i51343_2_.getByteArray("variation").orElseThrow();
        }

        this.createBoundingBox();
    }

    public void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tagCompound) {
        tagCompound.putBoolean("north", this.sides[0]);
        tagCompound.putBoolean("east", this.sides[1]);
        tagCompound.putBoolean("south", this.sides[2]);
        tagCompound.putBoolean("west", this.sides[3]);
        tagCompound.putInt("connectedSides", this.connectedSides);
        tagCompound.putInt("posX", this.gridPosition.x);
        tagCompound.putInt("posZ", this.gridPosition.z);
        tagCompound.putInt("x", this.x);
        tagCompound.putInt("y", this.y);
        tagCompound.putInt("z", this.z);
        tagCompound.putInt("stage", this.stage);
        tagCompound.putInt("rotation", Orientation.rotationAsInt(this.rotation));
        if (this.model != null) {
            tagCompound.putString("model", this.model.getKey().toString());
        }

        if (this.theme != null) {
            tagCompound.putString("theme", this.theme.getKey().toString());
        }

        if (this.secondaryTheme != null) {
            tagCompound.putString("secondaryTheme", this.secondaryTheme.getKey().toString());
        }

        if (this.features != null) {
            ListTag list = new ListTag();
            writeAllFeatures(this.features, list);
            tagCompound.put("features", list);
        }

        if (this.variation != null) {
            tagCompound.putByteArray("variation", this.variation);
        }
    }

    public abstract int getDungeonPieceType();

    public abstract void setupModel(DungeonBuilder var1, ModelSelector var2, List<DungeonPiece> var3, RandomSource var4);

    public void createBoundingBox() {
        if (this.model != null) {
            this.boundingBox = this.model.createBoundingBoxWithOffset(this.x, this.y, this.z, this.rotation);
        }
    }

    public void openSide(Direction side) {
        switch (side) {
            case NORTH:
                if (this.sides[0]) {
                    return;
                }

                this.sides[0] = true;
                this.connectedSides++;
                break;
            case EAST:
                if (this.sides[1]) {
                    return;
                }

                this.sides[1] = true;
                this.connectedSides++;
                break;
            case SOUTH:
                if (this.sides[2]) {
                    return;
                }

                this.sides[2] = true;
                this.connectedSides++;
                break;
            case WEST:
                if (this.sides[3]) {
                    return;
                }

                this.sides[3] = true;
                this.connectedSides++;
        }
    }

    public void setRotation(Rotation rotation) {
        this.rotation = rotation;
    }

    public Rotation getRotation() {
        return this.rotation;
    }

    public void setGridPosition(int x, int z) {
        this.gridPosition = new Position2D(x, z);
    }

    public void setGridPosition(Position2D position) {
        this.gridPosition = position;
    }

    public void setWorldPosition(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public void setup(RandomSource rand) {
        if (this.model != null) {
            if (this.model.hasFeatures()) {
                Vec3i offset = this.model.getOffset(this.rotation);
                List<DungeonModelFeature.Instance> features = new ArrayList();

                for (DungeonModelFeature feature : this.model.getFeatures()) {
                    feature.setup(this.model, this.x + offset.getX(), this.y + offset.getY(), this.z + offset.getZ(), this.rotation, features, rand);
                }

                this.features = (DungeonModelFeature.Instance[])features.toArray(new DungeonModelFeature.Instance[0]);
            }

            if (this.model.isVariationEnabled()) {
                this.variation = new byte[8];

                for (int i = 0; i < this.variation.length; i++) {
                    this.variation[i] = (byte)rand.nextInt(64);
                }
            }
        }
    }

    protected boolean hasPillarAt(BlockPos pos) {
        return false;
    }

    public void takeOverProperties(DungeonPiece piece) {
        this.sides = piece.sides;
        this.connectedSides = piece.connectedSides;
        this.rotation = piece.rotation;
    }

    public boolean hasChildPieces() {
        return this.model != null && this.model.hasMultipart();
    }

    public void addChildPieces(List<DungeonPiece> pieces, DungeonBuilder builder, DungeonType type, ModelSelector modelSelector, int layer, RandomSource rand) {
        if (this.model != null && (this.model.hasMultipart() || type.getLayer(layer).hasMultipartOverride(this.model))) {
            BlockPos pos = new BlockPos(this.x, this.y, this.z).offset(this.model.getOffset(this.rotation));

            for (MultipartModelData data : type.getLayer(layer).getMultipartData(this.model)) {
                if (data.checkConditions(this)) {
                    pieces.add(data.models.roll(rand).createMultipartPiece(this, this.model, this.rotation, pos.getX(), pos.getY(), pos.getZ(), rand));
                } else if (data.alternatives != null) {
                    pieces.add(data.alternatives.roll(rand).createMultipartPiece(this, this.model, this.rotation, pos.getX(), pos.getY(), pos.getZ(), rand));
                }
            }
        }
    }

    public void buildModel(
        DungeonModel model,
        LevelAccessor world,
        BoundingBox boundsIn,
        BlockPos pos,
        RandomSource random,
        PlacementConfiguration configuration,
        Theme theme,
        SecondaryTheme secondaryTheme,
        int lootLevel,
        Rotation rotation,
        boolean fillAir,
        boolean expandDownwards
    ) {
        if ((Boolean)Config.EXTENDED_DEBUG.get()) {
            DungeonsAll.LOGGER.debug("Building {} with rotation {} at ({} | {} | {})", model.getKey(), rotation, pos.getX(), pos.getY(), pos.getZ());
        }

        List<BlockPos> fancyPillars = new ArrayList(4);
        model.blocks
            .forEach(
                block -> {
                    BlockPos position = block.worldPos(model, rotation, pos);
                    if (boundsIn.isInside(position)) {
                        BlockState state = block.type
                            .blockFactory
                            .get(block, rotation, world, position, theme, secondaryTheme, world.getRandom(), this.variation, this.stage);
                        this.placeBlock(
                            world,
                            state,
                            position,
                            block,
                            rotation,
                            random,
                            configuration,
                            theme,
                            secondaryTheme,
                            fancyPillars,
                            lootLevel,
                            fillAir,
                            expandDownwards
                        );
                    }
                }
            );
        fancyPillars.forEach(pillar -> PillarGenerator.generateFancyPillar(world, pillar, random, boundsIn, theme));
        fancyPillars.clear();
        if ((Boolean)Config.EXTENDED_DEBUG.get()) {
            DungeonsAll.LOGGER.debug("Finished building {} with rotation {} at ({} | {} | {})", model.getKey(), rotation, pos.getX(), pos.getY(), pos.getZ());
        }
    }

    public void placeBlock(
        LevelAccessor world,
        BlockState state,
        BlockPos position,
        DungeonModelBlock block,
        Rotation rotation,
        RandomSource random,
        PlacementConfiguration configuration,
        Theme theme,
        SecondaryTheme secondaryTheme,
        List<BlockPos> fancyPillars,
        int lootLevel,
        boolean fillAir,
        boolean expandDownwards
    ) {
        if (!DungeonBuilder.isBlockProtected(world, position)) {
            PlacementBehaviour placementBehaviour = (PlacementBehaviour)block.type.placementBehaviourFromConfig.apply(configuration);
            if (world.isEmptyBlock(position) && !placementBehaviour.isSolid(world, position, rotation, world.getRandom())) {
                if (placementBehaviour.airBlock != null) {
                    state = ((BlockStateProvider)placementBehaviour.airBlock.apply(theme, secondaryTheme)).get(world, position, random);
                } else if (!fillAir && !(Boolean)Config.SOLID.get()) {
                    return;
                }
            }

            IBlockPlacementHandler.getHandler(state.getBlock()).place(world, state, position, random, theme, secondaryTheme, lootLevel);
            if (world.getBlockEntity(position) instanceof RandomizableContainerBlockEntity randomizableContainerBlockEntity) {
                if (this.model.hasLootTable()) {
                    Loot.setLoot(world, position, randomizableContainerBlockEntity, this.model.getLootTable(), theme, secondaryTheme, random);
                } else {
                    Loot.setLoot(world, position, randomizableContainerBlockEntity, Loot.getLootTable(this.stage, random), theme, secondaryTheme, random);
                }
            }

            FluidState fluidState = world.getFluidState(position);
            if (!fluidState.isEmpty()) {
                world.scheduleTick(position, fluidState.getType(), 0);
            }

            if (block.hasProperties || !state.getProperties().isEmpty()) {
                world.getChunk(position).markPosForPostProcessing(position);
            }

            if (expandDownwards) {
                if (block.type.isExpandable() && block.position.getY() == 0 && !world.getBlockState(position.below()).canOcclude()) {
                    PillarGenerator.generateSimplePillar(world, position.below(), theme, random);
                }
            } else if (block.position.getY() == 0
                && (block.type.isPillar() || this.hasPillarAt(position))
                && !world.getBlockState(position.below()).canOcclude()) {
                fancyPillars.add(position.below());
            }
        }
    }

    public void replaceBlockState(LevelAccessor worldIn, BlockState blockState, int x, int y, int z, BoundingBox bounds, boolean postProcessing) {
        BlockPos blockPos = new BlockPos(x, y, z);
        if (bounds.isInside(blockPos)) {
            if (DungeonBuilder.isBlockProtected(worldIn, blockPos) || worldIn.isEmptyBlock(blockPos)) {
                return;
            }

            worldIn.setBlock(blockPos, blockState, 2);
            if (postProcessing) {
                worldIn.getChunk(blockPos).markPosForPostProcessing(blockPos);
            }

            FluidState fluidstate = worldIn.getFluidState(blockPos);
            if (!fluidstate.isEmpty()) {
                worldIn.scheduleTick(blockPos, fluidstate.getType(), 0);
            }
        }
    }

    protected void entrances(LevelAccessor world, BoundingBox bounds, DungeonModel model, RandomSource random) {
        int pathStartX = (model.width - 3) / 2;
        int pathStartZ = (model.length - 3) / 2;
        Vec3i offset = model.getOffset(this.rotation);
        BlockPos pos = new BlockPos(this.x + offset.getX(), this.y, this.z + offset.getZ());
        if (this.sides[0]) {
            for (int x0 = pathStartX; x0 < pathStartX + 3; x0++) {
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + x0, pos.getY() + 1, pos.getZ(), bounds, false);
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + x0, pos.getY() + 2, pos.getZ(), bounds, false);
            }

            this.replaceBlockState(world, CAVE_AIR, pos.getX() + pathStartX + 1, pos.getY() + 3, pos.getZ(), bounds, false);
            BlockStateProvider stateProvider = model.getEntranceType() == 0 ? this.theme.stairs : this.secondaryTheme.stairs;
            BlockPos pos1 = new BlockPos(pos.getX() + pathStartX, pos.getY() + 3, pos.getZ());
            BlockState stair1 = stateProvider.get(world, pos1, random);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HORIZONTAL_FACING, Direction.WEST);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair1, pos1.getX(), pos1.getY(), pos1.getZ(), bounds, false);
            BlockPos pos2 = pos1.relative(Direction.EAST, 2);
            BlockState stair2 = stateProvider.get(world, pos2, random);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HORIZONTAL_FACING, Direction.EAST);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair2, pos2.getX(), pos2.getY(), pos2.getZ(), bounds, false);
        }

        if (this.sides[1]) {
            for (int z0 = pathStartZ; z0 < pathStartZ + 3; z0++) {
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + model.width - 1, pos.getY() + 1, pos.getZ() + z0, bounds, false);
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + model.width - 1, pos.getY() + 2, pos.getZ() + z0, bounds, false);
            }

            this.replaceBlockState(world, CAVE_AIR, pos.getX() + model.width - 1, pos.getY() + 3, pos.getZ() + pathStartZ + 1, bounds, false);
            BlockStateProvider stateProvider = model.getEntranceType() == 0 ? this.theme.stairs : this.secondaryTheme.stairs;
            BlockPos pos1 = new BlockPos(pos.getX() + model.width - 1, pos.getY() + 3, pos.getZ() + pathStartZ);
            BlockState stair1 = stateProvider.get(world, pos1, random);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair1, pos1.getX(), pos1.getY(), pos1.getZ(), bounds, false);
            BlockPos pos2 = pos1.relative(Direction.SOUTH, 2);
            BlockState stair2 = stateProvider.get(world, pos2, random);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair2, pos2.getX(), pos2.getY(), pos2.getZ(), bounds, false);
        }

        if (this.sides[2]) {
            for (int x0 = pathStartX; x0 < pathStartX + 3; x0++) {
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + x0, pos.getY() + 1, pos.getZ() + model.length - 1, bounds, false);
                this.replaceBlockState(world, CAVE_AIR, pos.getX() + x0, pos.getY() + 2, pos.getZ() + model.length - 1, bounds, false);
            }

            this.replaceBlockState(world, CAVE_AIR, pos.getX() + pathStartX + 1, pos.getY() + 3, pos.getZ() + model.length - 1, bounds, false);
            BlockStateProvider stateProvider = model.getEntranceType() == 0 ? this.theme.stairs : this.secondaryTheme.stairs;
            BlockPos pos1 = new BlockPos(pos.getX() + pathStartX, pos.getY() + 3, pos.getZ() + model.length - 1);
            BlockState stair1 = stateProvider.get(world, pos1, random);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HORIZONTAL_FACING, Direction.WEST);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair1, pos1.getX(), pos1.getY(), pos1.getZ(), bounds, false);
            BlockPos pos2 = pos1.relative(Direction.EAST, 2);
            BlockState stair2 = stateProvider.get(world, pos2, random);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HORIZONTAL_FACING, Direction.EAST);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair2, pos2.getX(), pos2.getY(), pos2.getZ(), bounds, false);
        }

        if (this.sides[3]) {
            for (int z0 = pathStartZ; z0 < pathStartZ + 3; z0++) {
                this.replaceBlockState(world, CAVE_AIR, pos.getX(), pos.getY() + 1, pos.getZ() + z0, bounds, false);
                this.replaceBlockState(world, CAVE_AIR, pos.getX(), pos.getY() + 2, pos.getZ() + z0, bounds, false);
            }

            this.replaceBlockState(world, CAVE_AIR, pos.getX(), pos.getY() + 3, pos.getZ() + pathStartZ + 1, bounds, false);
            BlockStateProvider stateProvider = model.getEntranceType() == 0 ? this.theme.stairs : this.secondaryTheme.stairs;
            BlockPos pos1 = new BlockPos(pos.getX(), pos.getY() + 3, pos.getZ() + pathStartZ);
            BlockState stair1 = stateProvider.get(world, pos1, random);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HORIZONTAL_FACING, Direction.NORTH);
            stair1 = DungeonBlocks.applyProperty(stair1, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair1, pos1.getX(), pos1.getY(), pos1.getZ(), bounds, false);
            BlockPos pos2 = pos1.relative(Direction.SOUTH, 2);
            BlockState stair2 = stateProvider.get(world, pos2, random);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HORIZONTAL_FACING, Direction.SOUTH);
            stair2 = DungeonBlocks.applyProperty(stair2, BlockStateProperties.HALF, Half.TOP);
            this.replaceBlockState(world, stair2, pos2.getX(), pos2.getY(), pos2.getZ(), bounds, false);
        }
    }

    protected void decorate(
        LevelAccessor world, BlockPos pos, Theme theme, RandomSource random, BoundingBox worldGenBounds, BoundingBox structureBounds, DungeonModel model
    ) {
        if (theme.hasDecorations()) {
            for (DungeonDecoration decoration : theme.getDecorations()) {
                if ((Boolean)Config.EXTENDED_DEBUG.get()) {
                    DungeonsAll.LOGGER
                        .debug("Running decoration {} for {} at ({} | {} | {})", decoration.toString(), model.getKey(), pos.getX(), pos.getY(), pos.getZ());
                }

                decoration.decorate(model, world, pos, random, worldGenBounds, structureBounds, this);
                if ((Boolean)Config.EXTENDED_DEBUG.get()) {
                    DungeonsAll.LOGGER
                        .debug("Finished decoration {} for {} at ({} | {} | {})", decoration.toString(), model.getKey(), pos.getX(), pos.getY(), pos.getZ());
                }
            }
        }
    }

    protected void placeFeatures(LevelAccessor world, BoundingBox bounds, Theme theme, SecondaryTheme secondaryTheme, RandomSource rand, int stage) {
        if (this.features != null) {
            for (DungeonModelFeature.Instance feature : this.features) {
                feature.place(world, bounds, rand, theme, secondaryTheme, stage);
            }
        }
    }

    public static Direction getOneWayDirection(DungeonPiece piece) {
        if (piece.sides[0]) {
            return Direction.NORTH;
        } else if (piece.sides[1]) {
            return Direction.EAST;
        } else if (piece.sides[2]) {
            return Direction.SOUTH;
        } else {
            return piece.sides[3] ? Direction.WEST : Direction.NORTH;
        }
    }

    public boolean canConnect(Direction side, int x, int z) {
        return true;
    }

    public static Direction getOpenSide(DungeonPiece piece, int n) {
        int c = 0;

        for (int i = 0; i < 4; i++) {
            if (piece.sides[i] && c++ == n) {
                return getDirectionFromInt(i);
            }
        }

        throw new IllegalStateException(piece + " does not have " + n + "or more open sides.");
    }

    public static Direction getDirectionFromInt(int dir) {
        return switch (dir) {
            case 1 -> Direction.EAST;
            case 2 -> Direction.SOUTH;
            case 3 -> Direction.WEST;
            default -> Direction.NORTH;
        };
    }

    protected static ListTag positionsToNbt(BlockPos[] positions) {
        ListTag nbtPositions = new ListTag();

        for (BlockPos pillar : positions) {
            CompoundTag p = new CompoundTag();
            p.putInt("x", pillar.getX());
            p.putInt("y", pillar.getY());
            p.putInt("z", pillar.getZ());
            nbtPositions.add(p);
        }

        return nbtPositions;
    }

    protected static BlockPos[] positionsFromNbt(ListTag nbt) {
        BlockPos[] positions = new BlockPos[nbt.size()];

        for (int i = 0; i < nbt.size(); i++) {
            CompoundTag pillar = (CompoundTag)nbt.getCompound(i).orElseThrow();
            positions[i] = new BlockPos(
                (Integer)pillar.getInt("x").orElseThrow(), (Integer)pillar.getInt("y").orElseThrow(), (Integer)pillar.getInt("z").orElseThrow()
            );
        }

        return positions;
    }

    protected static DungeonModelFeature.Instance[] readAllFeatures(ListTag nbt) {
        DungeonModelFeature.Instance[] features = new DungeonModelFeature.Instance[nbt.size()];

        for (int i = 0; i < features.length; i++) {
            features[i] = DungeonModelFeature.Instance.read((CompoundTag)nbt.getCompound(i).orElseThrow());
        }

        return features;
    }

    protected static void writeAllFeatures(DungeonModelFeature.Instance[] positions, ListTag nbt) {
        for (DungeonModelFeature.Instance feature : positions) {
            CompoundTag position = new CompoundTag();
            feature.write(position);
            nbt.add(position);
        }
    }
}
