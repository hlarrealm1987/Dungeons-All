package xiroc.dungeonsall.dungeon.piece;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonMultipartModelPiece extends DungeonPiece {
    public DungeonMultipartModelPiece() {
        super((StructurePieceType)ModStructurePieceTypes.MULTIPART_MODEL_PIECE.get());
    }

    public DungeonMultipartModelPiece(CompoundTag p_i51343_2_) {
        super((StructurePieceType)ModStructurePieceTypes.MULTIPART_MODEL_PIECE.get(), p_i51343_2_);
    }

    @Override
    public int getDungeonPieceType() {
        return 16;
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
    }

    public void postProcess(
        WorldGenLevel world,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource random,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            BlockPos pos = new BlockPos(this.x, this.y, this.z);
            this.buildModel(
                this.model,
                world,
                this.boundingBox,
                pos,
                random,
                PlacementConfiguration.DEFAULT,
                this.theme,
                this.secondaryTheme,
                this.stage,
                this.rotation,
                false,
                false
            );
            this.placeFeatures(world, this.boundingBox, this.theme, this.secondaryTheme, random, this.stage);
            this.decorate(world, pos, this.theme, random, structureBoundingBoxIn, this.boundingBox, this.model);
        }
    }

    @Override
    public void createBoundingBox() {
        if (this.model != null) {
            this.boundingBox = this.model.createBoundingBox(this.x, this.y, this.z, this.rotation);
        }
    }
}
