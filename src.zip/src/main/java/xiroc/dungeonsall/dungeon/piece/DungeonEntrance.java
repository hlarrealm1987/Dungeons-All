package xiroc.dungeonsall.dungeon.piece;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceSerializationContext;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonEntrance extends DungeonPiece {
    private static final String KEY_SURFACE_HEIGHT = "SurfaceHeight";
    private Integer surfaceHeight;

    public DungeonEntrance() {
        super((StructurePieceType)ModStructurePieceTypes.ENTRANCE.get());
    }

    public DungeonEntrance(CompoundTag nbt) {
        super((StructurePieceType)ModStructurePieceTypes.ENTRANCE.get(), nbt);
        if (nbt.contains("SurfaceHeight")) {
            this.surfaceHeight = (Integer)nbt.getInt("SurfaceHeight").orElseThrow();
        }
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
    }

    public void postProcess(
        WorldGenLevel worldIn,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource randomIn,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            if (this.surfaceHeight == null) {
                this.surfaceHeight = worldIn.getHeight(Types.WORLD_SURFACE_WG, this.x + 4, this.z + 4);
            }

            int cursorHeight = this.y;
            DungeonModel staircaseLayer = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(DungeonModels.STAIRCASE_LAYER);
            Rotation layerRotation = Rotation.NONE;

            while (cursorHeight < this.surfaceHeight) {
                this.buildModel(
                    staircaseLayer,
                    worldIn,
                    structureBoundingBoxIn,
                    new BlockPos(this.x + 2, cursorHeight, this.z + 2),
                    randomIn,
                    PlacementConfiguration.DEFAULT,
                    this.theme,
                    this.secondaryTheme,
                    this.stage,
                    layerRotation,
                    true,
                    false
                );
                layerRotation = layerRotation.getRotated(Rotation.CLOCKWISE_90);
                cursorHeight++;
            }

            BlockPos pos = new BlockPos(this.x + 4, cursorHeight, this.z + 4).offset(rotatedOffset(this.model.getOffset(), layerRotation, this.model));
            this.buildModel(
                this.model,
                worldIn,
                structureBoundingBoxIn,
                pos,
                randomIn,
                PlacementConfiguration.DEFAULT,
                this.theme,
                this.secondaryTheme,
                this.stage,
                layerRotation,
                true,
                true
            );
            this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
            BoundingBox populationBox = this.model.createBoundingBox(pos, layerRotation);
            this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, populationBox, this.model);
        }
    }

    private static Vec3i rotatedOffset(Vec3i offset, Rotation rotation, DungeonModel model) {
        return switch (rotation) {
            case CLOCKWISE_90 -> new Vec3i(-model.length - offset.getZ() + 1, offset.getY(), offset.getX());
            case CLOCKWISE_180 -> new Vec3i(-model.width - offset.getX() + 1, offset.getY(), -model.length - offset.getZ() + 1);
            case COUNTERCLOCKWISE_90 -> new Vec3i(offset.getZ(), offset.getY(), -model.width - offset.getX() + 1);
            default -> offset;
        };
    }

    @Override
    public void createBoundingBox() {
        if (this.model != null) {
            Vec3i defaultOffset = this.model.getOffset();
            Vec3i clockwise90 = rotatedOffset(defaultOffset, Rotation.CLOCKWISE_90, this.model);
            Vec3i clockwise180 = rotatedOffset(defaultOffset, Rotation.CLOCKWISE_180, this.model);
            Vec3i counterClockwise90 = rotatedOffset(defaultOffset, Rotation.COUNTERCLOCKWISE_90, this.model);
            int minOffsetX = Math.min(Math.min(defaultOffset.getX(), clockwise90.getX()), Math.min(clockwise180.getX(), counterClockwise90.getX()));
            int minOffsetZ = Math.min(Math.min(defaultOffset.getZ(), clockwise90.getZ()), Math.min(clockwise180.getZ(), counterClockwise90.getZ()));
            int x = this.x + 4 + minOffsetX;
            int z = this.z + 4 + minOffsetZ;
            this.boundingBox = new BoundingBox(
                x, 0, z, x + Math.max(this.model.width, this.model.length) - 1, 512, z + Math.max(this.model.width, this.model.length) - 1
            );
        }
    }

    @Override
    public int getDungeonPieceType() {
        return 6;
    }

    @Override
    public void addAdditionalSaveData(StructurePieceSerializationContext context, CompoundTag tagCompound) {
        super.addAdditionalSaveData(context, tagCompound);
        if (this.surfaceHeight != null) {
            tagCompound.putInt("SurfaceHeight", this.surfaceHeight);
        }
    }
}
