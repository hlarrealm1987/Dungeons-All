package xiroc.dungeonsall.dungeon.piece;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonNodeConnector extends DungeonPiece {
    public DungeonNodeConnector() {
        super((StructurePieceType)ModStructurePieceTypes.NODE_CONNECTOR.get());
    }

    public DungeonNodeConnector(CompoundTag nbt) {
        super((StructurePieceType)ModStructurePieceTypes.NODE_CONNECTOR.get(), nbt);
    }

    public void postProcess(
        WorldGenLevel worldIn,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource randomIn,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            BlockPos pos = new BlockPos(this.x, this.y + this.model.getOffset(this.rotation).getY(), this.z);
            this.buildModel(
                this.model,
                worldIn,
                structureBoundingBoxIn,
                pos,
                randomIn,
                PlacementConfiguration.CORRIDOR,
                this.theme,
                this.secondaryTheme,
                this.stage,
                this.rotation,
                false,
                false
            );
            this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
            this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, this.boundingBox, this.model);
        }
    }

    @Override
    public int getDungeonPieceType() {
        return 11;
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
        this.model = modelSelector.nodeConnectors.roll(rand);
    }

    @Override
    protected boolean hasPillarAt(BlockPos pos) {
        return this.rotation != Rotation.NONE && this.rotation != Rotation.CLOCKWISE_180
            ? pos.getX() % 3 == 0 && pos.getZ() % 6 == 0
            : pos.getX() % 6 == 0 && pos.getZ() % 3 == 0;
    }

    public void adjustPositionAndBounds() {
        if (this.model != null) {
            if (this.rotation != Rotation.NONE && this.rotation != Rotation.CLOCKWISE_180) {
                int minX = this.x - (this.model.length - 3) / 2;
                this.boundingBox = new BoundingBox(minX, this.y, this.z, minX + this.model.length - 1, this.y + this.model.height - 1, this.z + 4);
            } else {
                int minZ = this.z - (this.model.length - 3) / 2;
                this.boundingBox = new BoundingBox(this.x, this.y, minZ, this.x + 4, this.y + this.model.height - 1, minZ + this.model.length - 1);
            }

            this.setWorldPosition(this.boundingBox.minX(), this.boundingBox.minY(), this.boundingBox.minZ());
        }
    }

    @Override
    public void createBoundingBox() {
        if (this.model != null) {
            this.boundingBox = this.model.createBoundingBoxWithOffset(this.x, this.y, this.z, this.rotation);
        }
    }
}
