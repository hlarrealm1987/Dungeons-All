package xiroc.dungeonsall.dungeon.piece.room;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.model.ModelSelector;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.init.ModStructurePieceTypes;

public class DungeonRoom extends DungeonPiece {
    public DungeonRoom() {
        super((StructurePieceType)ModStructurePieceTypes.ROOM.get());
    }

    public DungeonRoom(CompoundTag p_i51343_2_) {
        super((StructurePieceType)ModStructurePieceTypes.ROOM.get(), p_i51343_2_);
    }

    @Override
    public void setupModel(DungeonBuilder builder, ModelSelector modelSelector, List<DungeonPiece> pieces, RandomSource rand) {
        this.model = modelSelector.rooms.roll(rand);
    }

    public void postProcess(
        WorldGenLevel worldIn,
        StructureManager p_230383_2_,
        ChunkGenerator p_230383_3_,
        RandomSource randomIn,
        BoundingBox structureBoundingBoxIn,
        ChunkPos p_230383_6_,
        BlockPos p_230383_7_
    ) {
        if (this.model == null) {
            DungeonsAll.LOGGER.warn("Missing model for {}", this);
        } else {
            Vec3i offset = this.model.getOffset(this.rotation);
            BlockPos pos = new BlockPos(this.x, this.y, this.z).offset(offset);
            this.buildModel(
                this.model,
                worldIn,
                structureBoundingBoxIn,
                pos,
                randomIn,
                PlacementConfiguration.ROOM,
                this.theme,
                this.secondaryTheme,
                this.stage,
                Rotation.NONE,
                false,
                false
            );
            this.entrances(worldIn, structureBoundingBoxIn, this.model, randomIn);
            this.placeFeatures(worldIn, structureBoundingBoxIn, this.theme, this.secondaryTheme, randomIn, this.stage);
            this.decorate(worldIn, pos, this.theme, randomIn, structureBoundingBoxIn, this.boundingBox, this.model);
        }
    }

    @Override
    public int getDungeonPieceType() {
        return 8;
    }
}
