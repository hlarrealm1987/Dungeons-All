package xiroc.dungeonsall.dungeon;

import xiroc.dungeonsall.dungeon.model.DungeonModelBlockType;
import xiroc.dungeonsall.dungeon.model.PlacementBehaviour;

public class PlacementConfiguration {
    public static final PlacementConfiguration DEFAULT = new PlacementConfiguration.Builder().build();
    public static final PlacementConfiguration BOTTOM_STAIRCASE = new PlacementConfiguration.Builder()
        .generic(DungeonModelBlockType.GENERIC.defaultPlacementBehavior.withAirBlock((theme, secondaryTheme) -> theme.getFencing()))
        .build();
    public static final PlacementConfiguration CORRIDOR = new PlacementConfiguration.Builder().floor(PlacementBehaviour.STRIPES).build();
    public static final PlacementConfiguration ROOM = new PlacementConfiguration.Builder().floor(PlacementBehaviour.SMALL_GRID).build();
    public static final PlacementConfiguration NODE = new PlacementConfiguration.Builder().floor(PlacementBehaviour.LARGE_GRID).build();
    public final PlacementBehaviour solid;
    public final PlacementBehaviour solidStairs;
    public final PlacementBehaviour solidSlab;
    public final PlacementBehaviour generic;
    public final PlacementBehaviour genericOrFencing;
    public final PlacementBehaviour slab;
    public final PlacementBehaviour solidPillar;
    public final PlacementBehaviour solidFloor;
    public final PlacementBehaviour fencing;
    public final PlacementBehaviour floor;
    public final PlacementBehaviour fluid;
    public final PlacementBehaviour looseGround;
    public final PlacementBehaviour stairs;
    public final PlacementBehaviour wall;
    public final PlacementBehaviour pillar;
    public final PlacementBehaviour trapdoor;
    public final PlacementBehaviour door;
    public final PlacementBehaviour fence;
    public final PlacementBehaviour fenceGate;
    public final PlacementBehaviour material;
    public final PlacementBehaviour materialButton;
    public final PlacementBehaviour materialPressurePlate;
    public final PlacementBehaviour materialSlab;
    public final PlacementBehaviour materialStairs;
    public final PlacementBehaviour chest;
    public final PlacementBehaviour carpet;
    public final PlacementBehaviour other;
    public final PlacementBehaviour skull;

    public PlacementConfiguration(
        PlacementBehaviour solid,
        PlacementBehaviour solidStairs,
        PlacementBehaviour solidSlab,
        PlacementBehaviour generic,
        PlacementBehaviour genericOrFencing,
        PlacementBehaviour slab,
        PlacementBehaviour solidPillar,
        PlacementBehaviour solidFloor,
        PlacementBehaviour fencing,
        PlacementBehaviour floor,
        PlacementBehaviour fluid,
        PlacementBehaviour looseGround,
        PlacementBehaviour stairs,
        PlacementBehaviour wall,
        PlacementBehaviour pillar,
        PlacementBehaviour trapdoor,
        PlacementBehaviour door,
        PlacementBehaviour fence,
        PlacementBehaviour fenceGate,
        PlacementBehaviour material,
        PlacementBehaviour materialButton,
        PlacementBehaviour materialPressurePlate,
        PlacementBehaviour materialSlab,
        PlacementBehaviour materialStairs,
        PlacementBehaviour chest,
        PlacementBehaviour carpet,
        PlacementBehaviour other,
        PlacementBehaviour skull
    ) {
        this.solid = solid;
        this.solidStairs = solidStairs;
        this.solidSlab = solidSlab;
        this.generic = generic;
        this.genericOrFencing = genericOrFencing;
        this.slab = slab;
        this.solidPillar = solidPillar;
        this.solidFloor = solidFloor;
        this.fencing = fencing;
        this.floor = floor;
        this.fluid = fluid;
        this.looseGround = looseGround;
        this.stairs = stairs;
        this.wall = wall;
        this.pillar = pillar;
        this.trapdoor = trapdoor;
        this.door = door;
        this.fence = fence;
        this.fenceGate = fenceGate;
        this.material = material;
        this.materialButton = materialButton;
        this.materialPressurePlate = materialPressurePlate;
        this.materialSlab = materialSlab;
        this.materialStairs = materialStairs;
        this.chest = chest;
        this.carpet = carpet;
        this.other = other;
        this.skull = skull;
    }

    public PlacementBehaviour getSolid() {
        return this.solid;
    }

    public PlacementBehaviour getSolidStairs() {
        return this.solidStairs;
    }

    public PlacementBehaviour getSolidSlab() {
        return this.solidSlab;
    }

    public PlacementBehaviour getGeneric() {
        return this.generic;
    }

    public PlacementBehaviour getGenericOrFencing() {
        return this.genericOrFencing;
    }

    public PlacementBehaviour getSlab() {
        return this.slab;
    }

    public PlacementBehaviour getSolidPillar() {
        return this.solidPillar;
    }

    public PlacementBehaviour getSolidFloor() {
        return this.solidFloor;
    }

    public PlacementBehaviour getFencing() {
        return this.fencing;
    }

    public PlacementBehaviour getFloor() {
        return this.floor;
    }

    public PlacementBehaviour getFluid() {
        return this.fluid;
    }

    public PlacementBehaviour getLooseGround() {
        return this.looseGround;
    }

    public PlacementBehaviour getStairs() {
        return this.stairs;
    }

    public PlacementBehaviour getWall() {
        return this.wall;
    }

    public PlacementBehaviour getPillar() {
        return this.pillar;
    }

    public PlacementBehaviour getTrapdoor() {
        return this.trapdoor;
    }

    public PlacementBehaviour getDoor() {
        return this.door;
    }

    public PlacementBehaviour getFence() {
        return this.fence;
    }

    public PlacementBehaviour getFenceGate() {
        return this.fenceGate;
    }

    public PlacementBehaviour getMaterial() {
        return this.material;
    }

    public PlacementBehaviour getMaterialButton() {
        return this.materialButton;
    }

    public PlacementBehaviour getMaterialPressurePlate() {
        return this.materialPressurePlate;
    }

    public PlacementBehaviour getMaterialSlab() {
        return this.materialSlab;
    }

    public PlacementBehaviour getMaterialStairs() {
        return this.materialStairs;
    }

    public PlacementBehaviour getChest() {
        return this.chest;
    }

    public PlacementBehaviour getCarpet() {
        return this.carpet;
    }

    public PlacementBehaviour getOther() {
        return this.other;
    }

    public PlacementBehaviour getSkull() {
        return this.skull;
    }

    private static class Builder {
        private PlacementBehaviour solid = DungeonModelBlockType.SOLID.defaultPlacementBehavior;
        private PlacementBehaviour solidStairs = DungeonModelBlockType.SOLID_STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour solidSlab = DungeonModelBlockType.SOLID_SLAB.defaultPlacementBehavior;
        private PlacementBehaviour generic = DungeonModelBlockType.GENERIC.defaultPlacementBehavior;
        private PlacementBehaviour genericOrFencing = DungeonModelBlockType.GENERIC_OR_FENCING.defaultPlacementBehavior;
        private PlacementBehaviour slab = DungeonModelBlockType.SLAB.defaultPlacementBehavior;
        private PlacementBehaviour solidPillar = DungeonModelBlockType.SOLID_PILLAR.defaultPlacementBehavior;
        private PlacementBehaviour solidFloor = DungeonModelBlockType.SOLID_FLOOR.defaultPlacementBehavior;
        private PlacementBehaviour fencing = DungeonModelBlockType.FENCING.defaultPlacementBehavior;
        private PlacementBehaviour floor = DungeonModelBlockType.FLOOR.defaultPlacementBehavior;
        private PlacementBehaviour fluid = DungeonModelBlockType.FLOOR.defaultPlacementBehavior;
        private PlacementBehaviour looseGround = DungeonModelBlockType.LOOSE_GROUND.defaultPlacementBehavior;
        private PlacementBehaviour stairs = DungeonModelBlockType.STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour wall = DungeonModelBlockType.WALL.defaultPlacementBehavior;
        private PlacementBehaviour pillar = DungeonModelBlockType.PILLAR.defaultPlacementBehavior;
        private PlacementBehaviour trapdoor = DungeonModelBlockType.TRAPDOOR.defaultPlacementBehavior;
        private PlacementBehaviour door = DungeonModelBlockType.DOOR.defaultPlacementBehavior;
        private PlacementBehaviour fence = DungeonModelBlockType.FENCE.defaultPlacementBehavior;
        private PlacementBehaviour fenceGate = DungeonModelBlockType.FENCE_GATE.defaultPlacementBehavior;
        private PlacementBehaviour material = DungeonModelBlockType.MATERIAL.defaultPlacementBehavior;
        private PlacementBehaviour materialButton = DungeonModelBlockType.MATERIAL_BUTTON.defaultPlacementBehavior;
        private PlacementBehaviour materialPressurePlate = DungeonModelBlockType.MATERIAL_PRESSURE_PLATE.defaultPlacementBehavior;
        private PlacementBehaviour materialSlab = DungeonModelBlockType.MATERIAL_SLAB.defaultPlacementBehavior;
        private PlacementBehaviour materialStairs = DungeonModelBlockType.MATERIAL_STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour chest = DungeonModelBlockType.MATERIAL_STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour carpet = DungeonModelBlockType.MATERIAL_STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour other = DungeonModelBlockType.MATERIAL_STAIRS.defaultPlacementBehavior;
        private PlacementBehaviour skull = DungeonModelBlockType.MATERIAL_STAIRS.defaultPlacementBehavior;

        public PlacementConfiguration.Builder solid(PlacementBehaviour solid) {
            this.solid = solid;
            return this;
        }

        public PlacementConfiguration.Builder solidStairs(PlacementBehaviour solidStairs) {
            this.solidStairs = solidStairs;
            return this;
        }

        public PlacementConfiguration.Builder solidSlab(PlacementBehaviour solidSlab) {
            this.solidSlab = solidSlab;
            return this;
        }

        public PlacementConfiguration.Builder generic(PlacementBehaviour generic) {
            this.generic = generic;
            return this;
        }

        public PlacementConfiguration.Builder genericOrFencing(PlacementBehaviour genericOrFencing) {
            this.genericOrFencing = genericOrFencing;
            return this;
        }

        public PlacementConfiguration.Builder slab(PlacementBehaviour slab) {
            this.slab = slab;
            return this;
        }

        public PlacementConfiguration.Builder solidPillar(PlacementBehaviour solidPillar) {
            this.solidPillar = solidPillar;
            return this;
        }

        public PlacementConfiguration.Builder solidFloor(PlacementBehaviour solidFloor) {
            this.solidFloor = solidFloor;
            return this;
        }

        public PlacementConfiguration.Builder fencing(PlacementBehaviour fencing) {
            this.fencing = fencing;
            return this;
        }

        public PlacementConfiguration.Builder floor(PlacementBehaviour floor) {
            this.floor = floor;
            return this;
        }

        public PlacementConfiguration.Builder fluid(PlacementBehaviour fluid) {
            this.fluid = fluid;
            return this;
        }

        public PlacementConfiguration.Builder looseGround(PlacementBehaviour looseGround) {
            this.looseGround = looseGround;
            return this;
        }

        public PlacementConfiguration.Builder stairs(PlacementBehaviour stairs) {
            this.stairs = stairs;
            return this;
        }

        public PlacementConfiguration.Builder wall(PlacementBehaviour wall) {
            this.wall = wall;
            return this;
        }

        public PlacementConfiguration.Builder pillar(PlacementBehaviour pillar) {
            this.pillar = pillar;
            return this;
        }

        public PlacementConfiguration.Builder trapdoor(PlacementBehaviour trapdoor) {
            this.trapdoor = trapdoor;
            return this;
        }

        public PlacementConfiguration.Builder door(PlacementBehaviour door) {
            this.door = door;
            return this;
        }

        public PlacementConfiguration.Builder fence(PlacementBehaviour fence) {
            this.fence = fence;
            return this;
        }

        public PlacementConfiguration.Builder fenceGate(PlacementBehaviour fenceGate) {
            this.fenceGate = fenceGate;
            return this;
        }

        public PlacementConfiguration.Builder material(PlacementBehaviour material) {
            this.material = material;
            return this;
        }

        public PlacementConfiguration.Builder materialButton(PlacementBehaviour materialButton) {
            this.materialButton = materialButton;
            return this;
        }

        public PlacementConfiguration.Builder materialPressurePlate(PlacementBehaviour materialPressurePlate) {
            this.materialPressurePlate = materialPressurePlate;
            return this;
        }

        public PlacementConfiguration.Builder materialSlab(PlacementBehaviour materialSlab) {
            this.materialSlab = materialSlab;
            return this;
        }

        public PlacementConfiguration.Builder materialStairs(PlacementBehaviour materialStairs) {
            this.materialStairs = materialStairs;
            return this;
        }

        public PlacementConfiguration.Builder chest(PlacementBehaviour chest) {
            this.chest = chest;
            return this;
        }

        public PlacementConfiguration.Builder carpet(PlacementBehaviour carpet) {
            this.carpet = carpet;
            return this;
        }

        public PlacementConfiguration.Builder other(PlacementBehaviour other) {
            this.other = other;
            return this;
        }

        public PlacementConfiguration.Builder skull(PlacementBehaviour skull) {
            this.skull = skull;
            return this;
        }

        public PlacementConfiguration build() {
            return new PlacementConfiguration(
                this.solid,
                this.solidStairs,
                this.solidSlab,
                this.generic,
                this.genericOrFencing,
                this.slab,
                this.solidPillar,
                this.solidFloor,
                this.fencing,
                this.floor,
                this.fluid,
                this.looseGround,
                this.stairs,
                this.wall,
                this.pillar,
                this.trapdoor,
                this.door,
                this.fence,
                this.fenceGate,
                this.material,
                this.materialButton,
                this.materialPressurePlate,
                this.materialSlab,
                this.materialStairs,
                this.chest,
                this.carpet,
                this.other,
                this.skull
            );
        }
    }
}
