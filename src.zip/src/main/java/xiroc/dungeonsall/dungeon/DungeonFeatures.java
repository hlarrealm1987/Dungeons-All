package xiroc.dungeonsall.dungeon;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import xiroc.dungeonsall.dungeon.generator.layer.SideRoomData;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSideRoom;
import xiroc.dungeonsall.util.Position2D;

public class DungeonFeatures {
    public static final List<DungeonFeatures.CorridorFeature> CORRIDOR_FEATURES = Lists.newArrayList();

    public static void processCorridor(DungeonBuilder builder, DungeonLayer layer, int x, int z, RandomSource rand, int lyr, int stage, BlockPos startPos) {
        for (DungeonFeatures.CorridorFeature corridorFeature : CORRIDOR_FEATURES) {
            if (corridorFeature.process(builder, layer, x, z, rand, lyr, stage, startPos)) {
                return;
            }
        }
    }

    static {
        CORRIDOR_FEATURES.add((DungeonFeatures.CorridorFeature)(builder, layer, x, z, rand, lyr, stage, startPos) -> {
            if (layer.grid[x][z].piece.connectedSides < 4 && rand.nextFloat() < 0.075) {
                SideRoomData sideRoomData = layer.findSideRoomData(new Position2D(x, z), rand);
                if (sideRoomData != null) {
                    DungeonSideRoom sideRoom = new DungeonSideRoom();
                    Direction dir = sideRoomData.rotation().rotate(Direction.WEST);
                    sideRoom.openSide(dir);
                    sideRoom.setGridPosition(sideRoomData.position());
                    sideRoom.setRotation(sideRoomData.rotation());
                    sideRoom.stage = stage;
                    layer.grid[sideRoomData.position().x][sideRoomData.position().z] = new Tile(sideRoom);
                    layer.grid[x][z].piece.openSide(dir.getOpposite());
                    layer.map.markPositionAsOccupied(sideRoomData.position());
                    layer.rotatePiece(layer.grid[x][z], rand);
                    return true;
                }
            }

            return false;
        });
    }

    @FunctionalInterface
    public interface CorridorFeature {
        boolean process(DungeonBuilder var1, DungeonLayer var2, int var3, int var4, RandomSource var5, int var6, int var7, BlockPos var8);
    }
}
