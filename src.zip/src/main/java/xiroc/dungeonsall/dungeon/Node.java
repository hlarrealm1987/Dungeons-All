package xiroc.dungeonsall.dungeon;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Rotation;
import xiroc.dungeonsall.dungeon.piece.room.DungeonNodeRoom;

public class Node {
    public static final Node DEAD_END = new Node(false, false, false, true);
    public static final Node STRAIGHT = new Node(false, true, false, true);
    public static final Node TURN = new Node(false, false, true, true);
    public static final Node FORK = new Node(false, true, true, true);
    public static final Node FULL = new Node(true, true, true, true);
    private final boolean[] sides;

    public Node(boolean north, boolean east, boolean south, boolean west) {
        this.sides = new boolean[]{north, east, south, west};
    }

    public Node rotate(Rotation rotation) {
        return switch (rotation) {
            case CLOCKWISE_90 -> new Node(this.sides[3], this.sides[0], this.sides[1], this.sides[2]);
            case COUNTERCLOCKWISE_90 -> new Node(this.sides[1], this.sides[2], this.sides[3], this.sides[0]);
            case CLOCKWISE_180 -> new Node(this.sides[2], this.sides[3], this.sides[0], this.sides[1]);
            default -> this;
        };
    }

    public Rotation compare(Node node, RandomSource rand) {
        return compare(node, this, Rotation.NONE, rand.nextBoolean() ? Rotation.CLOCKWISE_90 : Rotation.COUNTERCLOCKWISE_90, 0);
    }

    private static Rotation compare(Node node, Node rotatedNode, Rotation currentRotation, Rotation step, int depth) {
        if (depth > 3) {
            return null;
        }

        for (int i = 0; i < node.sides.length; i++) {
            if (node.sides[i] && !rotatedNode.sides[i]) {
                return compare(node, rotatedNode.rotate(step), currentRotation.getRotated(step), step, ++depth);
            }
        }

        return currentRotation;
    }

    public static Node ofNodeRoom(DungeonNodeRoom nodeRoom) {
        switch (nodeRoom.connectedSides) {
            case 1:
                return DEAD_END;
            case 2:
                return (!nodeRoom.sides[0] || !nodeRoom.sides[2]) && (!nodeRoom.sides[1] || !nodeRoom.sides[3]) ? TURN : STRAIGHT;
            case 3:
                return FORK;
            default:
                return FULL;
        }
    }
}
