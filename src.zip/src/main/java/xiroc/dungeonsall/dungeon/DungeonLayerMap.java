package xiroc.dungeonsall.dungeon;

import xiroc.dungeonsall.util.Position2D;

public class DungeonLayerMap {
    public final int width;
    public final int length;
    public final boolean[][] map;

    public DungeonLayerMap(int width, int length) {
        this.width = width;
        this.length = length;
        this.map = new boolean[width][length];
    }

    public boolean isPositionFree(int x, int z) {
        return !this.map[x][z];
    }

    public void markPositionAsOccupied(Position2D pos) {
        this.map[pos.x][pos.z] = true;
    }
}
