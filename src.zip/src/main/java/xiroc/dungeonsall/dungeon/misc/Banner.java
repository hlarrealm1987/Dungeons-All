package xiroc.dungeonsall.dungeon.misc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.Registries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.entity.BannerPattern;
import net.minecraft.world.level.block.entity.BannerPatternLayers;
import net.minecraft.world.level.block.entity.BannerPatternLayers.Layer;

public class Banner {
    private static final int PATTERN_COUNT = 3;

    public static BannerPatternLayers createPatterns(RandomSource rand, RegistryAccess registryAccess) {
        Registry<BannerPattern> bannerPatterns = registryAccess.lookupOrThrow(Registries.BANNER_PATTERN);
        List<Layer> layers = new ArrayList();

        for (int i = 0; i < 3; i++) {
            Holder<BannerPattern> pattern = (Holder<BannerPattern>)bannerPatterns.getRandom(rand).orElseThrow();
            layers.add(new Layer(pattern, DyeColor.byId(rand.nextInt(16))));
        }

        return new BannerPatternLayers(layers);
    }
}
