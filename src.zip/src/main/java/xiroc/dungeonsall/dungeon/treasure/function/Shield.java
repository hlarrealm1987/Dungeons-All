package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import xiroc.dungeonsall.dungeon.treasure.RandomItems;

public class Shield extends LootItemConditionalFunction {
    public static final MapCodec<Shield> CODEC = RecordCodecBuilder.mapCodec(
        builder -> commonFields(builder).and(Codec.INT.fieldOf("loot_level").forGetter(shield -> shield.lootLevel)).apply(builder, Shield::new)
    );
    public final int lootLevel;

    public Shield(List<LootItemCondition> conditions, int lootLevel) {
        super(conditions);
        this.lootLevel = Math.max(0, lootLevel);
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        return RandomItems.createShield(context.getRandom(), this.lootLevel, context.getLevel().registryAccess());
    }

    public static Builder<?> shield(int lootLevel) {
        return simpleBuilder(conditions -> new Shield(conditions, lootLevel));
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }
}
