package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.phys.Vec3;
import xiroc.dungeonsall.dungeon.treasure.Loot;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.Range;

public class MaterialBlocks extends LootItemConditionalFunction {
    public static final MapCodec<MaterialBlocks> CODEC = RecordCodecBuilder.mapCodec(builder -> commonFields(builder).apply(builder, MaterialBlocks::new));
    private static final Range AMOUNT = new Range(16, 64);

    public MaterialBlocks(java.util.Optional<net.minecraft.core.Holder<LootItemCondition>> conditions) {
        super(conditions);
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        if (context.hasParameter(LootContextParams.ORIGIN)) {
            Vec3 origin = xiroc.dungeonsall.compat.Compat26.parameter(context, LootContextParams.ORIGIN);
            if (origin == null) {
                return new ItemStack(Blocks.STONE_BRICKS, AMOUNT.nextInt(context.getRandom()));
            }
            BlockPos chestPosition = new BlockPos((int)(origin.x - 0.5), (int)(origin.y - 0.5), (int)(origin.z - 0.5));
            BlockEntity chest = context.getLevel().getBlockEntity(chestPosition);
            if (chest != null && chest.getPersistentData().contains("dungeonsall")) {
                Pair<Theme, SecondaryTheme> themes = Loot.getLootInformation(chest.getPersistentData());
                return new ItemStack(
                    getMaterial(themes.left(), themes.right(), context.getLevel(), chestPosition, context.getRandom()), AMOUNT.nextInt(context.getRandom())
                );
            }
        }

        return new ItemStack(Blocks.STONE_BRICKS, AMOUNT.nextInt(context.getRandom()));
    }

    private static Block getMaterial(Theme theme, SecondaryTheme secondaryTheme, LevelAccessor world, BlockPos pos, RandomSource rand) {
        return rand.nextBoolean() ? theme.material.get(world, pos, rand).getBlock() : secondaryTheme.material.get(world, pos, rand).getBlock();
    }

    public static Builder<?> materialBlocks() {
        return simpleBuilder(MaterialBlocks::new);
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }
}
