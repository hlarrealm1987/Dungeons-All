package xiroc.dungeonsall.dungeon.treasure;

import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Optional;
import net.minecraft.core.Holder;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.ItemLike;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.misc.Banner;
import xiroc.dungeonsall.util.Range;
import xiroc.dungeonsall.util.WeightedRandom;

public class RandomItems {
    private static WeightedRandom<Item> STAGE_1;
    private static WeightedRandom<Item> STAGE_2;
    private static WeightedRandom<Item> STAGE_3;
    private static WeightedRandom<Item> STAGE_4;
    private static WeightedRandom<Item> STAGE_5;
    private static final Range[] UNBREAKING_LEVELS = new Range[]{new Range(1, 1), new Range(1, 2), new Range(2, 2), new Range(2, 3), new Range(3, 3)};

    public static void loadJson(ResourceManager resourceManager) {
        try {
            Identifier stage1 = DungeonsAll.locate("treasure/stage_1.json");
            DungeonsAll.LOGGER.debug("Loading {}", stage1.toString());
            JsonArray array = JsonParser.parseReader(
                    new JsonReader(new InputStreamReader(((Resource)resourceManager.getResource(stage1).orElseThrow()).open()))
                )
                .getAsJsonArray();
            STAGE_1 = WeightedRandom.ITEM.fromJson(array);
            stage1 = DungeonsAll.locate("treasure/stage_2.json");
            DungeonsAll.LOGGER.debug("Loading {}", stage1.toString());
            array = JsonParser.parseReader(new JsonReader(new InputStreamReader(((Resource)resourceManager.getResource(stage1).orElseThrow()).open())))
                .getAsJsonArray();
            STAGE_2 = WeightedRandom.ITEM.fromJson(array);
            stage1 = DungeonsAll.locate("treasure/stage_3.json");
            DungeonsAll.LOGGER.debug("Loading {}", stage1.toString());
            array = JsonParser.parseReader(new JsonReader(new InputStreamReader(((Resource)resourceManager.getResource(stage1).orElseThrow()).open())))
                .getAsJsonArray();
            STAGE_3 = WeightedRandom.ITEM.fromJson(array);
            stage1 = DungeonsAll.locate("treasure/stage_4.json");
            DungeonsAll.LOGGER.debug("Loading {}", stage1.toString());
            array = JsonParser.parseReader(new JsonReader(new InputStreamReader(((Resource)resourceManager.getResource(stage1).orElseThrow()).open())))
                .getAsJsonArray();
            STAGE_4 = WeightedRandom.ITEM.fromJson(array);
            stage1 = DungeonsAll.locate("treasure/stage_5.json");
            DungeonsAll.LOGGER.debug("Loading {}", stage1.toString());
            array = JsonParser.parseReader(new JsonReader(new InputStreamReader(((Resource)resourceManager.getResource(stage1).orElseThrow()).open())))
                .getAsJsonArray();
            STAGE_5 = WeightedRandom.ITEM.fromJson(array);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static WeightedRandom<Item> itemProvider(int stage) {
        return switch (Mth.clamp(stage, 0, 4)) {
            case 0 -> STAGE_1;
            case 1 -> STAGE_2;
            case 2 -> STAGE_3;
            case 3 -> STAGE_4;
            default -> STAGE_5;
        };
    }

    public static ItemStack generate(RandomSource rand, int lootLevel, RegistryAccess registryAccess) {
        ItemStack stack = new ItemStack((ItemLike)itemProvider(lootLevel).roll(rand));
        return rand.nextFloat() < 0.5F + 0.1F * lootLevel
            ? EnchantmentHelper.enchantItem(rand, stack, 10 + 3 * lootLevel, registryAccess, Optional.empty())
            : stack;
    }

    public static ItemStack createShield(RandomSource rand, int lootLevel, RegistryAccess registryAccess) {
        ItemStack shield = new ItemStack(Items.SHIELD);
        lootLevel = Mth.clamp(lootLevel, 0, 4);
        float f = rand.nextFloat();
        if (f < 0.12F + lootLevel * 0.02F) {
            shield.enchant(enchantment(Enchantments.UNBREAKING, registryAccess), UNBREAKING_LEVELS[Mth.clamp(lootLevel, 0, 4)].nextInt(rand));
            if (f < 0.04F + lootLevel * 0.01F) {
                shield.enchant(enchantment(Enchantments.MENDING, registryAccess), 1);
            }

            if (rand.nextFloat() < 0.75F) {
                shield.enchant(enchantment(Enchantments.VANISHING_CURSE, registryAccess), 1);
            }
        }

        shield.set(DataComponents.BANNER_PATTERNS, Banner.createPatterns(rand, registryAccess));
        return shield;
    }

    private static Holder<Enchantment> enchantment(ResourceKey<Enchantment> key, RegistryAccess registryAccess) {
        return (Holder<Enchantment>)registryAccess.lookupOrThrow(Registries.ENCHANTMENT).get(key).orElseThrow();
    }
}
