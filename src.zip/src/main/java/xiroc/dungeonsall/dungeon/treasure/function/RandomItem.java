package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import xiroc.dungeonsall.dungeon.treasure.RandomItems;

public class RandomItem extends LootItemConditionalFunction {
    public static final MapCodec<RandomItem> CODEC = RecordCodecBuilder.mapCodec(
        builder -> commonFields(builder).and(Codec.INT.fieldOf("loot_level").forGetter(randomItem -> randomItem.lootLevel)).apply(builder, RandomItem::new)
    );
    public int lootLevel;

    public RandomItem(java.util.Optional<net.minecraft.core.Holder<LootItemCondition>> conditions, int lootLevel) {
        super(conditions);
        this.lootLevel = Math.max(0, lootLevel);
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        return context.hasParameter(LootContextParams.ORIGIN)
            ? RandomItems.generate(context.getRandom(), this.lootLevel, context.getLevel().registryAccess())
            : ItemStack.EMPTY;
    }

    public static Builder<?> randomItem(int lootLevel) {
        return simpleBuilder(conditions -> new RandomItem(conditions, lootLevel));
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }
}
