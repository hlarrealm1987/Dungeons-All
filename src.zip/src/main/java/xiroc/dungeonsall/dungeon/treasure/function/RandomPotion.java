package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import xiroc.dungeonsall.dungeon.treasure.TreasureItems;

public class RandomPotion extends LootItemConditionalFunction {
    public static final MapCodec<RandomPotion> CODEC = RecordCodecBuilder.mapCodec(
        builder -> commonFields(builder)
            .and(Codec.INT.fieldOf("loot_level").forGetter(randomPotion -> randomPotion.lootLevel))
            .apply(builder, RandomPotion::new)
    );
    public int lootLevel;

    public RandomPotion(java.util.Optional<net.minecraft.core.Holder<LootItemCondition>> conditions, int lootLevel) {
        super(conditions);
        this.lootLevel = Math.max(0, lootLevel);
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        return TreasureItems.getRandomSpecialPotion(context.getRandom(), this.lootLevel);
    }

    public static Builder<?> randomPotion(int lootLevel) {
        return simpleBuilder(conditions -> new RandomPotion(conditions, lootLevel));
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }
}
