package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.SuspiciousStewEffects;
import net.minecraft.world.item.component.SuspiciousStewEffects.Entry;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class SuspiciousStew extends LootItemConditionalFunction {
    public static final MapCodec<SuspiciousStew> CODEC = RecordCodecBuilder.mapCodec(builder -> commonFields(builder).apply(builder, SuspiciousStew::new));
    private static final Entry[] EFFECTS;

    public SuspiciousStew(java.util.Optional<net.minecraft.core.Holder<LootItemCondition>> conditions) {
        super(conditions);
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        stack.set(DataComponents.SUSPICIOUS_STEW_EFFECTS, createEffectList(context.getRandom()));
        return stack;
    }

    public static Builder<?> suspiciousStew() {
        return simpleBuilder(SuspiciousStew::new);
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }

    public static SuspiciousStewEffects createEffectList(RandomSource rand) {
        int counter = rand.nextInt(2);
        int max = EFFECTS.length;
        List<Entry> effects = new ArrayList();

        while (counter < max) {
            effects.add(EFFECTS[counter]);
            counter += 1 + rand.nextInt(3);
        }

        return new SuspiciousStewEffects(effects);
    }

    static {
        Entry regeneration = new Entry(MobEffects.REGENERATION, 160);
        Entry weakness = new Entry(MobEffects.WEAKNESS, 320);
        Entry poison = new Entry(MobEffects.POISON, 160);
        Entry healthBoost = new Entry(MobEffects.HEALTH_BOOST, 320);
        Entry blindness = new Entry(MobEffects.BLINDNESS, 120);
        Entry resistance = new Entry(MobEffects.RESISTANCE, 320);
        Entry nausea = new Entry(MobEffects.NAUSEA, 120);
        Entry absorption = new Entry(MobEffects.ABSORPTION, 320);
        Entry hunger = new Entry(MobEffects.HUNGER, 200);
        Entry saturation = new Entry(MobEffects.SATURATION, 80);
        Entry fireResistance = new Entry(MobEffects.FIRE_RESISTANCE, 320);
        Entry strength = new Entry(MobEffects.STRENGTH, 320);
        Entry speed = new Entry(MobEffects.SPEED, 220);
        Entry slowness = new Entry(MobEffects.SLOWNESS, 160);
        Entry miningFatigue = new Entry(MobEffects.MINING_FATIGUE, 160);
        Entry haste = new Entry(MobEffects.HASTE, 320);
        Entry jumpBoost = new Entry(MobEffects.JUMP_BOOST, 160);
        Entry wither = new Entry(MobEffects.WITHER, 80);
        EFFECTS = new Entry[]{
            regeneration,
            weakness,
            poison,
            healthBoost,
            blindness,
            resistance,
            nausea,
            absorption,
            hunger,
            saturation,
            fireResistance,
            strength,
            speed,
            slowness,
            miningFatigue,
            haste,
            jumpBoost,
            wither
        };
    }
}
