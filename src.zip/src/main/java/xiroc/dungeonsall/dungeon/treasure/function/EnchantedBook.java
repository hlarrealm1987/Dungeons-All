package xiroc.dungeonsall.dungeon.treasure.function;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Optional;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction;
import net.minecraft.world.level.storage.loot.functions.LootItemConditionalFunction.Builder;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;

public class EnchantedBook extends LootItemConditionalFunction {
    public static final MapCodec<EnchantedBook> CODEC = RecordCodecBuilder.mapCodec(
        builder -> commonFields(builder)
            .and(Codec.INT.fieldOf("loot_level").forGetter(enchantedBook -> enchantedBook.lootLevel))
            .apply(builder, EnchantedBook::new)
    );
    public int lootLevel;

    public EnchantedBook(java.util.Optional<net.minecraft.core.Holder<LootItemCondition>> conditions, int stage) {
        super(conditions);
        this.lootLevel = stage;
    }

    public ItemStack run(ItemStack stack, LootContext context) {
        return EnchantmentHelper.enchantItem(
            context.getRandom(), new ItemStack(Items.BOOK), 10 + this.lootLevel * 3, context.getLevel().registryAccess(), Optional.empty()
        );
    }

    public static Builder<?> enchantedBook(int lootLevel) {
        return simpleBuilder(conditions -> new EnchantedBook(conditions, lootLevel));
    }

    public MapCodec<? extends LootItemConditionalFunction> codec() {
        return CODEC;
    }
}
