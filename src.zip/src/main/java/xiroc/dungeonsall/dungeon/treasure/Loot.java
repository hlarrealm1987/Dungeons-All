package xiroc.dungeonsall.dungeon.treasure;

import com.google.common.collect.ImmutableSet;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.RandomizableContainer;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.functions.LootItemFunction;
import net.neoforged.neoforge.registries.RegisterEvent.RegisterHelper;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.treasure.function.EnchantedBook;
import xiroc.dungeonsall.dungeon.treasure.function.MaterialBlocks;
import xiroc.dungeonsall.dungeon.treasure.function.RandomItem;
import xiroc.dungeonsall.dungeon.treasure.function.RandomPotion;
import xiroc.dungeonsall.dungeon.treasure.function.Shield;
import xiroc.dungeonsall.dungeon.treasure.function.SuspiciousStew;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.Pair;

public interface Loot {
    String KEY_LOOT_LEVEL = "loot_level";
    ResourceKey<LootTable> CHEST_FOOD = lootTable("chests/food");
    ResourceKey<LootTable> CHEST_SECRET_ROOM = lootTable("chests/secret_room");
    ResourceKey<LootTable> CHEST_SUPPLY = lootTable("chests/supply");
    ResourceKey<LootTable> CHEST_TREASURE = lootTable("chests/treasure");
    ResourceKey<LootTable> CHEST_STAGE_1 = lootTable("chests/stage_1");
    ResourceKey<LootTable> CHEST_STAGE_2 = lootTable("chests/stage_2");
    ResourceKey<LootTable> CHEST_STAGE_3 = lootTable("chests/stage_3");
    ResourceKey<LootTable> CHEST_STAGE_4 = lootTable("chests/stage_4");
    ResourceKey<LootTable> CHEST_STAGE_5 = lootTable("chests/stage_5");
    ResourceKey<LootTable> WITHER_SKELETON = lootTable("monster_overrides/wither_skeleton");
    ImmutableSet<ResourceKey<LootTable>> ALL_LOOT_TABLES = ImmutableSet.<ResourceKey<LootTable>>builder()
        .add(CHEST_FOOD)
        .add(CHEST_SECRET_ROOM)
        .add(CHEST_SUPPLY)
        .add(CHEST_TREASURE)
        .add(CHEST_STAGE_1)
        .add(CHEST_STAGE_2)
        .add(CHEST_STAGE_3)
        .add(CHEST_STAGE_4)
        .add(CHEST_STAGE_5)
        .build();

    static void registerLootFunctions(RegisterHelper<MapCodec<? extends LootItemFunction>> registry) {
        registry.register(DungeonsAll.locate("enchanted_book"), EnchantedBook.CODEC);
        registry.register(DungeonsAll.locate("material_blocks"), MaterialBlocks.CODEC);
        registry.register(DungeonsAll.locate("random_item"), RandomItem.CODEC);
        registry.register(DungeonsAll.locate("random_potion"), RandomPotion.CODEC);
        registry.register(DungeonsAll.locate("shield"), Shield.CODEC);
        registry.register(DungeonsAll.locate("suspicious_stew"), SuspiciousStew.CODEC);
    }

    private static ResourceKey<LootTable> lootTable(String path) {
        return ResourceKey.create(Registries.LOOT_TABLE, DungeonsAll.locate(path));
    }

    static void setLoot(
        LevelAccessor world,
        BlockPos pos,
        RandomizableContainerBlockEntity tile,
        ResourceKey<LootTable> lootTable,
        Theme theme,
        SecondaryTheme secondaryTheme,
        RandomSource rand
    ) {
        RandomizableContainer.setBlockEntityLootTable(world, rand, pos, lootTable);
        setLootInformation(tile.getPersistentData(), theme, secondaryTheme);
    }

    static ResourceKey<LootTable> getLootTable(int lootLevel, RandomSource rand) {
        return switch (lootLevel) {
            case 0 -> rand.nextFloat() < 0.1 ? BuiltInLootTables.JUNGLE_TEMPLE : CHEST_STAGE_1;
            case 1 -> rand.nextFloat() < 0.1 ? BuiltInLootTables.SIMPLE_DUNGEON : CHEST_STAGE_2;
            case 2 -> rand.nextFloat() < 0.1 ? BuiltInLootTables.SIMPLE_DUNGEON : CHEST_STAGE_3;
            case 3 -> rand.nextFloat() < 0.1 ? BuiltInLootTables.STRONGHOLD_CROSSING : CHEST_STAGE_4;
            case 4 -> rand.nextFloat() < 0.1 ? BuiltInLootTables.STRONGHOLD_CROSSING : CHEST_STAGE_5;
            default -> CHEST_STAGE_5;
        };
    }

    static void setLootInformation(CompoundTag nbt, Theme theme, SecondaryTheme secondaryTheme) {
        CompoundTag data = new CompoundTag();
        data.putString("theme", theme.getKey().toString());
        data.putString("secondaryTheme", secondaryTheme.getKey().toString());
        nbt.put("dungeonsall", data);
    }

    static Pair<Theme, SecondaryTheme> getLootInformation(CompoundTag nbt) {
        CompoundTag data = (CompoundTag)nbt.getCompound("dungeonsall").orElseThrow();
        return new Pair<>(
            Theme.getTheme(Identifier.parse((String)data.getString("theme").orElseThrow())),
            Theme.getSecondaryTheme(Identifier.parse((String)data.getString("secondaryTheme").orElseThrow()))
        );
    }
}
