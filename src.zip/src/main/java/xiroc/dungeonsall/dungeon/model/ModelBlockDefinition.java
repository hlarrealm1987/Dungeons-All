package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.util.Pair;

public class ModelBlockDefinition {
    private static final String DIRECTORY = "dev/block_definitions";
    public static final Hashtable<Identifier, ModelBlockDefinition> DEFINITIONS = new Hashtable();
    private static final Hashtable<Block, DungeonModelBlockType> DEFAULT = new Hashtable();
    private static final ModelBlockDefinition DEFAULT_DEFINITION = new ModelBlockDefinition(DEFAULT);
    private static final Identifier DEFAULT_LOCATION = DungeonsAll.locate("default");
    public ModelBlockDefinition fallback;
    private final Hashtable<Block, DungeonModelBlockType> definition;
    private final Hashtable<DungeonModelBlockType, Block> invertedDefinition;
    private static ImmutableSet<Identifier> KEYS;
    private static Builder<Identifier> keySetBuilder;

    public ModelBlockDefinition(Hashtable<Block, DungeonModelBlockType> definition) {
        this.definition = definition;
        this.invertedDefinition = new Hashtable();
        this.definition.forEach((block, type) -> this.invertedDefinition.put(type, block));
    }

    public boolean containsBlock(Block block) {
        return this.definition.containsKey(block);
    }

    public DungeonModelBlockType getType(Block block) {
        return (DungeonModelBlockType)this.definition.getOrDefault(block, DungeonModelBlockType.OTHER);
    }

    public Block getBlock(DungeonModelBlock block) {
        if (block.type == DungeonModelBlockType.OTHER) {
            return (Block)BuiltInRegistries.BLOCK.get(block.blockName).map(Holder::value).orElse(Blocks.CAVE_AIR);
        } else if (block.type == DungeonModelBlockType.CARPET) {
            return block.block != null ? block.block : (Block)Blocks.CARPET.white();
        } else if (this.invertedDefinition.containsKey(block.type)) {
            return (Block)this.invertedDefinition.get(block.type);
        } else {
            return this.fallback != null && this.fallback.invertedDefinition.containsKey(block.type)
                ? (Block)this.fallback.invertedDefinition.get(block.type)
                : Blocks.AIR;
        }
    }

    public static void loadJson(ResourceManager resourceManager) {
        keySetBuilder = new Builder();
        List<Pair<ModelBlockDefinition, Identifier>> referencesToUpdate = Lists.newArrayList();
        resourceManager.listResources("dev/block_definitions", s -> s.getPath().endsWith(".json"))
            .forEach((file, resource) -> loadDefinition(resourceManager, file, referencesToUpdate));

        for (Pair<ModelBlockDefinition, Identifier> reference : referencesToUpdate) {
            Identifier key = reference.right();
            if (DEFINITIONS.containsKey(key)) {
                reference.left().fallback = (ModelBlockDefinition)DEFINITIONS.get(key);
            } else {
                DungeonsAll.LOGGER.warn("Unknown fallback model block definition: {}", key);
            }
        }

        KEYS = keySetBuilder.build();
    }

    private static void loadDefinition(ResourceManager resourceManager, Identifier Identifier, List<Pair<ModelBlockDefinition, Identifier>> referencesToUpdate) {
        DungeonsAll.LOGGER.debug("Loading {}", Identifier);
        Hashtable<Block, DungeonModelBlockType> definition = new Hashtable();
        Resource resource = (Resource)resourceManager.getResource(Identifier).orElseThrow();

        try {
            JsonObject object = JsonParser.parseReader(new InputStreamReader(resource.open())).getAsJsonObject();
            object.getAsJsonObject("definition").entrySet().forEach(entry -> {
                String keyx = (String)entry.getKey();
                Block block = (Block)BuiltInRegistries.BLOCK.get(Identifier.parse(keyx)).map(Holder::value).orElse(null);
                if (block != null) {
                    String value = ((JsonElement)entry.getValue()).getAsString().toUpperCase();
                    if (DungeonModelBlockType.NAME_TO_TYPE.containsKey(value)) {
                        definition.put(block, (DungeonModelBlockType)DungeonModelBlockType.NAME_TO_TYPE.get(value));
                    } else {
                        DungeonsAll.LOGGER.warn("Unknown model block type: {}", value);
                    }
                } else {
                    DungeonsAll.LOGGER.warn("Unknown block: {}", keyx);
                }
            });
            ModelBlockDefinition blockDefinition = new ModelBlockDefinition(definition);
            if (object.has("fallback")) {
                referencesToUpdate.add(new Pair<>(blockDefinition, Identifier.parse(object.get("fallback").getAsString())));
            }

            Identifier key = DungeonsAll.key(Identifier, "dev/block_definitions", ".json");
            DEFINITIONS.put(key, blockDefinition);
            keySetBuilder.add(key);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static ModelBlockDefinition getDefaultDefinition() {
        return (ModelBlockDefinition)DEFINITIONS.getOrDefault(DEFAULT_LOCATION, DEFAULT_DEFINITION);
    }

    public static ImmutableSet<Identifier> getKeys() {
        return KEYS;
    }

    static {
        DEFAULT.put(Blocks.AIR, DungeonModelBlockType.AIR);
        DEFAULT.put(Blocks.CAVE_AIR, DungeonModelBlockType.AIR);
        DEFAULT.put(Blocks.CHEST, DungeonModelBlockType.CHEST);
        DEFAULT.put(Blocks.STONE_BRICK_STAIRS, DungeonModelBlockType.SOLID_STAIRS);
        DEFAULT.put(Blocks.COBBLESTONE, DungeonModelBlockType.GENERIC);
        DEFAULT.put(Blocks.STONE_BRICKS, DungeonModelBlockType.SOLID);
        DEFAULT.put(Blocks.STONE_BRICK_WALL, DungeonModelBlockType.WALL);
        DEFAULT.put(Blocks.PURPUR_PILLAR, DungeonModelBlockType.SOLID_PILLAR);
        DEFAULT.put(Blocks.IRON_BARS, DungeonModelBlockType.FENCING);
        DEFAULT.put(Blocks.WATER, DungeonModelBlockType.FLUID);
        DEFAULT.put(Blocks.OAK_LOG, DungeonModelBlockType.PILLAR);
        DEFAULT.put(Blocks.OAK_PLANKS, DungeonModelBlockType.MATERIAL);
        DEFAULT.put(Blocks.OAK_DOOR, DungeonModelBlockType.DOOR);
        DEFAULT.put(Blocks.OAK_STAIRS, DungeonModelBlockType.MATERIAL_STAIRS);
        DEFAULT.put(Blocks.OAK_SLAB, DungeonModelBlockType.MATERIAL_SLAB);
        DEFAULT.put(Blocks.OAK_BUTTON, DungeonModelBlockType.MATERIAL_BUTTON);
        DEFAULT.put(Blocks.OAK_FENCE, DungeonModelBlockType.FENCE);
        DEFAULT.put(Blocks.OAK_FENCE_GATE, DungeonModelBlockType.FENCE_GATE);
        DEFAULT.put(Blocks.OAK_PRESSURE_PLATE, DungeonModelBlockType.MATERIAL_PRESSURE_PLATE);
        DEFAULT.put(Blocks.OAK_TRAPDOOR, DungeonModelBlockType.TRAPDOOR);
        DEFAULT.put(Blocks.GRAVEL, DungeonModelBlockType.FLOOR);
        DEFAULT.put(Blocks.CRACKED_STONE_BRICKS, DungeonModelBlockType.SOLID_FLOOR);
        DEFAULT.put(Blocks.COBBLESTONE_STAIRS, DungeonModelBlockType.STAIRS);
        DEFAULT.put(Blocks.COBBLESTONE_SLAB, DungeonModelBlockType.SLAB);
        DEFAULT.put(Blocks.SKELETON_SKULL, DungeonModelBlockType.SKULL);
        DEFINITIONS.put(DungeonsAll.locate("builtin/default"), DEFAULT_DEFINITION);
    }
}
