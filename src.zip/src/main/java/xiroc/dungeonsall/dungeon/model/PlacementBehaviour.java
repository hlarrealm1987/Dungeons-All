package xiroc.dungeonsall.dungeon.model;

import java.util.function.BiFunction;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Rotation;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;

public class PlacementBehaviour {
    public static final PlacementBehaviour NON_SOLID = new PlacementBehaviour((world, pos, rotation, rand) -> false);
    public static final PlacementBehaviour SOLID = new PlacementBehaviour((world, pos, rotation, rand) -> true);
    public static final PlacementBehaviour RANDOM_IF_SOLID_NEARBY = new PlacementBehaviour(
        (world, pos, rotation, rand) -> !isSolid(world, pos.north())
                && !isSolid(world, pos.east())
                && !isSolid(world, pos.south())
                && !isSolid(world, pos.west())
            ? false
            : rand.nextFloat() < 0.6F
    );
    public static PlacementBehaviour STRIPES = new PlacementBehaviour((world, pos, rotation, rand) -> {
        if (rotation != Rotation.NONE && rotation != Rotation.CLOCKWISE_180) {
            return switch (pos.getX() % 3) {
                case -2, 2 -> rand.nextFloat() < 0.25F;
                case -1, 1 -> rand.nextFloat() < 0.5F;
                case 0 -> rand.nextFloat() < 0.9F;
                default -> false;
            };
        } else {
            return switch (pos.getZ() % 3) {
                case -2, 2 -> rand.nextFloat() < 0.25F;
                case -1, 1 -> rand.nextFloat() < 0.5F;
                case 0 -> rand.nextFloat() < 0.9F;
                default -> false;
            };
        }
    });
    public static PlacementBehaviour SMALL_GRID = new PlacementBehaviour(
        (world, pos, rotation, rand) -> rand.nextFloat() < 0.95F - Math.abs(pos.getX() % 3) * 0.2F - Math.abs(pos.getZ() % 3) * 0.2F
    );
    public static PlacementBehaviour LARGE_GRID = new PlacementBehaviour(
        (world, pos, rotation, rand) -> rand.nextFloat() < 1.0F - Math.abs(pos.getX() % 6) * 0.1F - Math.abs(pos.getZ() % 6) * 0.1F
    );
    private final PlacementBehaviour.PlacementFunction function;
    @Nullable
    public final BiFunction<Theme, SecondaryTheme, BlockStateProvider> airBlock;

    public PlacementBehaviour(PlacementBehaviour.PlacementFunction function) {
        this(function, null);
    }

    public PlacementBehaviour(PlacementBehaviour.PlacementFunction function, BiFunction<Theme, SecondaryTheme, BlockStateProvider> airBlock) {
        this.function = function;
        this.airBlock = airBlock;
    }

    public PlacementBehaviour withAirBlock(BiFunction<Theme, SecondaryTheme, BlockStateProvider> airBlock) {
        return new PlacementBehaviour(this.function, airBlock);
    }

    public boolean isSolid(LevelAccessor world, BlockPos pos, Rotation pieceRotation, RandomSource rand) {
        return this.function.isSolid(world, pos, pieceRotation, rand);
    }

    private static boolean isSolid(LevelAccessor world, BlockPos pos) {
        return !world.hasChunk(pos.getX() >> 4, pos.getZ() >> 4)
            ? false
            : world.getBlockState(pos).canOcclude() || world.getBlockState(pos.below()).canOcclude();
    }

    public interface PlacementFunction {
        boolean isSolid(LevelAccessor var1, BlockPos var2, Rotation var3, RandomSource var4);
    }
}
