package xiroc.dungeonsall.dungeon.model;

import com.google.gson.JsonObject;
import java.util.Collection;
import net.minecraft.resources.Identifier;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.WeightedRandom;

public class ModelSelector {
    public WeightedRandom<DungeonModel> rooms;
    public WeightedRandom<DungeonModel> fullNodes;
    public WeightedRandom<DungeonModel> forkNodes;
    public WeightedRandom<DungeonModel> straightNodes;
    public WeightedRandom<DungeonModel> turnNodes;
    public WeightedRandom<DungeonModel> deadEndNodes;
    public WeightedRandom<DungeonModel> corridors;
    public WeightedRandom<DungeonModel> corridorLinkers;
    public WeightedRandom<DungeonModel> nodeConnectors;

    public ModelSelector(
        WeightedRandom<DungeonModel> rooms,
        WeightedRandom<DungeonModel> fullNodes,
        WeightedRandom<DungeonModel> forkNodes,
        WeightedRandom<DungeonModel> straightNodes,
        WeightedRandom<DungeonModel> turnNodes,
        WeightedRandom<DungeonModel> deadEndNodes,
        WeightedRandom<DungeonModel> corridors,
        WeightedRandom<DungeonModel> corridorLinkers,
        WeightedRandom<DungeonModel> nodeConnectors
    ) {
        this.rooms = rooms;
        this.fullNodes = fullNodes;
        this.forkNodes = forkNodes;
        this.straightNodes = straightNodes;
        this.turnNodes = turnNodes;
        this.deadEndNodes = deadEndNodes;
        this.nodeConnectors = nodeConnectors;
        this.corridors = corridors;
        this.corridorLinkers = corridorLinkers;
    }

    public static ModelSelector fromJson(JsonObject object, Identifier resource) {
        return new ModelSelector(
            loadRandom("rooms", object, resource),
            loadRandom("full_nodes", object, resource),
            loadRandom("fork_nodes", object, resource),
            loadRandom("straight_nodes", object, resource),
            loadRandom("turn_nodes", object, resource),
            loadRandom("dead_end_nodes", object, resource),
            loadRandom("corridors", object, resource),
            loadRandom("corridor_linkers", object, resource),
            loadRandom("node_connectors", object, resource)
        );
    }

    public static WeightedRandom<DungeonModel> loadRandom(String name, JsonObject object, Identifier resource) {
        WeightedRandom.Builder<DungeonModel> builder = new WeightedRandom.Builder<>();
        JsonObject models = object.getAsJsonObject(name);
        if (models.has("inherit")) {
            models.getAsJsonArray("inherit").forEach(element -> {
                String key = element.getAsString();
                if (ModelPools.POOLS.containsKey(key)) {
                    builder.addAll((Collection<Pair<DungeonModel, Integer>>)ModelPools.POOLS.get(key));
                } else {
                    throw new DatapackLoadException("Unknown model pool " + key + " in " + resource);
                }
            });
        }

        if (models.has("models")) {
            models.getAsJsonArray("models").forEach(element -> {
                JsonObject entry = element.getAsJsonObject();
                Identifier key = Identifier.parse(entry.get("key").getAsString());
                if (DungeonModels.KEY_TO_MODEL.containsKey(key)) {
                    builder.add((DungeonModel)DungeonModels.KEY_TO_MODEL.get(key), JSONUtils.getWeight(entry));
                } else {
                    throw new DatapackLoadException("Unknown model key " + key + " in " + resource);
                }
            });
        }

        if (builder.entries.isEmpty()) {
            throw new DatapackLoadException("Empty model list " + name + " in " + resource);
        } else {
            return builder.build();
        }
    }
}
