package xiroc.dungeonsall.dungeon.model;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.DungeonsAll;

public class ModelHandler {
    public static final byte LATEST_MODEL_FORMAT = 1;

    public static void readAndSaveModelToFile(String name, ModelBlockDefinition definition, Level world, BlockPos pos, int width, int height, int length) {
        DungeonsAll.LOGGER.info("Reading and saving {} to disk. Size: {}, {}, {}", name, width, height, length);
        List<DungeonModelBlock> blocks = new ArrayList();

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                for (int z = 0; z < length; z++) {
                    BlockPos position = new BlockPos(pos.getX() + x, pos.getY() + y, pos.getZ() + z);
                    BlockState state = world.getBlockState(position);
                    Block block = state.getBlock();
                    if (block != Blocks.BARRIER) {
                        blocks.add(DungeonModelBlock.fromBlockState(state, DungeonModelBlockType.get(block, definition), new Vec3i(x, y, z)));
                    }
                }
            }
        }

        writeToFile(toNbt(blocks, width, height, length), ((ServerLevel)world).getServer().getServerDirectory().toAbsolutePath() + "/models/" + name + ".nbt");
        DungeonsAll.LOGGER.info("Done.");
    }

    public static void writeToFile(CompoundTag nbt, String path) {
        try {
            DungeonsAll.LOGGER.info("Writing a model to disk at {}. ", path);
            File file = new File(path);
            Files.createDirectories(file.getParentFile().toPath(), new FileAttribute[0]);
            Files.deleteIfExists(file.toPath());
            Files.createFile(file.toPath(), new FileAttribute[0]);
            NbtIo.writeCompressed(nbt, new FileOutputStream(file));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static CompoundTag toNbt(List<DungeonModelBlock> blocks, int width, int height, int length) {
        CompoundTag nbt = new CompoundTag();
        nbt.putByte("format", (byte)1);
        nbt.putByte("width", (byte)width);
        nbt.putByte("height", (byte)height);
        nbt.putByte("length", (byte)length);
        ListTag _blocks = new ListTag();
        blocks.forEach(block -> _blocks.add(block.toNBT()));
        nbt.put("blocks", _blocks);
        return nbt;
    }

    public static DungeonModel loadModelFromNBT(CompoundTag nbt, Identifier file, Identifier key) {
        int format = (Integer)nbt.getInt("format").orElseThrow();
        return format == 1 ? ModelLoader.VERSION_1.load(nbt, file, key) : ModelLoader.LEGACY.load(nbt, file, key);
    }
}
