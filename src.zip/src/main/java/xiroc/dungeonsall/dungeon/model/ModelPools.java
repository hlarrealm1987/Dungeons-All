package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Hashtable;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Pair;

public class ModelPools {
    public static final Hashtable<String, ImmutableSet<Pair<DungeonModel, Integer>>> POOLS = new Hashtable();
    private static final Identifier FILE = DungeonsAll.locate("dungeon/model_pools.json");

    public static void load(ResourceManager resourceManager) {
        DungeonsAll.LOGGER.debug("Loading {}", FILE);
        POOLS.clear();

        try {
            JsonObject file = JsonParser.parseReader(
                    new InputStreamReader(
                        ((Resource)resourceManager.getResource(FILE).orElseThrow(() -> new DatapackLoadException("Missing file: " + FILE))).open()
                    )
                )
                .getAsJsonObject();
            JsonObject pools = file.getAsJsonObject("pools");
            pools.entrySet().forEach(entry -> {
                Builder<Pair<DungeonModel, Integer>> builder = new Builder();
                ((JsonElement)entry.getValue()).getAsJsonArray().forEach(element -> {
                    JsonObject modelEntry = element.getAsJsonObject();
                    Identifier key = Identifier.parse(modelEntry.get("key").getAsString());
                    if (!DungeonModels.KEY_TO_MODEL.containsKey(key)) {
                        DungeonsAll.LOGGER.warn("Cannot resolve model key " + key + " in " + FILE);
                    } else {
                        builder.add(new Pair<>((DungeonModel)DungeonModels.KEY_TO_MODEL.get(key), JSONUtils.getWeight(modelEntry)));
                    }
                });
                ImmutableSet<Pair<DungeonModel, Integer>> pool = builder.build();
                if (pool.isEmpty()) {
                    throw new DatapackLoadException("Empty model pool " + (String)entry.getKey() + " in " + FILE);
                }

                POOLS.put((String)entry.getKey(), pool);
            });
        } catch (IOException e) {
            DungeonsAll.LOGGER.error("Failed to load " + FILE);
            e.printStackTrace();
        }
    }
}
