package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.storage.loot.LootTable;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.util.JSONUtils;

public class DungeonModel {
    private final Identifier key;
    public final int width;
    public final int height;
    public final int length;
    public final ImmutableList<DungeonModelBlock> blocks;
    @Nullable
    private Integer id;
    @Nullable
    private List<MultipartModelData> multipartData;
    private int entranceType;
    private Vec3i offset;
    private Vec3i rotatedOffset;
    @Nullable
    private DungeonModelFeature[] features;
    @Nullable
    private ResourceKey<LootTable> lootTable;
    private boolean hasId = false;
    private boolean hasFeatures = false;
    private boolean hasMultipart = false;
    private boolean variation = false;

    public DungeonModel(Identifier key, ImmutableList<DungeonModelBlock> blocks, int width, int height, int length) {
        this.key = key;
        this.blocks = blocks;
        this.width = width;
        this.height = height;
        this.length = length;
        this.offset = DungeonModels.NO_OFFSET;
        this.rotatedOffset = DungeonModels.NO_OFFSET;
    }

    public List<DungeonModelBlock> getBlocks() {
        return this.blocks;
    }

    public void loadMetadata(JsonObject object, Identifier file) throws JsonParseException {
        if (object.has("id")) {
            this.id = object.get("id").getAsInt();
            this.hasId = true;
        }

        if (object.has("offset")) {
            JsonObject offset = object.getAsJsonObject("offset");
            this.offset = JSONUtils.getOffset(offset);
            if (offset.has("rotate") && offset.get("rotate").getAsBoolean()) {
                this.rotatedOffset = new Vec3i(this.offset.getZ(), this.offset.getY(), this.offset.getX());
            } else {
                this.rotatedOffset = this.offset;
            }
        }

        if (object.has("entrance_type") && object.get("entrance_type").getAsString().equals("secondary")) {
            this.entranceType = 1;
        }

        if (object.has("features")) {
            JsonArray array = object.getAsJsonArray("features");
            this.features = new DungeonModelFeature[array.size()];

            for (int i = 0; i < array.size(); i++) {
                this.features[i] = DungeonModelFeature.fromJson(array.get(i).getAsJsonObject(), file);
            }

            this.hasFeatures = true;
        }

        if (object.has("variation")) {
            this.variation = object.get("variation").getAsBoolean();
        }

        if (object.has("loot")) {
            this.lootTable = ResourceKey.create(Registries.LOOT_TABLE, Identifier.parse(object.get("loot").getAsString()));
        }

        if (object.has("multipart")) {
            List<MultipartModelData> multipartData = parseMultipartData(object.getAsJsonObject("multipart"), file);
            if (multipartData != null) {
                this.multipartData = multipartData;
                this.hasMultipart = true;
            }
        }
    }

    @Nullable
    public static List<MultipartModelData> parseMultipartData(JsonObject multipartData, Identifier file) {
        if (multipartData.size() > 0) {
            ArrayList<MultipartModelData> list = new ArrayList();
            multipartData.entrySet()
                .forEach(
                    entry -> {
                        MultipartModelData multipartModelData = MultipartModelData.fromJson(
                            (String)entry.getKey(), ((JsonElement)entry.getValue()).getAsJsonObject(), file
                        );
                        if (multipartModelData != null) {
                            list.add(multipartModelData);
                        }
                    }
                );
            return list;
        } else {
            return null;
        }
    }

    public Identifier getKey() {
        return this.key;
    }

    public int getEntranceType() {
        return this.entranceType;
    }

    public boolean hasLootTable() {
        return this.lootTable != null;
    }

    @Nullable
    public ResourceKey<LootTable> getLootTable() {
        return this.lootTable;
    }

    public BoundingBox createBoundingBox(int x, int y, int z, Rotation rotation) {
        switch (rotation) {
            case NONE:
            case CLOCKWISE_180:
                return new BoundingBox(x, y, z, x + this.width - 1, y + this.height - 1, z + this.length - 1);
            case CLOCKWISE_90:
            case COUNTERCLOCKWISE_90:
                return new BoundingBox(x, y, z, x + this.length - 1, y + this.height - 1, z + this.width - 1);
            default:
                DungeonsAll.LOGGER.warn("Unknown piece rotation: {}", rotation);
                return new BoundingBox(x, y, z, x + this.width - 1, y + this.height - 1, z + this.length - 1);
        }
    }

    public BoundingBox createBoundingBoxWithOffset(int x, int y, int z, Rotation rotation) {
        Vec3i offset = this.getOffset(rotation);
        return this.createBoundingBox(x + offset.getX(), y + offset.getY(), z + offset.getZ(), rotation);
    }

    public BoundingBox createBoundingBox(BlockPos origin, Rotation rotation) {
        switch (rotation) {
            case NONE:
            case CLOCKWISE_180:
                return new BoundingBox(
                    origin.getX(),
                    origin.getY(),
                    origin.getZ(),
                    origin.getX() + this.width - 1,
                    origin.getY() + this.height - 1,
                    origin.getZ() + this.length - 1
                );
            case CLOCKWISE_90:
            case COUNTERCLOCKWISE_90:
                return new BoundingBox(
                    origin.getX(),
                    origin.getY(),
                    origin.getZ(),
                    origin.getX() + this.length - 1,
                    origin.getY() + this.height - 1,
                    origin.getZ() + this.width - 1
                );
            default:
                DungeonsAll.LOGGER.warn("Unknown piece rotation: {}", rotation);
                return new BoundingBox(
                    origin.getX(),
                    origin.getY(),
                    origin.getZ(),
                    origin.getX() + this.width - 1,
                    origin.getY() + this.height - 1,
                    origin.getZ() + this.length - 1
                );
        }
    }

    public Vec3i getOffset() {
        return this.offset;
    }

    public Vec3i getOffset(Rotation rotation) {
        return (rotation.ordinal() & 1) == 1 ? this.rotatedOffset : this.offset;
    }

    public boolean hasId() {
        return this.hasId;
    }

    public boolean hasFeatures() {
        return this.hasFeatures;
    }

    public boolean hasMultipart() {
        return this.hasMultipart;
    }

    public boolean isVariationEnabled() {
        return this.variation;
    }

    @Nullable
    public DungeonModelFeature[] getFeatures() {
        return this.features;
    }

    @Nullable
    public List<MultipartModelData> getMultipartData() {
        return this.multipartData;
    }

    @Nullable
    public Integer getId() {
        return this.id;
    }

    public String toString() {
        return "{key=" + this.key + "}";
    }
}
