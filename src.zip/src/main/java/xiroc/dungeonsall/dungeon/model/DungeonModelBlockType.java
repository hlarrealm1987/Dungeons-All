package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import java.util.function.Function;
import javax.annotation.Nonnull;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import xiroc.dungeonsall.dungeon.PlacementConfiguration;
import xiroc.dungeonsall.dungeon.block.DungeonBlocks;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;

public enum DungeonModelBlockType {
    AIR((block, rotation, world, pos, theme, subTheme, rand, variation, stage) -> DungeonBlocks.CAVE_AIR),
    SOLID(tFactory(Theme::getSolid), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getSolid).expandable().placement(PlacementBehaviour.SOLID)),
    SOLID_STAIRS(
        tFactory(Theme::getSolidStairs), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getSolidStairs).placement(PlacementBehaviour.SOLID)
    ),
    SOLID_SLAB(tFactory(Theme::getSolidSlab), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getSolidSlab).placement(PlacementBehaviour.SOLID)),
    GENERIC(tFactory(Theme::getGeneric), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getGeneric).expandable()),
    GENERIC_OR_FENCING(
        tFactory(Theme::getGeneric),
        new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getGenericOrFencing)
            .placement(PlacementBehaviour.NON_SOLID.withAirBlock((theme, secondaryTheme) -> theme.getFencing()))
    ),
    SLAB(tFactory(Theme::getSlab), PlacementConfiguration::getSlab),
    SOLID_PILLAR(
        tFactory(Theme::getPillar),
        new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getSolidPillar).expandable().pillar().placement(PlacementBehaviour.SOLID)
    ),
    SOLID_FLOOR(
        tFactory(Theme::getFloor),
        new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getSolidFloor).expandable().placement(PlacementBehaviour.SOLID)
    ),
    FENCING(tFactory(Theme::getFencing), PlacementConfiguration::getFencing),
    FLOOR(tFactory(Theme::getFloor), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getFloor).placement(PlacementBehaviour.SMALL_GRID)),
    FLUID(tFactory(Theme::getFluid), PlacementConfiguration::getFluid),
    LOOSE_GROUND(tFactory(Theme::getFloor), PlacementConfiguration::getLooseGround),
    STAIRS(tFactory(Theme::getStairs), PlacementConfiguration::getStairs),
    WALL(tFactory(Theme::getWall), PlacementConfiguration::getWall),
    PILLAR(sFactory(SecondaryTheme::getPillar), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getPillar).expandable().pillar()),
    MATERIAL_STAIRS(sFactory(SecondaryTheme::getStairs), PlacementConfiguration::getStairs),
    TRAPDOOR(sFactory(SecondaryTheme::getTrapDoor), PlacementConfiguration::getTrapdoor),
    DOOR(sFactory(SecondaryTheme::getDoor), PlacementConfiguration::getDoor),
    FENCE(sFactory(SecondaryTheme::getFence), PlacementConfiguration::getFence),
    FENCE_GATE(sFactory(SecondaryTheme::getFenceGate), PlacementConfiguration::getFenceGate),
    MATERIAL_SLAB(sFactory(SecondaryTheme::getSlab), PlacementConfiguration::getSlab),
    MATERIAL_BUTTON(sFactory(SecondaryTheme::getButton), PlacementConfiguration::getMaterialButton),
    MATERIAL_PRESSURE_PLATE(sFactory(SecondaryTheme::getPressurePlate), PlacementConfiguration::getMaterialPressurePlate),
    MATERIAL(sFactory(SecondaryTheme::getMaterial), new DungeonModelBlockType.TypeBuilder(PlacementConfiguration::getMaterial).expandable()),
    CHEST(
        (block, rotation, world, pos, theme, subTheme, rand, variation, stage) -> block.create(Blocks.CHEST.defaultBlockState(), world, pos, rotation),
        PlacementConfiguration::getChest
    ),
    SKULL((block, rotation, world, pos, theme, subTheme, rand, variation, stage) -> {
        BlockState state = block.create(Blocks.SKELETON_SKULL.defaultBlockState(), world, pos, rotation);
        if (state.hasProperty(BlockStateProperties.ROTATION_16)) {
            int r = (Integer)state.getValue(BlockStateProperties.ROTATION_16);
            int add = rand.nextInt(3);
            if (rand.nextBoolean()) {
                r -= add;
                if (r < 0) {
                    r += 16;
                }
            } else {
                r = (r + add) % 16;
            }

            return (BlockState)state.setValue(BlockStateProperties.ROTATION_16, r);
        } else {
            return state;
        }
    }, PlacementConfiguration::getSkull),
    CARPET(
        (block, rotation, world, pos, theme, subTheme, rand, variation, stage) -> {
            Block b = block.variation != null && variation != null
                ? DungeonBlocks.CARPET[(block.variation + variation[block.variation % variation.length]) % DungeonBlocks.CARPET.length]
                : (Block)BuiltInRegistries.BLOCK.get(block.blockName).map(Holder::value).orElse(Blocks.CAVE_AIR);
            if (b == null) {
                b = DungeonBlocks.CARPET[rand.nextInt(DungeonBlocks.CARPET.length)];
            }

            return block.create(b.defaultBlockState());
        },
        PlacementConfiguration::getCarpet
    ),
    OTHER(
        (block, rotation, world, pos, theme, subTheme, rand, variation, stage) -> block.create(block.getBlock().defaultBlockState(), world, pos, rotation),
        PlacementConfiguration::getOther
    );

    public static final ImmutableMap<String, DungeonModelBlockType> NAME_TO_TYPE;
    public final DungeonModelBlockType.BlockFactory blockFactory;
    public final PlacementBehaviour defaultPlacementBehavior;
    public final Function<PlacementConfiguration, PlacementBehaviour> placementBehaviourFromConfig;
    private final boolean isPillar;
    private final boolean expandable;

    DungeonModelBlockType(DungeonModelBlockType.BlockFactory blockFactory) {
        this(blockFactory, config -> PlacementBehaviour.NON_SOLID);
    }

    DungeonModelBlockType(DungeonModelBlockType.BlockFactory blockFactory, Function<PlacementConfiguration, PlacementBehaviour> placementBehaviourFromConfig) {
        this(blockFactory, new DungeonModelBlockType.TypeBuilder(placementBehaviourFromConfig));
    }

    DungeonModelBlockType(DungeonModelBlockType.BlockFactory blockFactory, DungeonModelBlockType.TypeBuilder typeBuilder) {
        this.blockFactory = blockFactory;
        this.defaultPlacementBehavior = typeBuilder.defaultPlacementBehaviour;
        this.placementBehaviourFromConfig = typeBuilder.placementBehaviourFromConfig;
        this.isPillar = typeBuilder.isPillar;
        this.expandable = typeBuilder.expandable;
    }

    public boolean isPillar() {
        return this.isPillar;
    }

    public boolean isExpandable() {
        return this.expandable;
    }

    public static DungeonModelBlockType get(Block block, ModelBlockDefinition definition) {
        if (definition.containsBlock(block)) {
            return definition.getType(block);
        } else {
            return definition.fallback != null && definition.fallback.containsBlock(block) ? definition.fallback.getType(block) : OTHER;
        }
    }

    private static DungeonModelBlockType.BlockFactory tFactory(Function<Theme, BlockStateProvider> blockSelector) {
        return (block, rotation, world, pos, theme, secondaryTheme, rand, variation, stage) -> block.create(
            ((BlockStateProvider)blockSelector.apply(theme)).get(world, pos, rand, rotation), world, pos, rotation
        );
    }

    private static DungeonModelBlockType.BlockFactory sFactory(Function<SecondaryTheme, BlockStateProvider> blockSelector) {
        return (block, rotation, world, pos, theme, secondaryTheme, rand, variation, stage) -> block.create(
            ((BlockStateProvider)blockSelector.apply(secondaryTheme)).get(world, pos, rand, rotation), world, pos, rotation
        );
    }

    static {
        Builder<String, DungeonModelBlockType> builder = new Builder();

        for (DungeonModelBlockType type : values()) {
            builder.put(type.name(), type);
        }

        builder.put("NORMAL", GENERIC);
        builder.put("VANILLA_WALL", WALL);
        builder.put("WOODEN_BUTTON", MATERIAL_BUTTON);
        builder.put("WOODEN_SLAB", MATERIAL_SLAB);
        builder.put("WOODEN_PRESSURE_PLATE", MATERIAL_PRESSURE_PLATE);
        builder.put("NORMAL_2", AIR);
        builder.put("GENERIC_SECONDARY", AIR);
        builder.put("SPAWNER", AIR);
        builder.put("BARREL", AIR);
        NAME_TO_TYPE = builder.build();
    }

    @FunctionalInterface
    public interface BlockFactory {
        BlockState get(
            DungeonModelBlock var1, Rotation var2, LevelAccessor var3, BlockPos var4, Theme var5, SecondaryTheme var6, RandomSource var7, byte[] var8, int var9
        );
    }

    private static class TypeBuilder {
        private PlacementBehaviour defaultPlacementBehaviour;
        private Function<PlacementConfiguration, PlacementBehaviour> placementBehaviourFromConfig;
        private boolean expandable;
        private boolean isPillar;

        private TypeBuilder(Function<PlacementConfiguration, PlacementBehaviour> placementBehaviourFromConfig) {
            this.placementBehaviourFromConfig = placementBehaviourFromConfig;
            this.defaultPlacementBehaviour = PlacementBehaviour.NON_SOLID;
            this.expandable = false;
            this.isPillar = false;
        }

        public DungeonModelBlockType.TypeBuilder placement(@Nonnull PlacementBehaviour placementBehaviour) {
            this.defaultPlacementBehaviour = placementBehaviour;
            return this;
        }

        public DungeonModelBlockType.TypeBuilder expandable() {
            this.expandable = true;
            return this;
        }

        public DungeonModelBlockType.TypeBuilder pillar() {
            this.isPillar = true;
            return this;
        }
    }
}
