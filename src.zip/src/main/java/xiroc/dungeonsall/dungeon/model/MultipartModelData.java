package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.core.Vec3i;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Rotation;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.piece.DungeonMultipartModelPiece;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Orientation;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.ResourceReloadHandler;
import xiroc.dungeonsall.util.Updatable;
import xiroc.dungeonsall.util.WeightedRandom;

public class MultipartModelData {
    public final List<MultipartModelData.Condition<?>> conditions;
    public WeightedRandom<MultipartModelData.Instance> models;
    @Nullable
    public WeightedRandom<MultipartModelData.Instance> alternatives;
    public final String name;

    private MultipartModelData(String name) {
        this.name = name;
        this.conditions = new ArrayList();
        this.models = null;
        this.alternatives = null;
    }

    public MultipartModelData combine(
        @Nullable List<Pair<MultipartModelData.Instance, Integer>> models, @Nullable List<Pair<MultipartModelData.Instance, Integer>> alternatives
    ) {
        MultipartModelData result = new MultipartModelData(this.name);
        result.conditions.addAll(this.conditions);
        if (models != null) {
            ImmutableList<Pair<MultipartModelData.Instance, Integer>> base = this.models.getEntries();
            List<Pair<MultipartModelData.Instance, Integer>> combined = new ArrayList(base.size() + models.size());
            combined.addAll(base);
            combined.addAll(models);
            result.models = new WeightedRandom<>(combined);
        } else {
            result.models = this.models;
        }

        if (alternatives != null) {
            if (this.alternatives != null) {
                ImmutableList<Pair<MultipartModelData.Instance, Integer>> base = this.alternatives.getEntries();
                List<Pair<MultipartModelData.Instance, Integer>> combined = new ArrayList(base.size() + alternatives.size());
                combined.addAll(base);
                combined.addAll(alternatives);
                result.alternatives = new WeightedRandom<>(combined);
            } else {
                result.alternatives = new WeightedRandom<>(alternatives);
            }
        } else {
            result.alternatives = this.alternatives;
        }

        return result;
    }

    public static MultipartModelData fromJson(String name, JsonObject object, Identifier file) {
        MultipartModelData multipartModelData = new MultipartModelData(name);
        if (object.has("conditions")) {
            JsonObject jsonConditions = object.getAsJsonObject("conditions");
            jsonConditions.entrySet().forEach(entry -> {
                MultipartModelData.Condition<?> condition = MultipartModelData.Condition.fromJson((JsonElement)entry.getValue(), (String)entry.getKey());
                if (condition != null) {
                    multipartModelData.conditions.add(condition);
                }
            });
            if (multipartModelData.conditions.isEmpty()) {
                DungeonsAll.LOGGER.warn("Multipart metadata in {} has an empty or incorrect condition set.", file);
            }
        }

        if (object.has("models")) {
            WeightedRandom<MultipartModelData.Instance> models = getInstancesFromJson(object.getAsJsonArray("models"), file);
            if (models == null) {
                DungeonsAll.LOGGER.warn("Multipart metadata has an empty model list");
                return null;
            }

            multipartModelData.models = models;
            if (object.has("alternatives")) {
                multipartModelData.alternatives = getInstancesFromJson(object.getAsJsonArray("alternatives"), file);
                if (multipartModelData.conditions == null) {
                    DungeonsAll.LOGGER.warn("Multipart metadata has an alternative model set but no conditions");
                }
            }

            return multipartModelData;
        } else {
            DungeonsAll.LOGGER.warn("Multipart metadata does not have a model list");
            return null;
        }
    }

    @Nullable
    private static WeightedRandom<MultipartModelData.Instance> getInstancesFromJson(JsonArray array, Identifier file) {
        List<Pair<MultipartModelData.Instance, Integer>> entries = getRawInstancesFromJson(array, file);
        return entries.isEmpty() ? null : new WeightedRandom<>(entries);
    }

    public static List<Pair<MultipartModelData.Instance, Integer>> getRawInstancesFromJson(JsonArray array, Identifier file) {
        ArrayList<Pair<MultipartModelData.Instance, Integer>> list = new ArrayList();
        array.forEach(element -> {
            JsonObject object1 = element.getAsJsonObject();
            MultipartModelData.Instance data = MultipartModelData.Instance.fromJson(object1, file);
            list.add(new Pair<>(data, JSONUtils.getWeight(object1)));
            if (data != MultipartModelData.Instance.EMPTY) {
                ResourceReloadHandler.PENDING_UPDATES.add(data);
            }
        });
        return list;
    }

    public boolean checkConditions(DungeonPiece piece) {
        if (!this.conditions.isEmpty()) {
            for (MultipartModelData.Condition<?> condition : this.conditions) {
                if (!condition.isMet(piece)) {
                    return false;
                }
            }
        }

        return true;
    }

    private record Condition<T>(MultipartModelData.Property<T> property, T value) {
        @Nullable
        public static MultipartModelData.Condition<?> fromJson(JsonElement element, String name) {
            return switch (name) {
                case "north" -> new MultipartModelData.Condition((MultipartModelData.Property<T>)MultipartModelData.Property.NORTH, (T)element.getAsBoolean());
                case "east" -> new MultipartModelData.Condition((MultipartModelData.Property<T>)MultipartModelData.Property.EAST, (T)element.getAsBoolean());
                case "south" -> new MultipartModelData.Condition((MultipartModelData.Property<T>)MultipartModelData.Property.SOUTH, (T)element.getAsBoolean());
                case "west" -> new MultipartModelData.Condition((MultipartModelData.Property<T>)MultipartModelData.Property.WEST, (T)element.getAsBoolean());
                case "rotated_north" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.ROTATED_NORTH, (T)element.getAsBoolean()
                );
                case "rotated_east" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.ROTATED_EAST, (T)element.getAsBoolean()
                );
                case "rotated_south" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.ROTATED_SOUTH, (T)element.getAsBoolean()
                );
                case "rotated_west" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.ROTATED_WEST, (T)element.getAsBoolean()
                );
                case "multipart_north" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.MULTIPART_NORTH, (T)element.getAsBoolean()
                );
                case "multipart_east" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.MULTIPART_EAST, (T)element.getAsBoolean()
                );
                case "multipart_south" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.MULTIPART_SOUTH, (T)element.getAsBoolean()
                );
                case "multipart_west" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.MULTIPART_WEST, (T)element.getAsBoolean()
                );
                case "straight" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.STRAIGHT, (T)element.getAsBoolean()
                );
                case "connections" -> new MultipartModelData.Condition(
                    (MultipartModelData.Property<T>)MultipartModelData.Property.CONNECTIONS, (T)element.getAsInt()
                );
                case "stage" -> new MultipartModelData.Condition((MultipartModelData.Property<T>)MultipartModelData.Property.STAGE, (T)element.getAsInt());
                default -> null;
            };
        }

        public boolean isMet(DungeonPiece piece) {
            T t = this.property.get(piece);
            return t != null && t.equals(this.value);
        }
    }

    public static class Instance implements Updatable {
        public static final MultipartModelData.Instance EMPTY = new MultipartModelData.Instance(null, null, DungeonModels.NO_OFFSET, Rotation.NONE);
        public final Vec3i offset;
        public final Rotation rotation;
        private final Identifier file;
        @Nullable
        public DungeonModel model;
        private final Identifier key;

        public Instance(Identifier file, Identifier key, Vec3i offset, Rotation rotation) {
            this.file = file;
            this.key = key;
            this.offset = offset;
            this.rotation = rotation;
        }

        public DungeonMultipartModelPiece createMultipartPiece(
            DungeonPiece parentPiece, DungeonModel parent, Rotation rotation, int x, int y, int z, RandomSource rand
        ) {
            if (this.model != null) {
                DungeonMultipartModelPiece piece = new DungeonMultipartModelPiece();
                Rotation fullRotation = this.rotation.getRotated(rotation);
                Vec3i rotatedOffset = Orientation.rotatedMultipartOffset(parent, this.model, this.offset, rotation, fullRotation);
                piece.setWorldPosition(x + rotatedOffset.getX(), y + rotatedOffset.getY(), z + rotatedOffset.getZ());
                piece.model = this.model;
                piece.rotation = fullRotation;
                piece.stage = parentPiece.stage;
                piece.theme = parentPiece.theme;
                piece.secondaryTheme = parentPiece.secondaryTheme;
                piece.createBoundingBox();
                piece.setup(rand);
                return piece;
            } else {
                throw new RuntimeException("Can't create a multipart piece without a model. Metadata file: " + this.file.toString());
            }
        }

        @Override
        public void update() {
            if (this != EMPTY) {
                this.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(this.key);
                if (this.model == null) {
                    throw new RuntimeException("Cannot resolve model key " + this.key + " in " + this.file.toString());
                }
            }
        }

        public static MultipartModelData.Instance fromJson(JsonObject object, Identifier file) {
            if (object.has("model")) {
                Vec3i offset = object.has("offset") ? JSONUtils.getOffset(object.getAsJsonObject("offset")) : DungeonModels.NO_OFFSET;
                Rotation rotation = object.has("rotation") ? Rotation.valueOf(object.get("rotation").getAsString().toUpperCase(Locale.ROOT)) : Rotation.NONE;
                return new MultipartModelData.Instance(file, Identifier.parse(object.get("model").getAsString()), offset, rotation);
            } else {
                return EMPTY;
            }
        }
    }

    @FunctionalInterface
    private interface Property<T> {
        MultipartModelData.Property<Boolean> NORTH = piece -> piece.sides[0];
        MultipartModelData.Property<Boolean> EAST = piece -> piece.sides[1];
        MultipartModelData.Property<Boolean> SOUTH = piece -> piece.sides[2];
        MultipartModelData.Property<Boolean> WEST = piece -> piece.sides[3];
        MultipartModelData.Property<Boolean> ROTATED_NORTH = piece -> piece.sides[Orientation.rotationAsInt(piece.rotation)];
        MultipartModelData.Property<Boolean> ROTATED_EAST = piece -> piece.sides[(1 + Orientation.rotationAsInt(piece.rotation)) % 4];
        MultipartModelData.Property<Boolean> ROTATED_SOUTH = piece -> piece.sides[(2 + Orientation.rotationAsInt(piece.rotation)) % 4];
        MultipartModelData.Property<Boolean> ROTATED_WEST = piece -> piece.sides[(3 + Orientation.rotationAsInt(piece.rotation)) % 4];
        MultipartModelData.Property<Boolean> MULTIPART_NORTH = piece -> false;
        MultipartModelData.Property<Boolean> MULTIPART_EAST = piece -> false;
        MultipartModelData.Property<Boolean> MULTIPART_SOUTH = piece -> false;
        MultipartModelData.Property<Boolean> MULTIPART_WEST = piece -> false;
        MultipartModelData.Property<Boolean> STRAIGHT = piece -> piece.sides[0] && piece.sides[2] || piece.sides[1] && piece.sides[3];
        MultipartModelData.Property<Integer> CONNECTIONS = piece -> piece.connectedSides;
        MultipartModelData.Property<Integer> STAGE = piece -> piece.stage;

        @Nullable
        T get(DungeonPiece var1);
    }
}
