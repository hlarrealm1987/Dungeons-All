package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.ImmutableSet.Builder;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.util.Hashtable;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.jline.utils.InputStreamReader;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.exception.DatapackLoadException;

public class DungeonModels {
    public static final Hashtable<Identifier, DungeonModel> KEY_TO_MODEL = new Hashtable();
    public static final Hashtable<Integer, DungeonModel> ID_TO_MODEL = new Hashtable();
    public static final Vec3i NO_OFFSET = new Vec3i(0, 0, 0);
    public static final Identifier SECRET_ROOM_ENTRANCE = DungeonsAll.locate("default/corridor/secret_room_entrance");
    public static final Identifier STARTER_ROOM = DungeonsAll.locate("default/room/starter_room");
    public static final Identifier STAIRCASE_LAYER = DungeonsAll.locate("default/staircase_layer");
    public static final Identifier BOTTOM_STAIRS = DungeonsAll.locate("default/stairs_bottom");
    public static final Identifier TOP_STAIRS = DungeonsAll.locate("default/stairs_top");
    public static final Identifier LOOT_ROOM = DungeonsAll.locate("default/loot_room");
    public static final Identifier SECRET_ROOM = DungeonsAll.locate("default/room/secret_room");
    private static ImmutableSet<Identifier> KEYS;
    private static Builder<Identifier> keySetBuilder;
    private static final String DIRECTORY = "models";

    public static synchronized void load(ResourceManager resourceManager) {
        ID_TO_MODEL.clear();
        KEY_TO_MODEL.clear();
        keySetBuilder = new Builder();
        resourceManager.listResources("models", s -> s.getPath().endsWith(".nbt")).forEach((file, resource) -> load(file, resourceManager));
        KEYS = keySetBuilder.build();
    }

    private static void load(Identifier file, ResourceManager resourceManager) {
        DungeonModel model = loadModel(file, resourceManager);
        Identifier metadataFile = Identifier.fromNamespaceAndPath(file.getNamespace(), file.getPath().substring(0, file.getPath().indexOf(".nbt")) + ".json");
        resourceManager.getResource(metadataFile).ifPresent(metadata -> {
            DungeonsAll.LOGGER.debug("Loading {}", metadataFile);

            try {
                model.loadMetadata(JsonParser.parseReader(new InputStreamReader(metadata.open())).getAsJsonObject(), metadataFile);
            } catch (Exception e) {
                DungeonsAll.LOGGER.error("Failed to load metadata for {}", file.getPath());
                e.printStackTrace();
            }
        });
    }

    private static DungeonModel loadModel(Identifier resource, ResourceManager resourceManager) {
        DungeonsAll.LOGGER.debug("Loading {}", resource);

        try {
            CompoundTag nbt = NbtIo.readCompressed(((Resource)resourceManager.getResource(resource).orElseThrow()).open(), NbtAccounter.unlimitedHeap());
            Identifier key = DungeonsAll.key(resource, "models", ".nbt");
            DungeonModel model = ModelHandler.loadModelFromNBT(nbt, resource, key);
            KEY_TO_MODEL.put(key, model);
            keySetBuilder.add(key);
            if (model.hasId()) {
                ID_TO_MODEL.put(model.getId(), model);
            }

            return model;
        } catch (IOException e) {
            e.printStackTrace();
            throw new DatapackLoadException("Failed to load " + resource);
        }
    }

    public static ImmutableSet<Identifier> getKeys() {
        return KEYS;
    }
}
