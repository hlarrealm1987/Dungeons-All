package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableList.Builder;
import net.minecraft.core.Vec3i;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import xiroc.dungeonsall.DungeonsAll;

public interface ModelLoader {
    ModelLoader VERSION_1 = (nbt, file, key) -> {
        Builder<DungeonModelBlock> modelBlocks = new Builder();
        ListTag blocks = (ListTag)nbt.getList("blocks").orElseThrow();

        for (int i = 0; i < blocks.size(); i++) {
            DungeonModelBlock block = DungeonModelBlock.fromNBT((CompoundTag)blocks.getCompound(i).orElseThrow());
            if (block != null) {
                modelBlocks.add(block);
            } else {
                DungeonsAll.LOGGER.error("Loading a block from {} (version 1) returned null", file);
            }
        }

        return new DungeonModel(
            key,
            modelBlocks.build(),
            (Integer)nbt.getInt("width").orElseThrow(),
            (Integer)nbt.getInt("height").orElseThrow(),
            (Integer)nbt.getInt("length").orElseThrow()
        );
    };
    ModelLoader LEGACY = (nbt, file, key) -> {
        int width = (Integer)nbt.getInt("width").orElseThrow();
        int height = (Integer)nbt.getInt("height").orElseThrow();
        int length = (Integer)nbt.getInt("length").orElseThrow();
        ListTag blocks = (ListTag)nbt.getList("model").orElseThrow();
        Builder<DungeonModelBlock> modelBlocks = new Builder();

        for (int x = 0; x < width; x++) {
            ListTag blocks2 = (ListTag)blocks.getList(x).orElseThrow();

            for (int y = 0; y < height; y++) {
                ListTag blocks3 = (ListTag)blocks2.getList(y).orElseThrow();

                for (int z = 0; z < length; z++) {
                    DungeonModelBlock block = DungeonModelBlock.fromNBT((CompoundTag)blocks3.getCompound(z).orElseThrow(), new Vec3i(x, y, z));
                    if (block != null) {
                        modelBlocks.add(block);
                    } else {
                        DungeonsAll.LOGGER.error("Loading a block from {} (legacy) returned null", file);
                    }
                }
            }
        }

        return new DungeonModel(key, modelBlocks.build(), width, height, length);
    };

    DungeonModel load(CompoundTag var1, Identifier var2, Identifier var3);
}
