package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Vec3i;
import net.minecraft.core.Direction.Axis;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FarmlandBlock;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap.Types;
import net.minecraft.world.level.levelgen.structure.BoundingBox;
import net.minecraft.world.level.material.FluidState;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.block.DungeonBlocks;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.treasure.Loot;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;
import xiroc.dungeonsall.util.DirectionalBlockPos;
import xiroc.dungeonsall.util.IBlockPlacementHandler;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Range;

public final class DungeonModelFeature {
    private final DungeonModelFeature.Type type;
    private final DungeonModelFeature.Position[] positions;
    private final Range amount;
    @Nullable
    private final DungeonModelFeature followup;

    private DungeonModelFeature(DungeonModelFeature.Type type, DungeonModelFeature.Position[] positions, Range amount, @Nullable DungeonModelFeature followup) {
        this.type = type;
        this.positions = positions;
        this.amount = amount;
        this.followup = followup;
    }

    public void setup(DungeonModel model, int x, int y, int z, Rotation rotation, List<DungeonModelFeature.Instance> features, RandomSource rand) {
        this.setup(model, x, y, z, rotation, features, Lists.newArrayList(this.positions), rand);
    }

    private void setup(
        DungeonModel model,
        int x,
        int y,
        int z,
        Rotation rotation,
        List<DungeonModelFeature.Instance> features,
        List<DungeonModelFeature.Position> positions,
        RandomSource rand
    ) {
        if (!positions.isEmpty()) {
            int count = this.amount.nextInt(rand);
            if (count >= positions.size()) {
                features.add(
                    new DungeonModelFeature.Instance(
                        this.type,
                        (DirectionalBlockPos[])positions.stream().map(posx -> posx.worldPos(x, y, z, rotation, model)).toArray(DirectionalBlockPos[]::new)
                    )
                );
            } else {
                DirectionalBlockPos[] resultingPositions = new DirectionalBlockPos[count];

                for (int i = 0; i < count; i++) {
                    DungeonModelFeature.Position pos = (DungeonModelFeature.Position)positions.get(rand.nextInt(positions.size()));
                    DirectionalBlockPos position = pos.worldPos(x, y, z, rotation, model);
                    positions.remove(pos);
                    resultingPositions[i] = position;
                }

                features.add(new DungeonModelFeature.Instance(this.type, resultingPositions));
            }

            if (this.followup != null && !positions.isEmpty()) {
                this.followup.setup(model, x, y, z, rotation, features, positions, rand);
            }
        }
    }

    private static void placeChest(
        LevelAccessor world, BlockPos pos, BlockState chest, Theme theme, SecondaryTheme secondaryTheme, int lootLevel, RandomSource rand
    ) {
        world.setBlock(pos, chest, 2);
        if (world.getBlockEntity(pos) instanceof RandomizableContainerBlockEntity randomizableContainerBlockEntity) {
            Loot.setLoot(world, pos, randomizableContainerBlockEntity, Loot.getLootTable(lootLevel, rand), theme, secondaryTheme, rand);
        }
    }

    public static DungeonModelFeature fromJson(JsonObject object, Identifier file) {
        return fromJson(object, file, null);
    }

    private static DungeonModelFeature fromJson(JsonObject object, Identifier file, DungeonModelFeature.Position[] positions) {
        String type = object.get("type").getAsString();
        if (!DungeonModelFeature.Type.TYPES.containsKey(type)) {
            throw new DatapackLoadException("Unknown feature type " + type + " in " + file);
        }

        if (positions == null) {
            JsonArray positionsArray = object.getAsJsonArray("positions");
            positions = new DungeonModelFeature.Position[positionsArray.size()];

            for (int i = 0; i < positions.length; i++) {
                positions[i] = DungeonModelFeature.Position.fromJson(positionsArray.get(i).getAsJsonObject());
            }
        }

        JsonObject jsonAmount = object.getAsJsonObject("amount");
        Range amount = new Range(jsonAmount.get("min").getAsInt(), jsonAmount.get("max").getAsInt());
        DungeonModelFeature followUp = null;
        if (object.has("follow_up")) {
            followUp = fromJson(object.getAsJsonObject("follow_up"), file, positions);
        }

        return new DungeonModelFeature((DungeonModelFeature.Type)DungeonModelFeature.Type.TYPES.get(type), positions, amount, followUp);
    }

    public static class Instance {
        private final DungeonModelFeature.Type type;
        private final DirectionalBlockPos[] positions;

        private Instance(DungeonModelFeature.Type type, DirectionalBlockPos[] positions) {
            this.type = type;
            this.positions = positions;
        }

        public void place(LevelAccessor world, BoundingBox worldGenBounds, RandomSource rand, Theme theme, SecondaryTheme secondaryTheme, int stage) {
            for (DirectionalBlockPos pos : this.positions) {
                this.type.place(world, rand, pos.position, pos.direction, worldGenBounds, theme, secondaryTheme, stage);
            }
        }

        public static DungeonModelFeature.Instance read(CompoundTag nbt) {
            DungeonModelFeature.Type type = (DungeonModelFeature.Type)DungeonModelFeature.Type.TYPES.get(nbt.getString("type").orElseThrow());
            ListTag nbtPositions = (ListTag)nbt.getList("positions").orElseThrow();
            DirectionalBlockPos[] positions = new DirectionalBlockPos[nbtPositions.size()];

            for (int i = 0; i < nbtPositions.size(); i++) {
                positions[i] = DirectionalBlockPos.fromNBT((CompoundTag)nbtPositions.getCompound(i).orElseThrow());
            }

            return new DungeonModelFeature.Instance(type, positions);
        }

        public void write(CompoundTag nbt) {
            nbt.putString("type", this.type.getName());
            ListTag positions = new ListTag();

            for (DirectionalBlockPos position : this.positions) {
                CompoundTag pos = new CompoundTag();
                position.writeToNBT(pos);
                positions.add(pos);
            }

            nbt.put("positions", positions);
        }
    }

    private record Position(Vec3i position, Direction facing) {
        public static DungeonModelFeature.Position fromJson(JsonObject object) {
            Vec3i position = JSONUtils.getOffset(object);
            Direction facing = object.has("facing") ? Direction.valueOf(object.get("facing").getAsString().toUpperCase(Locale.ROOT)) : Direction.NORTH;
            return new DungeonModelFeature.Position(position, facing);
        }

        public DirectionalBlockPos worldPos(int x, int y, int z, Rotation rotation, DungeonModel model) {
            return switch (rotation) {
                case CLOCKWISE_90 -> new DirectionalBlockPos(
                    x + model.length - this.position.getZ() - 1,
                    y + this.position.getY(),
                    z + this.position.getX(),
                    this.facing.getAxis() != Axis.Y ? this.facing.getClockWise() : this.facing
                );
                case CLOCKWISE_180 -> new DirectionalBlockPos(
                    x + model.width - this.position.getX() - 1,
                    y + this.position.getY(),
                    z + model.length - this.position.getZ() - 1,
                    this.facing.getAxis() != Axis.Y ? this.facing.getOpposite() : this.facing
                );
                case COUNTERCLOCKWISE_90 -> new DirectionalBlockPos(
                    x + this.position.getZ(),
                    y + this.position.getY(),
                    z + model.width - this.position.getX() - 1,
                    this.facing.getAxis() != Axis.Y ? this.facing.getCounterClockWise() : this.facing
                );
                default -> new DirectionalBlockPos(x + this.position.getX(), y + this.position.getY(), z + this.position.getZ(), this.facing);
            };
        }
    }

    private interface Type {
        DungeonModelFeature.Type CHEST = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && !DungeonBuilder.isBlockProtected(world, pos) && world.getBlockState(pos.below()).canOcclude()) {
                    DungeonModelFeature.placeChest(
                        world,
                        pos,
                        (BlockState)DungeonBlocks.CHEST.setValue(BlockStateProperties.HORIZONTAL_FACING, direction),
                        theme,
                        secondaryTheme,
                        stage,
                        rand
                    );
                }
            }

            @Override
            public String getName() {
                return "chest";
            }
        };
        DungeonModelFeature.Type TNT_CHEST = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && !DungeonBuilder.isBlockProtected(world, pos) && world.getBlockState(pos.below()).canOcclude()) {
                    DungeonModelFeature.placeChest(
                        world,
                        pos,
                        (BlockState)DungeonBlocks.CHEST.setValue(BlockStateProperties.HORIZONTAL_FACING, direction),
                        theme,
                        secondaryTheme,
                        stage,
                        rand
                    );
                    BlockPos down = pos.below(2);
                    if (!DungeonBuilder.isBlockProtected(world, down) && !world.isEmptyBlock(down)) {
                        world.setBlock(pos.below(2), Blocks.TNT.defaultBlockState(), 2);
                    }
                }
            }

            @Override
            public String getName() {
                return "tnt_chest";
            }
        };
        DungeonModelFeature.Type SPAWNER = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && !DungeonBuilder.isBlockProtected(world, pos) && world.getBlockState(pos.below()).canOcclude()) {
                    IBlockPlacementHandler.SPAWNER.place(world, DungeonBlocks.SPAWNER, pos, rand, theme, secondaryTheme, stage);
                }
            }

            @Override
            public String getName() {
                return "spawner";
            }
        };
        DungeonModelFeature.Type CEILING_SPAWNER = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && !DungeonBuilder.isBlockProtected(world, pos) && world.getBlockState(pos.above()).canOcclude()) {
                    IBlockPlacementHandler.SPAWNER.place(world, DungeonBlocks.SPAWNER, pos, rand, theme, secondaryTheme, stage);
                }
            }

            @Override
            public String getName() {
                return "ceiling_spawner";
            }
        };
        DungeonModelFeature.Type SPAWNER_GRAVE = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && !DungeonBuilder.isBlockProtected(world, pos) && world.getBlockState(pos.below()).canOcclude()) {
                    DungeonModelFeature.placeChest(
                        world,
                        pos,
                        (BlockState)DungeonBlocks.CHEST.setValue(BlockStateProperties.HORIZONTAL_FACING, direction),
                        theme,
                        secondaryTheme,
                        stage,
                        rand
                    );
                }

                BlockPos spawner = pos.relative(direction);
                if (bounds.isInside(spawner) && !DungeonBuilder.isBlockProtected(world, spawner) && world.getBlockState(spawner.below()).canOcclude()) {
                    IBlockPlacementHandler.SPAWNER.place(world, DungeonBlocks.SPAWNER, spawner, rand, theme, secondaryTheme, stage);
                }

                BlockPos p = pos.relative(direction, 2);
                if (bounds.isInside(p) && world.getBlockState(p.below()).canOcclude()) {
                    world.setBlock(p, Blocks.QUARTZ_BLOCK.defaultBlockState(), 2);
                }
            }

            @Override
            public String getName() {
                return "spawner_grave";
            }
        };
        DungeonModelFeature.Type EMPTY_GRAVE = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                BlockPos position = pos.relative(direction, 2);
                if (bounds.isInside(position) && world.getBlockState(position.below()).canOcclude()) {
                    world.setBlock(position, Blocks.QUARTZ_BLOCK.defaultBlockState(), 2);
                }
            }

            @Override
            public String getName() {
                return "empty_grave";
            }
        };
        DungeonModelFeature.Type STAIRS = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (direction.getAxis() != Axis.Y) {
                    for (int length = 0; length < 10; length++) {
                        if (bounds.isInside(pos)) {
                            int height = world.getHeightmapPos(Types.WORLD_SURFACE_WG, pos).getY();
                            if (height >= pos.getY()) {
                                break;
                            }

                            while (height < pos.getY()) {
                                BlockPos p = new BlockPos(pos.getX(), height, pos.getZ());
                                world.setBlock(p, theme.solid.get(world, p, rand), 2);
                                height++;
                            }

                            world.setBlock(
                                pos,
                                (BlockState)theme.solidStairs.get(world, pos, rand).setValue(BlockStateProperties.HORIZONTAL_FACING, direction.getOpposite()),
                                2
                            );
                            pos = pos.relative(direction).relative(Direction.DOWN);
                        }
                    }
                }
            }

            @Override
            public String getName() {
                return "stairs";
            }
        };
        DungeonModelFeature.Type SEWER_HOLE = new DungeonModelFeature.Type() {
            private final BlockStateProvider AIR_WATER = new BlockStateProvider() {
                @Override
                public BlockState get(LevelAccessor world, BlockPos pos, RandomSource random, Rotation rotation) {
                    return pos.getY() > 8 ? Blocks.CAVE_AIR.defaultBlockState() : Blocks.WATER.defaultBlockState();
                }

                @Override
                public JsonObject serialize() {
                    return null;
                }
            };
            private final BlockStateProvider AIR_LAVA = new BlockStateProvider() {
                @Override
                public BlockState get(LevelAccessor world, BlockPos pos, RandomSource random, Rotation rotation) {
                    return pos.getY() > 8 ? Blocks.CAVE_AIR.defaultBlockState() : Blocks.LAVA.defaultBlockState();
                }

                @Override
                public JsonObject serialize() {
                    return null;
                }
            };

            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                BlockStateProvider inner = stage < 4 ? this.AIR_WATER : this.AIR_LAVA;
                this.buildDown(world, pos, rand, bounds, inner);
                BlockPos east = pos.east();
                this.buildDown(world, east, rand, bounds, inner);
                BlockPos west = pos.west();
                this.buildDown(world, west, rand, bounds, inner);
                BlockPos north = pos.north();
                this.buildDown(world, north, rand, bounds, inner);
                BlockPos south = pos.south();
                this.buildDown(world, pos.south(), rand, bounds, inner);
                this.buildDown(world, east.north(), rand, bounds, inner);
                this.buildDown(world, east.south(), rand, bounds, inner);
                this.buildDown(world, west.north(), rand, bounds, inner);
                this.buildDown(world, west.south(), rand, bounds, inner);
                this.buildDown(world, east.offset(1, -1, 0), rand, bounds, theme.generic);
                this.buildDown(world, east.offset(1, -1, -1), rand, bounds, theme.generic);
                this.buildDown(world, east.offset(1, -1, 1), rand, bounds, theme.generic);
                this.buildDown(world, south.offset(0, -1, 1), rand, bounds, theme.generic);
                this.buildDown(world, south.offset(1, -1, 1), rand, bounds, theme.generic);
                this.buildDown(world, south.offset(-1, -1, 1), rand, bounds, theme.generic);
                this.buildDown(world, west.offset(-1, -1, 0), rand, bounds, theme.generic);
                this.buildDown(world, west.offset(-1, -1, -1), rand, bounds, theme.generic);
                this.buildDown(world, west.offset(-1, -1, 1), rand, bounds, theme.generic);
                this.buildDown(world, north.offset(0, -1, -1), rand, bounds, theme.generic);
                this.buildDown(world, north.offset(1, -1, -1), rand, bounds, theme.generic);
                this.buildDown(world, north.offset(-1, -1, -1), rand, bounds, theme.generic);
            }

            @Override
            public String getName() {
                return "sewer_hole";
            }

            private void buildDown(LevelAccessor world, BlockPos pos, RandomSource random, BoundingBox bounds, BlockStateProvider blockStateProvider) {
                if (bounds.isInside(pos)) {
                    for (; pos.getY() > 0; pos = pos.below()) {
                        if (!DungeonBuilder.isBlockProtected(world, pos) && !world.isEmptyBlock(pos)) {
                            world.setBlock(pos, blockStateProvider.get(world, pos, random), 2);
                            FluidState state = world.getFluidState(pos);
                            if (!state.isEmpty()) {
                                world.scheduleTick(pos, state.getType(), 0);
                            }
                        }
                    }
                }
            }
        };
        DungeonModelFeature.Type CROPS = new DungeonModelFeature.Type() {
            @Override
            public void place(
                LevelAccessor world,
                RandomSource rand,
                BlockPos pos,
                Direction direction,
                BoundingBox bounds,
                Theme theme,
                SecondaryTheme secondaryTheme,
                int stage
            ) {
                if (bounds.isInside(pos) && world.getBlockState(pos.below()).getBlock() instanceof FarmlandBlock) {
                    BlockState crop = DungeonBlocks.CROPS.roll(rand).defaultBlockState();
                    if (crop.hasProperty(BlockStateProperties.AGE_7)) {
                        crop = (BlockState)crop.setValue(BlockStateProperties.AGE_7, 4 + rand.nextInt(4));
                    }

                    world.setBlock(pos, crop, 2);
                }
            }

            @Override
            public String getName() {
                return "crops";
            }
        };
        ImmutableMap<String, DungeonModelFeature.Type> TYPES = new Builder()
            .put(CHEST.getName(), CHEST)
            .put(TNT_CHEST.getName(), TNT_CHEST)
            .put(SPAWNER_GRAVE.getName(), SPAWNER_GRAVE)
            .put(EMPTY_GRAVE.getName(), EMPTY_GRAVE)
            .put(SPAWNER.getName(), SPAWNER)
            .put(CEILING_SPAWNER.getName(), CEILING_SPAWNER)
            .put(STAIRS.getName(), STAIRS)
            .put(SEWER_HOLE.getName(), SEWER_HOLE)
            .put(CROPS.getName(), CROPS)
            .build();

        void place(LevelAccessor var1, RandomSource var2, BlockPos var3, Direction var4, BoundingBox var5, Theme var6, SecondaryTheme var7, int var8);

        String getName();
    }
}
