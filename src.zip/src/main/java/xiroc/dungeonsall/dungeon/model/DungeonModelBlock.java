package xiroc.dungeonsall.dungeon.model;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import xiroc.dungeonsall.DungeonsAll;

public class DungeonModelBlock {
    public final DungeonModelBlockType type;
    public Vec3i position;
    @Nullable
    private final DungeonModelBlock.PropertyHolder[] properties;
    public final boolean hasProperties;
    @Nullable
    public final Integer variation;
    public final Block block;
    @Nullable
    public final Identifier blockName;
    @Nullable
    public Identifier lootTable;

    private DungeonModelBlock(DungeonModelBlockType type, Vec3i position) {
        this(type, position, null, null, Blocks.CAVE_AIR, null);
    }

    private DungeonModelBlock(
        DungeonModelBlockType type,
        Vec3i position,
        @Nullable DungeonModelBlock.PropertyHolder[] properties,
        @Nullable Integer variation,
        Block block,
        @Nullable Identifier blockName
    ) {
        this.type = type;
        this.position = position;
        this.properties = properties;
        this.hasProperties = properties != null;
        this.variation = variation;
        this.block = block;
        this.blockName = blockName;
    }

    public static DungeonModelBlock fromBlockState(BlockState state, DungeonModelBlockType type, Vec3i position) {
        List<DungeonModelBlock.PropertyHolder> properties = Lists.newArrayList();

        for (Property<?> property : state.getProperties()) {
            properties.add(new DungeonModelBlock.PropertyHolder(property, state.getValue(property)));
        }

        DungeonModelBlock.PropertyHolder[] blockProperties = properties.isEmpty()
            ? null
            : (DungeonModelBlock.PropertyHolder[])properties.toArray(new DungeonModelBlock.PropertyHolder[0]);
        Integer variation = null;
        Identifier blockName = null;
        Block block;
        if (type == DungeonModelBlockType.CARPET) {
            variation = 0;
            block = state.getBlock();
            blockName = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        } else if (type == DungeonModelBlockType.OTHER) {
            block = state.getBlock();
            blockName = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        } else {
            block = Blocks.CAVE_AIR;
        }

        return new DungeonModelBlock(type, position, blockProperties, variation, block, blockName);
    }

    public CompoundTag toNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putString("type", this.type.toString());
        CompoundTag position = new CompoundTag();
        position.putInt("x", this.position.getX());
        position.putInt("y", this.position.getY());
        position.putInt("z", this.position.getZ());
        tag.put("position", position);
        if (this.blockName != null) {
            tag.putString("resourceName", this.blockName.toString());
        }

        if (this.properties != null) {
            ListTag properties = new ListTag();

            for (DungeonModelBlock.PropertyHolder holder : this.properties) {
                CompoundTag nbt = new CompoundTag();
                nbt.putString("property", holder.propertyName);
                nbt.putString("value", holder.valueName);
                properties.add(nbt);
            }

            if (!properties.isEmpty()) {
                tag.put("properties", properties);
            }
        }

        if (this.variation != null) {
            tag.putInt("variation", this.variation);
        }

        return tag;
    }

    public static DungeonModelBlock fromNBT(CompoundTag nbt, Vec3i position) {
        if (!nbt.contains("type")) {
            DungeonsAll.LOGGER.info("Model block does not have a type parameter");
            return new DungeonModelBlock(DungeonModelBlockType.AIR, position);
        }

        if (nbt.contains("position")) {
            CompoundTag pos = (CompoundTag)nbt.getCompound("position").orElseThrow();
            position = new Vec3i((Integer)pos.getInt("x").orElseThrow(), (Integer)pos.getInt("y").orElseThrow(), (Integer)pos.getInt("z").orElseThrow());
        }

        String type = (String)nbt.getString("type").orElseThrow();
        if (!DungeonModelBlockType.NAME_TO_TYPE.containsKey(type)) {
            DungeonsAll.LOGGER.warn("Unknown model block type: {}", type);
            return new DungeonModelBlock(DungeonModelBlockType.AIR, position);
        }

        DungeonModelBlockType blockType = (DungeonModelBlockType)DungeonModelBlockType.NAME_TO_TYPE.get(type);
        Identifier blockName = null;
        Block block;
        if (nbt.contains("resourceName")) {
            blockName = Identifier.parse((String)nbt.getString("resourceName").orElseThrow());
            if (BuiltInRegistries.BLOCK.containsKey(blockName)) {
                block = (Block)BuiltInRegistries.BLOCK.get(blockName).map(Holder::value).orElse(Blocks.CAVE_AIR);
            } else {
                DungeonsAll.LOGGER.warn("Unknown block: {}", blockName);
                block = Blocks.CAVE_AIR;
            }
        } else {
            block = Blocks.CAVE_AIR;
        }

        DungeonModelBlock.PropertyHolder[] properties = null;
        if (nbt.contains("properties")) {
            ListTag nbtProperties = (ListTag)nbt.getList("properties").orElseThrow();
            properties = new DungeonModelBlock.PropertyHolder[nbtProperties.size()];

            for (int i = 0; i < nbtProperties.size(); i++) {
                CompoundTag data = (CompoundTag)nbtProperties.get(i);
                properties[i] = new DungeonModelBlock.PropertyHolder(
                    (String)data.getString("property").orElseThrow(), (String)data.getString("value").orElseThrow()
                );
            }
        }

        Integer variation = null;
        if (nbt.contains("variation")) {
            variation = (Integer)nbt.getInt("variation").orElseThrow();
        }

        return new DungeonModelBlock(blockType, position, properties, variation, block, blockName);
    }

    public static DungeonModelBlock fromNBT(CompoundTag nbt) {
        return fromNBT(nbt, null);
    }

    public BlockPos worldPos(DungeonModel model, Rotation rotation, BlockPos offset) {
        return switch (rotation) {
            case CLOCKWISE_90 -> new BlockPos(
                offset.getX() + model.length - this.position.getZ() - 1, offset.getY() + this.position.getY(), offset.getZ() + this.position.getX()
            );
            case COUNTERCLOCKWISE_90 -> new BlockPos(
                offset.getX() + this.position.getZ(), offset.getY() + this.position.getY(), offset.getZ() + model.width - this.position.getX() - 1
            );
            case CLOCKWISE_180 -> new BlockPos(
                offset.getX() + model.width - this.position.getX() - 1,
                offset.getY() + this.position.getY(),
                offset.getZ() + model.length - this.position.getZ() - 1
            );
            default -> offset.offset(this.position);
        };
    }

    public BlockState create(BlockState state, LevelAccessor world, BlockPos pos, Rotation rotation) {
        if (this.properties != null) {
            for (DungeonModelBlock.PropertyHolder holder : this.properties) {
                state = holder.apply(state);
            }
        }

        return state.rotate(world, pos, rotation);
    }

    public BlockState create(BlockState state) {
        if (this.properties != null) {
            for (DungeonModelBlock.PropertyHolder holder : this.properties) {
                state = holder.apply(state);
            }
        }

        return state;
    }

    public Block getBlock() {
        return this.block;
    }

    private static class PropertyHolder {
        public String propertyName;
        public String valueName;
        public Property<?> property;
        public Object value;

        public PropertyHolder(String propertyName, String valueName) {
            this.propertyName = propertyName;
            this.valueName = valueName;
        }

        public PropertyHolder(Property<?> property, Object value) {
            this.property = property;
            this.propertyName = property.getName();
            this.value = value;
            this.valueName = value.toString().toLowerCase(Locale.ROOT);
        }

        public <T extends Comparable<T>> BlockState apply(BlockState state) {
            if (this.property == null) {
                for (Property<?> p : state.getProperties()) {
                    if (p.getName().equals(this.propertyName)) {
                        this.property = p;
                        Optional<?> optional = p.getValue(this.valueName);
                        if (optional.isPresent()) {
                            this.value = optional.get();
                        } else {
                            DungeonsAll.LOGGER.error("Couldn't parse property {} with value {}", p.getName(), this.valueName);
                        }
                        break;
                    }
                }
            }

            return state.hasProperty(this.property) ? (BlockState)state.setValue(this.property, (Comparable)this.value) : state;
        }
    }
}
