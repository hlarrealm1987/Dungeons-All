package xiroc.dungeonsall.dungeon;

import javax.annotation.Nonnull;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;

public class Tile {
    public final DungeonPiece piece;
    private int flags;
    private int id;

    public Tile(@Nonnull DungeonPiece piece) {
        this.piece = piece;
        this.flags = 0;
    }

    public Tile addFlag(Tile.Flag flag) {
        this.flags = this.flags | flag.value;
        return this;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return this.id;
    }

    public boolean hasFlag(Tile.Flag flag) {
        return (this.flags & flag.value) != 0;
    }

    public enum Flag {
        PLACEHOLDER(1),
        FIXED_POSITION(2),
        FIXED_ROTATION(4),
        FIXED_MODEL(8);

        int value;

        Flag(int value) {
            this.value = value;
        }
    }
}
