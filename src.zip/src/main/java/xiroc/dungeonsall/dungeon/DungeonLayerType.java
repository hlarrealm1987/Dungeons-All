package xiroc.dungeonsall.dungeon;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import xiroc.dungeonsall.dungeon.generator.layer.LayerGenerator;
import xiroc.dungeonsall.dungeon.generator.layer.NewLayerGenerator;

public enum DungeonLayerType {
    DEFAULT(NewLayerGenerator.INSTANCE);

    public static final ImmutableMap<String, DungeonLayerType> NAME_TO_TYPE = new Builder().put("default", DEFAULT).build();
    public final LayerGenerator layerGenerator;

    DungeonLayerType(LayerGenerator layerGenerator) {
        this.layerGenerator = layerGenerator;
    }
}
