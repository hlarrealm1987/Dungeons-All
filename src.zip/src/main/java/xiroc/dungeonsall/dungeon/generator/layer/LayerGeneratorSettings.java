package xiroc.dungeonsall.dungeon.generator.layer;

import com.google.gson.JsonObject;
import net.minecraft.resources.Identifier;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.Range;

public class LayerGeneratorSettings {
    public final int minRooms;
    public final int maxRooms;
    public final Range rooms;
    public final int minNodes;
    public final int maxNodes;
    public final Range nodes;
    public final int minDistance;
    public final int maxDistance;
    public final int maxDepth;
    public final int minNodeDepth;
    public final int maxNodeDepth;
    public final int minRoomDepth;
    public final int maxRoomDepth;
    public final int minStairsDepth;

    public LayerGeneratorSettings(
        int minRooms,
        int maxRooms,
        int minNodes,
        int maxNodes,
        int minRoomDepth,
        int maxRoomDepth,
        int minNodeDepth,
        int maxNodeDepth,
        int minStairsDepth,
        int maxDepth,
        int minDistance,
        int maxDistance
    ) {
        this.minRooms = minRooms;
        this.maxRooms = maxRooms;
        this.rooms = new Range(minRooms, maxRooms);
        this.minNodes = minNodes;
        this.maxNodes = maxNodes;
        this.nodes = new Range(minNodes, maxNodes);
        this.minRoomDepth = minRoomDepth;
        this.maxRoomDepth = maxRoomDepth;
        this.minNodeDepth = minNodeDepth;
        this.maxNodeDepth = maxNodeDepth;
        this.minStairsDepth = minStairsDepth;
        this.maxDepth = maxDepth;
        this.minDistance = minDistance;
        this.maxDistance = maxDistance;
    }

    public static LayerGeneratorSettings fromJson(JsonObject settings, Identifier resource) {
        return new LayerGeneratorSettings(
            getValue("min_rooms", settings, resource),
            getValue("max_rooms", settings, resource),
            getValue("min_nodes", settings, resource),
            getValue("max_nodes", settings, resource),
            getValue("min_room_depth", settings, resource),
            getValue("max_room_depth", settings, resource),
            getValue("min_node_depth", settings, resource),
            getValue("max_node_depth", settings, resource),
            getValue("min_stairs_depth", settings, resource),
            getValue("max_depth", settings, resource),
            getValue("min_distance", settings, resource),
            getValue("max_distance", settings, resource)
        );
    }

    private static int getValue(String name, JsonObject object, Identifier resource) {
        if (object.has(name)) {
            return object.getAsJsonPrimitive(name).getAsInt();
        } else {
            throw new DatapackLoadException("Missing layer settings field " + name + " in " + resource);
        }
    }
}
