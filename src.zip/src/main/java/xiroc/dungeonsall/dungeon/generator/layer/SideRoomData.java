package xiroc.dungeonsall.dungeon.generator.layer;

import net.minecraft.world.level.block.Rotation;
import xiroc.dungeonsall.util.Position2D;

public record SideRoomData(Position2D position, Rotation rotation) {
}
