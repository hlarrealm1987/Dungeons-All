package xiroc.dungeonsall.dungeon.generator.layer;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.DungeonLayer;
import xiroc.dungeonsall.dungeon.Tile;
import xiroc.dungeonsall.dungeon.piece.DungeonCorridor;
import xiroc.dungeonsall.dungeon.piece.DungeonPiece;
import xiroc.dungeonsall.dungeon.piece.DungeonStairs;
import xiroc.dungeonsall.dungeon.piece.room.DungeonNodeRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonRoom;
import xiroc.dungeonsall.util.Orientation;
import xiroc.dungeonsall.util.Position2D;

public class NewLayerGenerator extends LayerGenerator {
    public static final NewLayerGenerator INSTANCE = new NewLayerGenerator();
    private int roomsLeft;
    private int nodesLeft;
    private int rooms;
    private int nodes;
    private boolean secretRoom;
    private final ArrayList<DungeonCorridor> corridors = new ArrayList();
    private ArrayList<NewLayerGenerator.LayerElement> newElements;
    private boolean placeStairs;
    private static final Consumer<NewLayerGenerator> ON_ROOM_PLACED = generator -> {
        generator.roomsLeft--;
        generator.rooms++;
    };
    private static final Consumer<NewLayerGenerator> ON_NODE_PLACED = generator -> {
        generator.nodesLeft--;
        generator.nodes++;
    };
    private static final Consumer<NewLayerGenerator> ON_STAIRS_PLACED = generator -> generator.placeStairs = false;

    private NewLayerGenerator() {
    }

    @Override
    public void initializeLayer(LayerGeneratorSettings settings, DungeonBuilder dungeonBuilder, RandomSource rand, int layer, boolean isLastLayer) {
        super.initializeLayer(settings, dungeonBuilder, rand, layer, isLastLayer);
        this.corridors.clear();
        this.placeStairs = !isLastLayer;
        this.secretRoom = false;
        this.roomsLeft = settings.rooms.nextInt(rand);
        this.nodesLeft = settings.nodes.nextInt(rand);
        this.rooms = 0;
        this.nodes = 0;
    }

    @Override
    public void generateLayer(DungeonBuilder dungeonBuilder, DungeonLayer dungeonLayer, int layer, RandomSource rand, Position2D start) {
        dungeonLayer.start = start;
        this.newElements = new ArrayList();
        NewLayerGenerator.LayerElement stairs = new NewLayerGenerator.GenericElement(new DungeonStairs().bottom(), start, null, null, 0);
        stairs.place(dungeonLayer);
        stairs.update(this, dungeonLayer, rand);
        ArrayList<NewLayerGenerator.LayerElement> lastElements = this.newElements;

        do {
            this.newElements = new ArrayList();

            for (NewLayerGenerator.LayerElement element : lastElements) {
                element.update(this, dungeonLayer, rand);
            }

            lastElements = this.newElements;
        } while (!lastElements.isEmpty());

        if (layer == 0) {
            createStarterRoom(dungeonLayer, rand, layer);
        }

        if (this.secretRoom) {
            tryCreateSecretRoom(dungeonLayer, this.corridors, 8, rand);
        }

        this.corridors.clear();
        this.newElements.clear();
        DungeonsAll.LOGGER.debug("Generated Layer {} with {}({}) Nodes and {}({}) Rooms", layer, this.nodes, this.nodesLeft, this.rooms, this.roomsLeft);
    }

    private void generationStep(
        NewLayerGenerator.LayerElement cursor, DungeonLayer dungeonLayer, @Nullable Direction excludedDirection, RandomSource rand, int depth
    ) {
        if (depth <= this.settings.maxDepth) {
            List<Direction> directions = Lists.newArrayList(
                excludedDirection != null ? Orientation.getHorizontalFacingsWithout(excludedDirection) : Orientation.HORIZONTAL_FACINGS
            );
            int count = depth < 2 ? 2 + rand.nextInt(2) : 1 + rand.nextInt(3);

            while (count > 0 && !directions.isEmpty()) {
                Direction direction = (Direction)directions.remove(rand.nextInt(directions.size()));
                int maxDistance = this.maxDistance(cursor.position, direction, dungeonLayer);
                if (maxDistance >= this.settings.minDistance) {
                    Position2D nextPos = cursor.position.shift(direction, Mth.nextInt(rand, this.settings.minDistance, maxDistance));
                    if (nextPos.isValid(dungeonLayer.width, dungeonLayer.length)) {
                        NewLayerGenerator.LayerElement element = this.nextElement(dungeonLayer, nextPos, direction.getOpposite(), rand, depth);
                        if (element != null) {
                            boolean canConnect = this.canConnectStraight(dungeonLayer, cursor, element);
                            if (canConnect) {
                                element.place(dungeonLayer);
                                element.onPlaced.accept(this);
                                this.connectStraight(dungeonLayer, cursor.getConnectionPoint(direction), element.getConnectionPoint(direction.getOpposite()));
                                this.newElements.add(element);
                                count--;
                            }
                        }
                    }
                }
            }
        }
    }

    @Nullable
    private NewLayerGenerator.LayerElement nextElement(DungeonLayer dungeonLayer, Position2D pos, Direction toOrigin, RandomSource rand, int depth) {
        if (dungeonLayer.isTileFree(pos)) {
            if (this.placeStairs && depth >= this.settings.minStairsDepth) {
                dungeonLayer.end = pos;
                return new NewLayerGenerator.GenericElement(new DungeonStairs().top(), pos, toOrigin, ON_STAIRS_PLACED, depth);
            }

            if (depth <= this.settings.maxNodeDepth
                && this.nodesLeft > 0
                && (this.roomsLeft == 0 || depth > this.settings.maxRoomDepth || rand.nextFloat() < 0.65F)
                && dungeonLayer.canPlaceNode(pos)) {
                return new NewLayerGenerator.NodeElement(pos, toOrigin, depth);
            }

            if (depth <= this.settings.maxRoomDepth && this.roomsLeft > 0) {
                return new NewLayerGenerator.GenericElement(new DungeonRoom(), pos, toOrigin, ON_ROOM_PLACED, depth);
            }
        }

        return null;
    }

    private int maxDistance(Position2D pos, Direction direction, DungeonLayer dungeonLayer) {
        return switch (direction) {
            case NORTH -> Math.min(pos.z, this.settings.maxDistance);
            case SOUTH -> Math.min(dungeonLayer.length - pos.z - 1, this.settings.maxDistance);
            case WEST -> Math.min(pos.x, this.settings.maxDistance);
            case EAST -> Math.min(dungeonLayer.width - pos.x - 1, this.settings.maxDistance);
            default -> 0;
        };
    }

    @Override
    public void enableSecretRoom() {
        this.secretRoom = true;
    }

    public void connectStraight(DungeonLayer dungeonLayer, Position2D start, Position2D end) {
        if (start.x == end.x && start.z == end.z) {
            throw new IllegalArgumentException("The start and end positions of a straight connection must not be the same.");
        }

        if (start.x == end.x) {
            if (start.z > end.z) {
                dungeonLayer.openSideIfPresent(start, Direction.NORTH);
                dungeonLayer.openSideIfPresent(end, Direction.SOUTH);

                for (int z = start.z - 1; z > end.z; z--) {
                    if (dungeonLayer.grid[start.x][z] != null) {
                        DungeonPiece piece = dungeonLayer.grid[start.x][z].piece;
                        if (piece.canConnect(Direction.NORTH, start.x, z) && piece.canConnect(Direction.SOUTH, start.x, z)) {
                            piece.openSide(Direction.NORTH);
                            piece.openSide(Direction.SOUTH);
                        }
                    } else {
                        DungeonCorridor corridor = createCorridor(dungeonLayer, start.x, z, Direction.NORTH, Direction.SOUTH);
                        this.corridors.add(corridor);
                    }
                }
            } else {
                dungeonLayer.openSideIfPresent(start, Direction.SOUTH);
                dungeonLayer.openSideIfPresent(end, Direction.NORTH);

                for (int z = start.z + 1; z < end.z; z++) {
                    if (dungeonLayer.grid[start.x][z] != null) {
                        DungeonPiece piece = dungeonLayer.grid[start.x][z].piece;
                        if (piece.canConnect(Direction.SOUTH, start.x, z) && piece.canConnect(Direction.NORTH, start.x, z)) {
                            piece.openSide(Direction.SOUTH);
                            piece.openSide(Direction.NORTH);
                        }
                    } else {
                        DungeonCorridor corridor = createCorridor(dungeonLayer, start.x, z, Direction.SOUTH, Direction.NORTH);
                        this.corridors.add(corridor);
                    }
                }
            }
        } else {
            if (start.z != end.z) {
                throw new IllegalArgumentException(
                    "The start and end positions of a straight connection must have either the same x-coordinate or the same z-coordinate."
                );
            }

            if (start.x > end.x) {
                dungeonLayer.openSideIfPresent(start, Direction.WEST);
                dungeonLayer.openSideIfPresent(end, Direction.EAST);

                for (int x = start.x - 1; x > end.x; x--) {
                    if (dungeonLayer.grid[x][start.z] != null) {
                        DungeonPiece piece = dungeonLayer.grid[x][start.z].piece;
                        if (piece.canConnect(Direction.WEST, x, start.z) && piece.canConnect(Direction.EAST, x, start.z)) {
                            piece.openSide(Direction.WEST);
                            piece.openSide(Direction.EAST);
                        }
                    } else {
                        DungeonCorridor corridor = createCorridor(dungeonLayer, x, start.z, Direction.WEST, Direction.EAST);
                        this.corridors.add(corridor);
                    }
                }
            } else {
                dungeonLayer.openSideIfPresent(start, Direction.EAST);
                dungeonLayer.openSideIfPresent(end, Direction.WEST);

                for (int x = start.x + 1; x < end.x; x++) {
                    if (dungeonLayer.grid[x][start.z] != null) {
                        DungeonPiece piece = dungeonLayer.grid[x][start.z].piece;
                        if (piece.canConnect(Direction.EAST, x, start.z) && piece.canConnect(Direction.WEST, x, start.z)) {
                            piece.openSide(Direction.EAST);
                            piece.openSide(Direction.WEST);
                        }
                    } else {
                        DungeonCorridor corridor = createCorridor(dungeonLayer, x, start.z, Direction.EAST, Direction.WEST);
                        this.corridors.add(corridor);
                    }
                }
            }
        }
    }

    private boolean canConnectStraight(DungeonLayer dungeonLayer, NewLayerGenerator.LayerElement start, NewLayerGenerator.LayerElement end) {
        if (start.position.x == end.position.x && start.position.z == end.position.z) {
            return false;
        }

        if (start.position.x == end.position.x) {
            if (start.position.z > end.position.z) {
                if (!start.piece.canConnect(Direction.NORTH, end.position.x, end.position.z)
                    || !end.piece.canConnect(Direction.SOUTH, start.position.x, start.position.z)) {
                    return false;
                }

                for (int z = start.position.z - 1; z > end.position.z; z--) {
                    if (this.pieceCannotConnect(dungeonLayer, start.position.x, z, Direction.NORTH, Direction.SOUTH)) {
                        return false;
                    }
                }
            } else {
                if (!start.piece.canConnect(Direction.SOUTH, end.position.x, end.position.z)
                    || !end.piece.canConnect(Direction.NORTH, start.position.x, start.position.z)) {
                    return false;
                }

                for (int z = start.position.z; z < end.position.z; z++) {
                    if (this.pieceCannotConnect(dungeonLayer, start.position.x, z, Direction.SOUTH, Direction.NORTH)) {
                        return false;
                    }
                }
            }

            return true;
        } else {
            if (start.position.z != end.position.z) {
                return false;
            }

            if (start.position.x > end.position.x) {
                if (!start.piece.canConnect(Direction.WEST, end.position.x, end.position.z)
                    || !end.piece.canConnect(Direction.EAST, start.position.x, start.position.z)) {
                    return false;
                }

                for (int x = start.position.x - 1; x > end.position.x; x--) {
                    if (this.pieceCannotConnect(dungeonLayer, x, start.position.z, Direction.WEST, Direction.EAST)) {
                        return false;
                    }
                }
            } else {
                if (!start.piece.canConnect(Direction.EAST, end.position.x, end.position.z)
                    || !end.piece.canConnect(Direction.WEST, start.position.x, start.position.z)) {
                    return false;
                }

                for (int x = start.position.x; x < end.position.x; x++) {
                    if (this.pieceCannotConnect(dungeonLayer, x, start.position.z, Direction.EAST, Direction.WEST)) {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    private boolean pieceCannotConnect(DungeonLayer dungeonLayer, int x, int z, Direction from, Direction to) {
        if (dungeonLayer.grid[x][z] == null) {
            return false;
        }

        DungeonPiece piece = dungeonLayer.grid[x][z].piece;
        return !piece.canConnect(from, x, z) || !piece.canConnect(to, x, z);
    }

    private static class GenericElement extends NewLayerGenerator.LayerElement {
        GenericElement(DungeonPiece piece, Position2D position, Direction toOrigin, Consumer<NewLayerGenerator> onPlaced, int depth) {
            super(piece, position, toOrigin, onPlaced, depth);
        }

        @Override
        public Position2D getConnectionPoint(Direction connectionSide) {
            return this.position;
        }
    }

    private abstract static class LayerElement {
        final Position2D position;
        final Direction toOrigin;
        final int depth;
        final DungeonPiece piece;
        final Consumer<NewLayerGenerator> onPlaced;

        LayerElement(DungeonPiece piece, Position2D position, Direction toOrigin, Consumer<NewLayerGenerator> onPlaced, int depth) {
            this.piece = piece;
            this.piece.setGridPosition(position);
            this.position = position;
            this.toOrigin = toOrigin;
            this.onPlaced = onPlaced;
            this.depth = depth;
        }

        public void place(DungeonLayer layer) {
            layer.grid[this.position.x][this.position.z] = new Tile(this.piece);
        }

        public void update(NewLayerGenerator layerGenerator, DungeonLayer dungeonLayer, RandomSource rand) {
            layerGenerator.generationStep(this, dungeonLayer, this.toOrigin, rand, this.depth + 1);
        }

        public abstract Position2D getConnectionPoint(Direction var1);
    }

    private static class NodeElement extends NewLayerGenerator.LayerElement {
        NodeElement(Position2D center, Direction toOrigin, int depth) {
            super(new DungeonNodeRoom(), center, toOrigin, NewLayerGenerator.ON_NODE_PLACED, depth);
        }

        @Override
        public void place(DungeonLayer layer) {
            LayerGenerator.placeNodeRoom((DungeonNodeRoom)this.piece, this.position, layer);
        }

        @Override
        public Position2D getConnectionPoint(Direction connectionSide) {
            return this.position.shift(connectionSide, 1);
        }
    }
}
