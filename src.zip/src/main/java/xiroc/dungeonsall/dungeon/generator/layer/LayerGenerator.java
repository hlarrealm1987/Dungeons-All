package xiroc.dungeonsall.dungeon.generator.layer;

import java.util.List;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.DungeonLayer;
import xiroc.dungeonsall.dungeon.Tile;
import xiroc.dungeonsall.dungeon.model.DungeonModel;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.piece.DungeonCorridor;
import xiroc.dungeonsall.dungeon.piece.room.DungeonNodeRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSideRoom;
import xiroc.dungeonsall.util.Orientation;
import xiroc.dungeonsall.util.Position2D;

public abstract class LayerGenerator {
    public LayerGeneratorSettings settings;

    public static void createNodeRoom(Position2D center, DungeonLayer dungeonLayer) {
        placeNodeRoom(new DungeonNodeRoom(), center, dungeonLayer);
    }

    public static void placeNodeRoom(DungeonNodeRoom nodeRoom, Position2D center, DungeonLayer dungeonLayer) {
        nodeRoom.setGridPosition(center.x, center.z);
        Tile placeHolder = new Tile(nodeRoom).addFlag(Tile.Flag.PLACEHOLDER);

        for (int x = -1; x < 2; x++) {
            for (int z = -1; z < 2; z++) {
                if ((x != 0 || z != 0) && Position2D.isValid(center.x + x, center.z + z, dungeonLayer.width, dungeonLayer.length)) {
                    dungeonLayer.grid[center.x + x][center.z + z] = placeHolder;
                }
            }
        }

        dungeonLayer.grid[center.x][center.z] = new Tile(nodeRoom);
    }

    public static DungeonCorridor createCorridor(DungeonLayer dungeonLayer, int x, int z, Direction from, Direction to) {
        DungeonCorridor corridor = new DungeonCorridor();
        corridor.setGridPosition(x, z);
        corridor.openSide(from);
        corridor.openSide(to);
        corridor.setRotation(Orientation.getRotationFromFacing(from));
        dungeonLayer.grid[corridor.gridPosition.x][corridor.gridPosition.z] = new Tile(corridor);
        return corridor;
    }

    public static void tryCreateSecretRoom(DungeonLayer dungeonLayer, List<DungeonCorridor> corridors, int maxAttempts, RandomSource random) {
        for (int i = 0; i < maxAttempts && !corridors.isEmpty(); i++) {
            DungeonCorridor corridor = (DungeonCorridor)corridors.get(random.nextInt(corridors.size()));
            if (corridor.isStraight() && corridor.connectedSides == 2 && dungeonLayer.placeSecretRoom(corridor, corridor.gridPosition, random)) {
                break;
            }

            corridors.remove(corridor);
        }
    }

    public static void createStarterRoom(DungeonLayer dungeonLayer, RandomSource rand, int layer) {
        SideRoomData sideRoomData = dungeonLayer.findStarterRoomData(dungeonLayer.start, rand);
        if (sideRoomData != null) {
            DungeonSideRoom room = new DungeonSideRoom();
            Direction dir = sideRoomData.rotation().rotate(Direction.WEST);
            room.openSide(dir);
            room.setGridPosition(sideRoomData.position().x, sideRoomData.position().z);
            room.setRotation(sideRoomData.rotation());
            room.model = (DungeonModel)DungeonModels.KEY_TO_MODEL.get(DungeonModels.STARTER_ROOM);
            room.stage = layer;
            dungeonLayer.map.markPositionAsOccupied(sideRoomData.position());
            dungeonLayer.grid[sideRoomData.position().x][sideRoomData.position().z] = new Tile(room).addFlag(Tile.Flag.FIXED_MODEL);
            Position2D connectedSegment = sideRoomData.position().shift(dir, 1);
            if (dungeonLayer.grid[connectedSegment.x][connectedSegment.z] != null) {
                dungeonLayer.grid[connectedSegment.x][connectedSegment.z].piece.openSide(dir.getOpposite());
                dungeonLayer.rotatePiece(dungeonLayer.grid[connectedSegment.x][connectedSegment.z], rand);
            }
        }
    }

    public void initializeLayer(LayerGeneratorSettings settings, DungeonBuilder dungeonBuilder, RandomSource rand, int layer, boolean isLastLayer) {
        this.settings = settings;
    }

    public abstract void generateLayer(DungeonBuilder var1, DungeonLayer var2, int var3, RandomSource var4, Position2D var5);

    public void enableSecretRoom() {
    }
}
