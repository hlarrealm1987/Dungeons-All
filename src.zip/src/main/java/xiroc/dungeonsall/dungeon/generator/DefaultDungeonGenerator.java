package xiroc.dungeonsall.dungeon.generator;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.DungeonLayer;
import xiroc.dungeonsall.dungeon.DungeonType;
import xiroc.dungeonsall.dungeon.generator.layer.LayerGenerator;
import xiroc.dungeonsall.dungeon.generator.layer.LayerGeneratorSettings;
import xiroc.dungeonsall.util.Position2D;

public class DefaultDungeonGenerator extends DungeonGenerator {
    private int secretRoomLayer;
    private LayerGenerator layerGenerator;

    @Override
    public void initializeDungeon(DungeonType type, DungeonBuilder dungeonBuilder, ChunkPos chunkPos, RandomSource rand) {
        super.initializeDungeon(type, dungeonBuilder, chunkPos, rand);
        this.secretRoomLayer = rand.nextInt(2);
    }

    @Override
    public void initializeLayer(LayerGeneratorSettings settings, DungeonBuilder dungeonBuilder, RandomSource rand, int layer, boolean isLastLayer) {
        this.layerGenerator = this.type.getLayer(layer).layerType().layerGenerator;
        this.layerGenerator.initializeLayer(settings, dungeonBuilder, rand, layer, isLastLayer);
    }

    @Override
    public int layerCount(RandomSource rand, int height) {
        return Math.min(this.type.dungeonSettings().maxLayers(), height / 9);
    }

    @Override
    public void generateLayer(DungeonBuilder dungeonBuilder, DungeonLayer dungeonLayer, int layer, RandomSource rand, Position2D start) {
        DungeonsAll.LOGGER.debug("Generating layout for layer {}", layer);
        if ((Boolean)Config.SECRET_ROOMS.get() && layer == this.secretRoomLayer) {
            this.layerGenerator.enableSecretRoom();
        }

        this.layerGenerator.generateLayer(dungeonBuilder, dungeonLayer, layer, rand, start);
    }
}
