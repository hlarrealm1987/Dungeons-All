package xiroc.dungeonsall.dungeon.generator;

import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ChunkPos;
import xiroc.dungeonsall.dungeon.DungeonBuilder;
import xiroc.dungeonsall.dungeon.DungeonType;
import xiroc.dungeonsall.dungeon.generator.layer.LayerGenerator;

public abstract class DungeonGenerator extends LayerGenerator {
    protected DungeonType type;

    public void initializeDungeon(DungeonType type, DungeonBuilder dungeonBuilder, ChunkPos chunkPos, RandomSource rand) {
        this.type = type;
    }

    public abstract int layerCount(RandomSource var1, int var2);
}
