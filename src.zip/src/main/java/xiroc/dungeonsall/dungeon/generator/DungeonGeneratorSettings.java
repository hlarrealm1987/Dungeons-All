package xiroc.dungeonsall.dungeon.generator;

import com.google.gson.JsonObject;
import net.minecraft.resources.Identifier;
import xiroc.dungeonsall.exception.DatapackLoadException;

public record DungeonGeneratorSettings(int maxLayers) {
    public static DungeonGeneratorSettings fromJson(JsonObject settings, Identifier file) {
        if (settings.has("max_layers")) {
            return new DungeonGeneratorSettings(settings.get("max_layers").getAsInt());
        } else {
            throw new DatapackLoadException("Missing entry max_layers in " + file);
        }
    }
}
