package xiroc.dungeonsall.compat;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.storage.loot.LootContext;

/**
 * Small helpers for Minecraft 26.3 methods that were renamed.
 * They look up the right method once, by its types, so they work no matter the new name.
 */
public final class Compat26 {
    private static Method samplerMethod;
    private static Method parameterMethod;

    private Compat26() {}

    /** Returns the climate sampler of a RandomState (was RandomState.sampler()). */
    public static Climate.Sampler sampler(RandomState state) {
        try {
            if (samplerMethod == null) {
                for (Method m : RandomState.class.getMethods()) {
                    if (m.getParameterCount() == 0 && !Modifier.isStatic(m.getModifiers())
                            && Climate.Sampler.class.isAssignableFrom(m.getReturnType())) {
                        samplerMethod = m;
                        break;
                    }
                }
            }
            return (Climate.Sampler) samplerMethod.invoke(state);
        } catch (Exception e) {
            throw new IllegalStateException("Dungeons All: could not get the climate sampler", e);
        }
    }

    /** Reads a loot context parameter (was LootContext.getParameter(key)). Returns null if missing. */
    @SuppressWarnings("unchecked")
    public static <T> T parameter(LootContext context, ContextKey<T> key) {
        try {
            if (parameterMethod == null) {
                Method fallback = null;
                for (Method m : LootContext.class.getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 1 && p[0] == ContextKey.class && !Modifier.isStatic(m.getModifiers())
                            && m.getReturnType() != boolean.class && m.getReturnType() != Boolean.class) {
                        if (m.getName().toLowerCase().contains("optional")) {
                            parameterMethod = m;
                            break;
                        }
                        if (fallback == null) {
                            fallback = m;
                        }
                    }
                }
                if (parameterMethod == null) {
                    parameterMethod = fallback;
                }
            }
            Object value = parameterMethod.invoke(context, key);
            if (value instanceof java.util.Optional<?> optional) {
                value = optional.orElse(null);
            }
            return (T) value;
        } catch (Exception e) {
            return null;
        }
    }

    private static Method noiseBiomeMethod;
    private static java.util.function.Function<RandomState, Object> noiseArgument;
    private static boolean noiseBiomeSearched;

    /**
     * Biome at a quart position (was BiomeSource.getNoiseBiome(x, y, z, randomState.sampler())).
     * Returns null (and logs the available methods once) if it cannot be found, instead of crashing.
     */
    @SuppressWarnings("unchecked")
    public static synchronized net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> noiseBiome(
            net.minecraft.world.level.biome.BiomeSource source, int x, int y, int z, RandomState state) {
        if (!noiseBiomeSearched) {
            noiseBiomeSearched = true;
            findNoiseBiome(source, state);
        }
        if (noiseBiomeMethod == null) {
            return null;
        }
        try {
            Object arg = noiseArgument.apply(state);
            return (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) noiseBiomeMethod.invoke(source, x, y, z, arg);
        } catch (Exception e) {
            return null;
        }
    }

    private static void findNoiseBiome(net.minecraft.world.level.biome.BiomeSource source, RandomState state) {
        for (Method m : source.getClass().getMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (p.length != 4 || p[0] != int.class || p[1] != int.class || p[2] != int.class
                    || Modifier.isStatic(m.getModifiers())
                    || !net.minecraft.core.Holder.class.isAssignableFrom(m.getReturnType())) {
                continue;
            }
            java.util.function.Function<RandomState, Object> arg = argumentFor(p[3], state);
            if (arg != null) {
                noiseBiomeMethod = m;
                noiseArgument = arg;
                xiroc.dungeonsall.DungeonsAll.LOGGER.info("Dungeons All: biome lookup uses {} ", m);
                return;
            }
        }
        // Not found: log what exists so it can be fixed.
        xiroc.dungeonsall.DungeonsAll.LOGGER.error("Dungeons All: could not find the biome lookup. Dungeons will skip the biome check.");
        for (Method m : source.getClass().getMethods()) {
            if (net.minecraft.core.Holder.class.isAssignableFrom(m.getReturnType())) {
                xiroc.dungeonsall.DungeonsAll.LOGGER.error("  BiomeSource method: {}", m);
            }
        }
        for (Method m : RandomState.class.getMethods()) {
            if (m.getParameterCount() == 0) {
                xiroc.dungeonsall.DungeonsAll.LOGGER.error("  RandomState method: {}", m);
            }
        }
    }

    /** How to turn a RandomState into the 4th argument the biome lookup needs. */
    private static java.util.function.Function<RandomState, Object> argumentFor(Class<?> type, RandomState state) {
        if (type.isInstance(state)) {
            return s -> s;
        }
        // A no-argument method on RandomState that returns the right type.
        for (Method r : RandomState.class.getMethods()) {
            if (r.getParameterCount() == 0 && !Modifier.isStatic(r.getModifiers())
                    && r.getReturnType() != Object.class && type.isAssignableFrom(r.getReturnType())) {
                return s -> invoke(r, s);
            }
        }
        // A field on RandomState of the right type.
        for (java.lang.reflect.Field f : RandomState.class.getDeclaredFields()) {
            if (!Modifier.isStatic(f.getModifiers()) && type.isAssignableFrom(f.getType()) && f.getType() != Object.class) {
                try {
                    f.setAccessible(true);
                    return s -> {
                        try {
                            return f.get(s);
                        } catch (IllegalAccessException e) {
                            throw new IllegalStateException(e);
                        }
                    };
                } catch (RuntimeException ignored) {
                    // not accessible, keep looking
                }
            }
        }
        // One step further: RandomState -> something -> the right type.
        for (Method r : RandomState.class.getMethods()) {
            if (r.getParameterCount() != 0 || Modifier.isStatic(r.getModifiers()) || r.getReturnType().isPrimitive()
                    || r.getDeclaringClass() == Object.class) {
                continue;
            }
            for (Method r2 : r.getReturnType().getMethods()) {
                if (r2.getParameterCount() == 0 && !Modifier.isStatic(r2.getModifiers())
                        && r2.getReturnType() != Object.class && type.isAssignableFrom(r2.getReturnType())) {
                    return s -> invoke(r2, invoke(r, s));
                }
            }
        }
        return null;
    }

    private static Object invoke(Method m, Object target) {
        try {
            return m.invoke(target);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
