package xiroc.dungeonsall.compat;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.storage.loot.LootContext;

/**
 * Small helpers for Minecraft 26.3 methods that were renamed.
 * They look up the right method once, by its types, so they work no matter the new name.
 */
public final class Compat26 {
    private static Method samplerMethod;
    private static Method parameterMethod;

    private Compat26() {}

    /** Returns the climate sampler of a RandomState (was RandomState.sampler()). */
    public static Climate.Sampler sampler(RandomState state) {
        try {
            if (samplerMethod == null) {
                for (Method m : RandomState.class.getMethods()) {
                    if (m.getParameterCount() == 0 && !Modifier.isStatic(m.getModifiers())
                            && Climate.Sampler.class.isAssignableFrom(m.getReturnType())) {
                        samplerMethod = m;
                        break;
                    }
                }
            }
            return (Climate.Sampler) samplerMethod.invoke(state);
        } catch (Exception e) {
            throw new IllegalStateException("Dungeons All: could not get the climate sampler", e);
        }
    }

    /** Reads a loot context parameter (was LootContext.getParameter(key)). Returns null if missing. */
    @SuppressWarnings("unchecked")
    public static <T> T parameter(LootContext context, ContextKey<T> key) {
        try {
            if (parameterMethod == null) {
                Method fallback = null;
                for (Method m : LootContext.class.getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 1 && p[0] == ContextKey.class && !Modifier.isStatic(m.getModifiers())
                            && m.getReturnType() != boolean.class && m.getReturnType() != Boolean.class) {
                        if (m.getName().toLowerCase().contains("optional")) {
                            parameterMethod = m;
                            break;
                        }
                        if (fallback == null) {
                            fallback = m;
                        }
                    }
                }
                if (parameterMethod == null) {
                    parameterMethod = fallback;
                }
            }
            Object value = parameterMethod.invoke(context, key);
            if (value instanceof java.util.Optional<?> optional) {
                value = optional.orElse(null);
            }
            return (T) value;
        } catch (Exception e) {
            return null;
        }
    }
}
