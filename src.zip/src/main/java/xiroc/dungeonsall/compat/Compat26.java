package xiroc.dungeonsall.compat;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.storage.loot.LootContext;

/**
 * Small helpers for Minecraft 26.3 methods that were renamed.
 * They look up the right method once, by its types, so they work no matter the new name.
 */
public final class Compat26 {
    private static Method samplerMethod;
    private static Method parameterMethod;

    private Compat26() {}

    /** Returns the climate sampler of a RandomState (was RandomState.sampler()). */
    public static Climate.Sampler sampler(RandomState state) {
        try {
            if (samplerMethod == null) {
                for (Method m : RandomState.class.getMethods()) {
                    if (m.getParameterCount() == 0 && !Modifier.isStatic(m.getModifiers())
                            && Climate.Sampler.class.isAssignableFrom(m.getReturnType())) {
                        samplerMethod = m;
                        break;
                    }
                }
            }
            return (Climate.Sampler) samplerMethod.invoke(state);
        } catch (Exception e) {
            throw new IllegalStateException("Dungeons All: could not get the climate sampler", e);
        }
    }

    /** Reads a loot context parameter (was LootContext.getParameter(key)). Returns null if missing. */
    @SuppressWarnings("unchecked")
    public static <T> T parameter(LootContext context, ContextKey<T> key) {
        try {
            if (parameterMethod == null) {
                Method fallback = null;
                for (Method m : LootContext.class.getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 1 && p[0] == ContextKey.class && !Modifier.isStatic(m.getModifiers())
                            && m.getReturnType() != boolean.class && m.getReturnType() != Boolean.class) {
                        if (m.getName().toLowerCase().contains("optional")) {
                            parameterMethod = m;
                            break;
                        }
                        if (fallback == null) {
                            fallback = m;
                        }
                    }
                }
                if (parameterMethod == null) {
                    parameterMethod = fallback;
                }
            }
            Object value = parameterMethod.invoke(context, key);
            if (value instanceof java.util.Optional<?> optional) {
                value = optional.orElse(null);
            }
            return (T) value;
        } catch (Exception e) {
            return null;
        }
    }

    private static Method noiseBiomeMethod;
    private static Method noiseSamplerMethod;

    /**
     * Biome at a quart position (was BiomeSource.getNoiseBiome(x, y, z, randomState.sampler())).
     * Finds the 4-argument getter (int, int, int, sampler) and the matching sampler from RandomState.
     */
    @SuppressWarnings("unchecked")
    public static net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome> noiseBiome(
            net.minecraft.world.level.biome.BiomeSource source, int x, int y, int z, RandomState state) {
        try {
            if (noiseBiomeMethod == null) {
                for (Method m : net.minecraft.world.level.biome.BiomeSource.class.getMethods()) {
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length == 4 && p[0] == int.class && p[1] == int.class && p[2] == int.class
                            && net.minecraft.core.Holder.class.isAssignableFrom(m.getReturnType())
                            && !Modifier.isStatic(m.getModifiers())) {
                        for (Method r : RandomState.class.getMethods()) {
                            if (r.getParameterCount() == 0 && !Modifier.isStatic(r.getModifiers())
                                    && p[3].isAssignableFrom(r.getReturnType()) && r.getReturnType() != Object.class) {
                                noiseBiomeMethod = m;
                                noiseSamplerMethod = r;
                                break;
                            }
                        }
                        if (noiseBiomeMethod != null) {
                            break;
                        }
                    }
                }
            }
            Object sampler = noiseSamplerMethod.invoke(state);
            return (net.minecraft.core.Holder<net.minecraft.world.level.biome.Biome>) noiseBiomeMethod.invoke(source, x, y, z, sampler);
        } catch (Exception e) {
            throw new IllegalStateException("Dungeons All: could not look up the biome", e);
        }
    }
}
