package xiroc.dungeonsall;

import java.util.Objects;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.levelgen.structure.StructureType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig.Type;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.AddServerReloadListenersEvent;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.RegisterEvent;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.treasure.Loot;
import xiroc.dungeonsall.init.ModStructurePieceTypes;
import xiroc.dungeonsall.init.ModStructureTypes;
import xiroc.dungeonsall.util.ResourceReloadHandler;

@Mod("dungeonsall")
public class DungeonsAll {
    public static final String MOD_ID = "dungeonsall";
    public static final String NAME = "Dungeons All";
    public static final String VERSION = "2.3.17";
    public static final Logger LOGGER = LogManager.getLogger("Dungeons All");
    public static final DeferredRegister<StructureType<?>> STRUCTURE_TYPE = DeferredRegister.create(Registries.STRUCTURE_TYPE, "dungeonsall");
    public static final DeferredRegister<StructurePieceType> STRUCTURE_PIECE_TYPE = DeferredRegister.create(Registries.STRUCTURE_PIECE, "dungeonsall");

    public DungeonsAll(ModContainer modContainer) {
        LOGGER.info("Here we go! Launching Dungeons All {}...", "2.3.17");
        modContainer.registerConfig(Type.LOCAL, Config.CONFIG, "dungeons_all.toml");
        IEventBus modEventBus = (IEventBus)Objects.requireNonNull(modContainer.getEventBus());
        STRUCTURE_TYPE.register(modEventBus);
        STRUCTURE_PIECE_TYPE.register(modEventBus);
        modEventBus.addListener(this::onRegister);
        IEventBus forgeEventBus = NeoForge.EVENT_BUS;
        forgeEventBus.addListener(this::onAddReloadListener);
        ModStructureTypes.init();
        ModStructurePieceTypes.init();
    }

    private void onRegister(RegisterEvent event) {
        event.register(Registries.LOOT_FUNCTION_TYPE, Loot::registerLootFunctions);
    }

    private void onAddReloadListener(AddServerReloadListenersEvent event) {
        event.addListener(locate("server_resources"), new ResourceReloadHandler());
    }

    public static Identifier locate(String path) {
        return Identifier.fromNamespaceAndPath("dungeonsall", path);
    }

    public static Identifier key(Identifier identifier, String baseDirectory, String fileEnding) {
        String path = identifier.getPath();
        return Identifier.fromNamespaceAndPath(identifier.getNamespace(), path.substring(baseDirectory.length() + 1, path.length() - fileEnding.length()));
    }
}
