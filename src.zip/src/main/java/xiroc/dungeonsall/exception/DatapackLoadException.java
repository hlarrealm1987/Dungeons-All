package xiroc.dungeonsall.exception;

public class DatapackLoadException extends RuntimeException {
    public DatapackLoadException(String message) {
        super(message);
    }
}
