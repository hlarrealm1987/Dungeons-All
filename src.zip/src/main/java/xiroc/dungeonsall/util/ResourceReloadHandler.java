package xiroc.dungeonsall.util;

import java.util.ArrayList;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.minecraft.server.packs.resources.PreparableReloadListener;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.PreparableReloadListener.PreparationBarrier;
import net.minecraft.server.packs.resources.PreparableReloadListener.SharedState;
import net.minecraft.util.Unit;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.DungeonType;
import xiroc.dungeonsall.dungeon.model.DungeonModels;
import xiroc.dungeonsall.dungeon.model.ModelPools;
import xiroc.dungeonsall.dungeon.monster.RandomEquipment;
import xiroc.dungeonsall.dungeon.monster.RandomMonster;
import xiroc.dungeonsall.dungeon.monster.RandomPotionEffect;
import xiroc.dungeonsall.dungeon.monster.SpawnRates;
import xiroc.dungeonsall.dungeon.treasure.RandomItems;
import xiroc.dungeonsall.theme.Theme;

public class ResourceReloadHandler implements PreparableReloadListener {
    public static final ArrayList<Updatable> PENDING_UPDATES = new ArrayList();

    public void reload(ResourceManager resourceManager) {
        DungeonsAll.LOGGER.info("Loading data...");
        PENDING_UPDATES.clear();
        DungeonModels.load(resourceManager);
        ModelPools.load(resourceManager);
        DungeonType.load(resourceManager);
        Theme.loadJson(resourceManager);
        SpawnRates.loadJson(resourceManager);
        RandomItems.loadJson(resourceManager);
        RandomMonster.loadJson(resourceManager);
        RandomEquipment.loadJson(resourceManager);
        RandomPotionEffect.loadJson(resourceManager);
        DungeonsAll.LOGGER.debug("Completing...");
        PENDING_UPDATES.forEach(Updatable::update);
        PENDING_UPDATES.clear();
        DungeonsAll.LOGGER.info("Done.");
    }

    public CompletableFuture<Void> reload(SharedState currentReload, Executor taskExecutor, PreparationBarrier preparationBarrier, Executor reloadExecutor) {
        return preparationBarrier.wait(Unit.INSTANCE).thenRunAsync(() -> this.reload(currentReload.resourceManager()));
    }

    public String getName() {
        return "Dungeons All Resource Reload Listener";
    }
}
