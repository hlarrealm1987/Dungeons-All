package xiroc.dungeonsall.util;

import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

public record Range(int min, int max) {
    public int nextInt(RandomSource random) {
        return Mth.nextInt(random, this.min, this.max);
    }
}
