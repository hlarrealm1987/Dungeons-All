package xiroc.dungeonsall.util;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.config.Config;
import xiroc.dungeonsall.dungeon.block.Furnace;
import xiroc.dungeonsall.dungeon.block.Plants;
import xiroc.dungeonsall.dungeon.block.Spawner;
import xiroc.dungeonsall.theme.SecondaryTheme;
import xiroc.dungeonsall.theme.Theme;

public interface IBlockPlacementHandler {
    IBlockPlacementHandler SPAWNER = new Spawner();
    IBlockPlacementHandler DEFAULT = (world, state, pos, rand, theme, secondaryTheme, lootLevel) -> {
        if ((Boolean)Config.TICK_FALLING_BLOCKS.get() && state.getBlock() instanceof FallingBlock) {
            world.scheduleTick(pos, state.getBlock(), 1);
        }

        world.setBlock(pos, state, 2);
    };
    ImmutableMap<Block, IBlockPlacementHandler> PLACEMENT_HANDLERS = new Builder()
        .put(Blocks.FURNACE, new Furnace())
        .put(Blocks.SMOKER, new Furnace.Smoker())
        .put(Blocks.SPAWNER, SPAWNER)
        .put(Blocks.FARMLAND, new Plants.Farmland())
        .put(Blocks.FLOWER_POT, new Plants.FlowerPot())
        .put(Blocks.PODZOL, new Plants.Podzol())
        .build();

    void place(LevelAccessor var1, BlockState var2, BlockPos var3, RandomSource var4, Theme var5, SecondaryTheme var6, int var7);

    static IBlockPlacementHandler getHandler(Block block) {
        return (IBlockPlacementHandler)PLACEMENT_HANDLERS.getOrDefault(block, DEFAULT);
    }
}
