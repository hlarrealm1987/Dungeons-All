package xiroc.dungeonsall.util;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Optional;
import net.minecraft.core.Vec3i;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.neoforged.fml.ModList;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.model.DungeonModels;

public class JSONUtils {
    public static boolean areRequirementsMet(JsonObject object) {
        if (object.has("requirements")) {
            JsonObject conditions = object.getAsJsonObject("requirements");
            if (conditions.has("present")) {
                for (JsonElement mod : conditions.getAsJsonArray("present")) {
                    if (!ModList.get().isLoaded(mod.getAsString())) {
                        return false;
                    }
                }
            }

            if (conditions.has("absent")) {
                for (JsonElement mod : conditions.getAsJsonArray("absent")) {
                    if (ModList.get().isLoaded(mod.getAsString())) {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public static BlockState deserializeBlockStateProperties(Block block, JsonObject element) {
        BlockState state = block.defaultBlockState();
        if (element.has("properties")) {
            JsonObject data = element.get("properties").getAsJsonObject();

            for (Property<?> property : state.getProperties()) {
                if (data.has(property.getName())) {
                    state = parseProperty(state, property, data.get(property.getName()).getAsString());
                }
            }
        }

        return state;
    }

    public static int getWeight(JsonObject object) {
        return object.has("weight") ? object.get("weight").getAsInt() : 1;
    }

    public static Vec3i getOffset(JsonObject jsonObject) {
        int x = 0;
        int y = 0;
        int z = 0;
        if (jsonObject.has("x")) {
            x = jsonObject.get("x").getAsInt();
        }

        if (jsonObject.has("y")) {
            y = jsonObject.get("y").getAsInt();
        }

        if (jsonObject.has("z")) {
            z = jsonObject.get("z").getAsInt();
        }

        return x == 0 && y == 0 && z == 0 ? DungeonModels.NO_OFFSET : new Vec3i(x, y, z);
    }

    private static <T extends Comparable<T>> BlockState parseProperty(BlockState state, Property<T> property, String value) {
        Optional<T> optional = property.getValue(value);
        if (optional.isPresent()) {
            T t = (T)optional.get();
            return (BlockState)state.setValue(property, t);
        } else {
            DungeonsAll.LOGGER
                .warn("Couldn't apply property {} with value {} to {}", property.getName(), value, BuiltInRegistries.BLOCK.getKey(state.getBlock()));
            return state;
        }
    }

    public static JsonObject serializeBlockState(JsonObject object, BlockState state) {
        Block block = state.getBlock();
        Identifier registryName = BuiltInRegistries.BLOCK.getKey(block);
        if (registryName == null) {
            DungeonsAll.LOGGER.error("No registry name found for block {} ({})", block, block.getClass());
            return new JsonObject();
        }

        object.addProperty("block", registryName.toString());
        BlockState defaultState = block.defaultBlockState();
        JsonObject properties = new JsonObject();
        state.getProperties().forEach(property -> {
            if (!state.getValue(property).equals(defaultState.getValue(property))) {
                properties.addProperty(property.getName(), state.getValue(property).toString());
            }
        });
        if (properties.size() > 0) {
            object.add("properties", properties);
        }

        return object;
    }
}
