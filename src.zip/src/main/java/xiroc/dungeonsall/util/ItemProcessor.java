package xiroc.dungeonsall.util;

import net.minecraft.world.item.ItemStack;

@FunctionalInterface
public interface ItemProcessor<W, R, L> {
    ItemStack generate(W var1, R var2, L var3);
}
