package xiroc.dungeonsall.util;

public interface Updatable {
    void update();
}
