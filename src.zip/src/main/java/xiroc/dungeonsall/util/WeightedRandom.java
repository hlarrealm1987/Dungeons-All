package xiroc.dungeonsall.util;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.google.common.collect.UnmodifiableIterator;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.Collection;
import java.util.List;
import net.minecraft.resources.Identifier;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import xiroc.dungeonsall.dungeon.monster.RandomEquipment;

public class WeightedRandom<T> implements IRandom<T> {
    public static final WeightedRandom.JsonReader<Item> ITEM = entries -> {
        WeightedRandom.Builder<Item> builder = new WeightedRandom.Builder<>();
        entries.forEach(element -> {
            JsonObject entry = element.getAsJsonObject();
            int weight = JSONUtils.getWeight(entry);
            builder.add(RandomEquipment.getItem(Identifier.parse(entry.get("item").getAsString())), weight);
        });
        return builder.build();
    };
    private final int totalWeight;
    private final ImmutableList<Pair<T, Integer>> entries;
    private final ImmutableList<Pair<T, Integer>> originalEntries;

    public WeightedRandom(List<Pair<T, Integer>> entries) {
        this.originalEntries = ImmutableList.copyOf(entries);
        com.google.common.collect.ImmutableList.Builder<Pair<T, Integer>> builder = new com.google.common.collect.ImmutableList.Builder();
        int weight = 0;

        for (Pair<T, Integer> entry : entries) {
            if (entry.right() > 0) {
                weight += entry.right();
                builder.add(new Pair<>(entry.left(), weight));
            }
        }

        this.entries = builder.build();
        this.totalWeight = weight;
    }

    @Override
    public T roll(RandomSource rand) {
        int r = rand.nextInt(this.totalWeight);
        UnmodifiableIterator var3 = this.entries.iterator();

        while (var3.hasNext()) {
            Pair<T, Integer> entry = (Pair<T, Integer>)var3.next();
            if (r < entry.right()) {
                return entry.left();
            }
        }

        return null;
    }

    public boolean isEmpty() {
        return this.entries.isEmpty();
    }

    public int size() {
        return this.entries.size();
    }

    public ImmutableList<Pair<T, Integer>> getEntries() {
        return this.originalEntries;
    }

    public static class Builder<T> {
        public final List<Pair<T, Integer>> entries = Lists.newArrayList();

        public WeightedRandom.Builder<T> add(T t, int weight) {
            this.entries.add(new Pair<>(t, weight));
            return this;
        }

        public void addAll(Collection<Pair<T, Integer>> entries) {
            this.entries.addAll(entries);
        }

        public WeightedRandom<T> build() {
            return new WeightedRandom<>(this.entries);
        }
    }

    @FunctionalInterface
    public interface JsonReader<T> {
        WeightedRandom<T> fromJson(JsonArray var1);
    }
}
