package xiroc.dungeonsall.util;

import net.minecraft.util.RandomSource;

public interface IRandom<T> {
    T roll(RandomSource var1);
}
