package xiroc.dungeonsall.util;

import net.minecraft.core.Direction;

public class Position2D {
    public final int x;
    public final int z;

    public Position2D(int x, int z) {
        this.x = x;
        this.z = z;
    }

    public boolean isValid(int xBound, int zBound) {
        return this.x > -1 && this.z > -1 && this.x < xBound && this.z < zBound;
    }

    public boolean isValid(int bound) {
        return this.x > -1 && this.z > -1 && this.x < bound && this.z < bound;
    }

    public Direction directionTo(Position2D pos) {
        if (pos.x > this.x) {
            return Direction.EAST;
        } else if (pos.x < this.x) {
            return Direction.WEST;
        } else if (pos.z > this.z) {
            return Direction.SOUTH;
        } else if (pos.z < this.z) {
            return Direction.NORTH;
        } else {
            throw new IllegalArgumentException("The target position must not be equal to the origin position.");
        }
    }

    public static boolean isValid(int x, int z, int xBound, int zBound) {
        return x >= 0 && z >= 0 && x < xBound && z < zBound;
    }

    public Position2D shift(Direction direction, int amount) {
        return switch (direction) {
            case NORTH -> new Position2D(this.x, this.z - amount);
            case EAST -> new Position2D(this.x + amount, this.z);
            case SOUTH -> new Position2D(this.x, this.z + amount);
            case WEST -> new Position2D(this.x - amount, this.z);
            default -> this;
        };
    }
}
