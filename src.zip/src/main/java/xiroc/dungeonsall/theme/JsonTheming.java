package xiroc.dungeonsall.theme;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.block.provider.SingleBlock;
import xiroc.dungeonsall.dungeon.block.provider.WeightedRandomBlock;
import xiroc.dungeonsall.dungeon.block.provider.pattern.CheckerboardPattern;
import xiroc.dungeonsall.dungeon.block.provider.pattern.TerracottaPattern;
import xiroc.dungeonsall.dungeon.decoration.DungeonDecoration;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.WeightedRandom;

public class JsonTheming {
    protected static Theme deserializeTheme(JsonObject object, Identifier file) {
        JsonObject themeObject = object.get("theme").getAsJsonObject();
        Theme.Builder themeBuilder = Theme.builder();
        themeBuilder.solid(deserialize(themeObject, "solid", file))
            .generic(deserialize(themeObject, "generic", file))
            .pillar(deserialize(themeObject, "pillar", file))
            .fencing(deserialize(themeObject, "fencing", file))
            .floor(deserialize(themeObject, "floor", file))
            .fluid(deserialize(themeObject, "fluid", file))
            .material(deserialize(themeObject, "material", file))
            .stairs(deserialize(themeObject, "stairs", file))
            .solidStairs(deserialize(themeObject, "solid_stairs", file))
            .slab(deserialize(themeObject, "slab", file))
            .solidSlab(deserialize(themeObject, "solid_slab", file))
            .wall(deserialize(themeObject, "wall", file));
        if (object.has("decorations")) {
            object.getAsJsonArray("decorations").forEach(element -> themeBuilder.addDecoration(DungeonDecoration.fromJson(element.getAsJsonObject(), file)));
        }

        if (object.has("secondary_theme")) {
            WeightedRandom.Builder<SecondaryTheme> builder = new WeightedRandom.Builder<>();
            object.getAsJsonArray("secondary_theme").forEach(element -> {
                JsonObject instance = element.getAsJsonObject();
                Identifier key = Identifier.parse(instance.get("key").getAsString());
                if (Theme.KEY_TO_SECONDARY_THEME.containsKey(key)) {
                    builder.add((SecondaryTheme)Theme.KEY_TO_SECONDARY_THEME.get(key), JSONUtils.getWeight(instance));
                } else {
                    throw new DatapackLoadException("Unknown secondary theme key " + key + " in " + file.toString());
                }
            });
            themeBuilder.secondaryTheme(builder.build());
        }

        if (object.has("id")) {
            int id = object.get("id").getAsInt();
            themeBuilder.legacyId(id);
        }

        return themeBuilder.build();
    }

    protected static SecondaryTheme deserializeSecondaryTheme(JsonObject object, Identifier file) {
        JsonObject themeObject = object.get("theme").getAsJsonObject();
        SecondaryTheme.Builder themeBuilder = SecondaryTheme.builder();
        themeBuilder.pillar(deserialize(themeObject, "pillar", file))
            .trapdoor(deserialize(themeObject, "trapdoor", file))
            .door(deserialize(themeObject, "door", file))
            .material(deserialize(themeObject, "material", file))
            .stairs(deserialize(themeObject, "stairs", file))
            .slab(deserialize(themeObject, "slab", file))
            .fence(deserialize(themeObject, "fence", file))
            .fenceGate(deserialize(themeObject, "fence_gate", file))
            .button(deserialize(themeObject, "button", file))
            .pressurePlate(deserialize(themeObject, "pressure_plate", file));
        if (object.has("id")) {
            themeBuilder.legacyId(object.get("id").getAsInt());
        }

        return themeBuilder.build();
    }

    protected static void deserializeThemeMapping(
        JsonObject object, Map<String, WeightedRandom.Builder<Theme>> themeMappingBuilders, WeightedRandom.Builder<Theme> defaultBuilder, Identifier file
    ) {
        if (JSONUtils.areRequirementsMet(object)) {
            object.getAsJsonObject("mapping")
                .entrySet()
                .forEach(
                    entry -> {
                        ArrayList<Pair<Identifier, Integer>> mappings = listThemes(entry);
                        mappings.forEach(
                            mapping -> {
                                if (!Theme.KEY_TO_THEME.containsKey(mapping.left())) {
                                    throw new DatapackLoadException("Cannot resolve theme key " + mapping.left() + " in " + file.toString());
                                }

                                ((WeightedRandom.Builder)themeMappingBuilders.computeIfAbsent((String)entry.getKey(), var0x -> new WeightedRandom.Builder()))
                                    .add((Theme)Theme.KEY_TO_THEME.get(mapping.left()), (Integer)mapping.right());
                            }
                        );
                    }
                );
            if (object.has("default")) {
                object.getAsJsonArray("default").forEach(element -> {
                    JsonObject entry = element.getAsJsonObject();
                    Identifier theme = Identifier.parse(entry.get("key").getAsString());
                    if (!Theme.KEY_TO_THEME.containsKey(theme)) {
                        throw new DatapackLoadException("Cannot resolve theme key " + theme + " in the default case of " + file);
                    }

                    defaultBuilder.add((Theme)Theme.KEY_TO_THEME.get(theme), JSONUtils.getWeight(entry));
                });
            }
        }
    }

    protected static void deserializeSecondaryThemeMapping(
        JsonObject object,
        Map<String, WeightedRandom.Builder<SecondaryTheme>> secondaryThemeMappingBuilders,
        WeightedRandom.Builder<SecondaryTheme> defaultBuilder,
        Identifier file
    ) {
        if (JSONUtils.areRequirementsMet(object)) {
            object.getAsJsonObject("mapping")
                .entrySet()
                .forEach(
                    entry -> {
                        ArrayList<Pair<Identifier, Integer>> mappings = listThemes(entry);
                        mappings.forEach(
                            mapping -> {
                                if (!Theme.KEY_TO_SECONDARY_THEME.containsKey(mapping.left())) {
                                    throw new DatapackLoadException("Cannot resolve secondary theme key " + mapping.right() + " in " + file.toString());
                                }

                                ((WeightedRandom.Builder)secondaryThemeMappingBuilders.computeIfAbsent(
                                        (String)entry.getKey(), var0x -> new WeightedRandom.Builder()
                                    ))
                                    .add((SecondaryTheme)Theme.KEY_TO_SECONDARY_THEME.get(mapping.left()), (Integer)mapping.right());
                            }
                        );
                    }
                );
            if (object.has("default")) {
                object.getAsJsonArray("default").forEach(element -> {
                    JsonObject entry = element.getAsJsonObject();
                    Identifier theme = Identifier.parse(entry.get("key").getAsString());
                    if (!Theme.KEY_TO_SECONDARY_THEME.containsKey(theme)) {
                        throw new DatapackLoadException("Cannot resolve secondary theme key " + theme + " in the default case of " + file);
                    }

                    defaultBuilder.add((SecondaryTheme)Theme.KEY_TO_SECONDARY_THEME.get(theme), JSONUtils.getWeight(entry));
                });
            }
        }
    }

    private static ArrayList<Pair<Identifier, Integer>> listThemes(Entry<String, JsonElement> entry) {
        ArrayList<Pair<Identifier, Integer>> entries = new ArrayList();
        ((JsonElement)entry.getValue()).getAsJsonArray().forEach(element -> {
            JsonObject jsonObject = element.getAsJsonObject();
            entries.add(new Pair<>(Identifier.parse(jsonObject.get("key").getAsString()), JSONUtils.getWeight(jsonObject)));
        });
        return entries;
    }

    protected static void deserializeRandomThemeFile(
        JsonObject object, WeightedRandom.Builder<Theme> themes, WeightedRandom.Builder<SecondaryTheme> secondaryThemes, Identifier file
    ) {
        if (JSONUtils.areRequirementsMet(object)) {
            if (object.has("primary_themes")) {
                object.getAsJsonArray("primary_themes").forEach(element -> {
                    JsonObject entry = element.getAsJsonObject();
                    Identifier key = Identifier.parse(entry.get("key").getAsString());
                    if (Theme.KEY_TO_THEME.containsKey(key)) {
                        themes.add((Theme)Theme.KEY_TO_THEME.get(key), JSONUtils.getWeight(entry));
                    } else {
                        throw new DatapackLoadException("Cannot resolve primary theme key " + key + " in " + file);
                    }
                });
            }

            if (object.has("secondary_themes")) {
                object.getAsJsonArray("secondary_themes").forEach(element -> {
                    JsonObject entry = element.getAsJsonObject();
                    Identifier key = Identifier.parse(entry.get("key").getAsString());
                    if (Theme.KEY_TO_SECONDARY_THEME.containsKey(key)) {
                        secondaryThemes.add((SecondaryTheme)Theme.KEY_TO_SECONDARY_THEME.get(key), JSONUtils.getWeight(entry));
                    } else {
                        throw new DatapackLoadException("Cannot resolve secondary theme key " + key + " in " + file);
                    }
                });
            }
        }
    }

    public static BlockStateProvider deserialize(JsonObject base, String name, Identifier file) {
        if (!base.has(name)) {
            DungeonsAll.LOGGER.warn("Missing BlockState Provider \"{}\" in {}", name, file.toString());
            return null;
        }

        JsonObject object = (JsonObject)base.get(name);
        if (object.has("type")) {
            String type = object.get("type").getAsString();
            if (type.equalsIgnoreCase("random_block")) {
                JsonArray blockObjects = object.get("blocks").getAsJsonArray();
                WeightedRandom.Builder<BlockState> builder = new WeightedRandom.Builder<>();

                for (JsonElement blockElement : blockObjects) {
                    JsonObject blockObject = (JsonObject)blockElement;
                    Block block = (Block)BuiltInRegistries.BLOCK.get(Identifier.parse(blockObject.get("block").getAsString())).map(Holder::value).orElse(null);
                    if (block != null) {
                        BlockState state = JSONUtils.deserializeBlockStateProperties(block, blockObject);
                        builder.add(state, JSONUtils.getWeight(blockObject));
                    } else {
                        DungeonsAll.LOGGER.error("Unknown block: {}", blockObject.get("block").getAsString());
                    }
                }

                return new WeightedRandomBlock(builder.build());
            } else if (type.equalsIgnoreCase("block")) {
                Block block = (Block)BuiltInRegistries.BLOCK.get(Identifier.parse(object.get("block").getAsString())).map(Holder::value).orElse(null);
                if (block != null) {
                    BlockState state = JSONUtils.deserializeBlockStateProperties(block, object);
                    return new SingleBlock(state);
                } else {
                    DungeonsAll.LOGGER.error("Unknown block: {}", object.get("block").getAsString());
                    return new SingleBlock(Blocks.CAVE_AIR.defaultBlockState());
                }
            } else if (type.equalsIgnoreCase("pattern")) {
                switch (object.get("pattern_type").getAsString().toLowerCase(Locale.ROOT)) {
                    case "checkerboard":
                        return new CheckerboardPattern(deserialize(object, "block_1", file), deserialize(object, "block_2", file));
                    case "terracotta":
                        return new TerracottaPattern(deserialize(object, "block", file));
                    default:
                        DungeonsAll.LOGGER.error("Unknown block pattern type: " + object.get("pattern_type").getAsString());
                        return null;
                }
            } else {
                DungeonsAll.LOGGER.error("Failed to load BlockState Provider {}: Unknown type {}.", object, type);
                return null;
            }
        } else {
            DungeonsAll.LOGGER.error("Invalid BlockState Provider \"{}\": Type not specified.", name);
            return null;
        }
    }
}
