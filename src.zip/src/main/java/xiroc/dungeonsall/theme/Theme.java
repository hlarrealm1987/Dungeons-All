package xiroc.dungeonsall.theme;

import com.google.common.collect.ImmutableSet;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import org.jline.utils.InputStreamReader;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.block.provider.BlockStateProvider;
import xiroc.dungeonsall.dungeon.block.provider.SingleBlock;
import xiroc.dungeonsall.dungeon.decoration.DungeonDecoration;
import xiroc.dungeonsall.exception.DatapackLoadException;
import xiroc.dungeonsall.util.IRandom;
import xiroc.dungeonsall.util.JSONUtils;
import xiroc.dungeonsall.util.Pair;
import xiroc.dungeonsall.util.WeightedRandom;

public class Theme {
    public static final Theme BUILTIN_DEFAULT_THEME = new Theme(
        new SingleBlock(Blocks.STONE_BRICKS.defaultBlockState()),
        new SingleBlock(Blocks.STONE_BRICKS.defaultBlockState()),
        new SingleBlock(Blocks.COBBLESTONE.defaultBlockState()),
        new SingleBlock(Blocks.GRAVEL.defaultBlockState()),
        new SingleBlock(Blocks.STONE_BRICK_STAIRS.defaultBlockState()),
        new SingleBlock(Blocks.COBBLESTONE_STAIRS.defaultBlockState()),
        new SingleBlock(Blocks.COBBLESTONE.defaultBlockState()),
        new SingleBlock(Blocks.COBBLESTONE_WALL.defaultBlockState()),
        new SingleBlock(Blocks.COBBLESTONE_SLAB.defaultBlockState()),
        new SingleBlock(Blocks.STONE_BRICK_SLAB.defaultBlockState()),
        new SingleBlock(Blocks.IRON_BARS.defaultBlockState()),
        new SingleBlock(Blocks.WATER.defaultBlockState())
    );
    public static final SecondaryTheme BUILTIN_DEFAULT_SECONDARY_THEME = new SecondaryTheme(
        new SingleBlock(Blocks.OAK_LOG.defaultBlockState()),
        new SingleBlock(Blocks.OAK_TRAPDOOR.defaultBlockState()),
        new SingleBlock(Blocks.OAK_DOOR.defaultBlockState()),
        new SingleBlock(Blocks.OAK_PLANKS.defaultBlockState()),
        new SingleBlock(Blocks.OAK_STAIRS.defaultBlockState()),
        new SingleBlock(Blocks.OAK_SLAB.defaultBlockState()),
        new SingleBlock(Blocks.OAK_FENCE.defaultBlockState()),
        new SingleBlock(Blocks.OAK_FENCE_GATE.defaultBlockState()),
        new SingleBlock(Blocks.OAK_BUTTON.defaultBlockState()),
        new SingleBlock(Blocks.OAK_PRESSURE_PLATE.defaultBlockState())
    );
    protected static final Hashtable<String, IRandom<Theme>> BIOME_TO_THEME = new Hashtable();
    protected static final Hashtable<String, IRandom<SecondaryTheme>> BIOME_TO_SECONDARY_THEME = new Hashtable();
    public static final Hashtable<Identifier, Theme> KEY_TO_THEME = new Hashtable();
    public static final Hashtable<Identifier, SecondaryTheme> KEY_TO_SECONDARY_THEME = new Hashtable();
    private static WeightedRandom<Theme> DEFAULT_TOP_THEME = null;
    private static WeightedRandom<SecondaryTheme> DEFAULT_SECONDARY_TOP_THEME = null;
    private static IRandom<Theme> CATACOMBS_THEME = rand -> {
        throw new IllegalStateException();
    };
    private static IRandom<Theme> LOWER_CATACOMBS_THEME = rand -> {
        throw new IllegalStateException();
    };
    private static IRandom<Theme> HELL_THEME = rand -> {
        throw new IllegalStateException();
    };
    private static IRandom<SecondaryTheme> CATACOMBS_SECONDARY_THEME = rand -> {
        throw new IllegalStateException();
    };
    private static IRandom<SecondaryTheme> LOWER_CATACOMBS_SECONDARY_THEME = rand -> {
        throw new IllegalStateException();
    };
    private static IRandom<SecondaryTheme> HELL_SECONDARY_THEME = rand -> {
        throw new IllegalStateException();
    };
    public static final Hashtable<Integer, Theme> ID_TO_THEME = new Hashtable();
    public static final Hashtable<Integer, SecondaryTheme> ID_TO_SECONDARY_THEME = new Hashtable();
    private static final Identifier PRIMARY_THEME_FALLBACK = DungeonsAll.locate("vanilla/default");
    private static final Identifier SECONDARY_THEME_FALLBACK = DungeonsAll.locate("vanilla/oak");
    public static final Identifier PRIMARY_HELL_MOSSY = DungeonsAll.locate("vanilla/hell/mossy");
    private static final String PRIMARY_THEME_DIRECTORY = "theming/primary_themes";
    private static final String SECONDARY_THEME_DIRECTORY = "theming/secondary_themes";
    private static final String PRIMARY_THEME_MAPPINGS_DIRECTORY = "theming/mappings/primary";
    private static final String SECONDARY_THEME_MAPPINGS_DIRECTORY = "theming/mappings/secondary";
    private static final String UPPER_CATACOMBS_THEMES_DIRECTORY = "theming/lower_layers/upper_catacombs";
    private static final String CATACOMBS_THEMES_DIRECTORY = "theming/lower_layers/catacombs";
    private static final String HELL_THEMES_DIRECTORY = "theming/lower_layers/hell";
    private static ImmutableSet<Identifier> THEME_KEYS;
    private static ImmutableSet<Identifier> SECONDARY_THEME_KEYS;
    public final BlockStateProvider pillar;
    public final BlockStateProvider solid;
    public final BlockStateProvider generic;
    public final BlockStateProvider floor;
    public final BlockStateProvider solidStairs;
    public final BlockStateProvider stairs;
    public final BlockStateProvider material;
    public final BlockStateProvider wall;
    public final BlockStateProvider slab;
    public final BlockStateProvider solidSlab;
    public final BlockStateProvider fencing;
    public final BlockStateProvider fluid;
    public IRandom<SecondaryTheme> secondaryTheme;
    protected Identifier key;
    @Nullable
    private DungeonDecoration[] decorations;
    @Nullable
    protected Integer id;

    public Theme(
        BlockStateProvider pillar,
        BlockStateProvider solid,
        BlockStateProvider generic,
        BlockStateProvider floor,
        BlockStateProvider solidStairs,
        BlockStateProvider stairs,
        BlockStateProvider material,
        BlockStateProvider wall,
        BlockStateProvider slab,
        BlockStateProvider solidSlab,
        BlockStateProvider fencing,
        BlockStateProvider fluid
    ) {
        this.solid = solid;
        this.material = material;
        this.generic = generic;
        this.pillar = pillar;
        this.floor = floor;
        this.stairs = stairs;
        this.solidStairs = solidStairs;
        this.slab = slab;
        this.solidSlab = solidSlab;
        this.wall = wall;
        this.fencing = fencing;
        this.fluid = fluid;
    }

    public void setDecorations(@Nullable DungeonDecoration[] decorations) {
        this.decorations = decorations;
    }

    public boolean hasDecorations() {
        return this.decorations != null;
    }

    public Identifier getKey() {
        return this.key;
    }

    public DungeonDecoration[] getDecorations() {
        return this.decorations;
    }

    public BlockStateProvider getPillar() {
        return this.pillar;
    }

    public BlockStateProvider getSolid() {
        return this.solid;
    }

    public BlockStateProvider getGeneric() {
        return this.generic;
    }

    public BlockStateProvider getFencing() {
        return this.fencing;
    }

    public BlockStateProvider getFloor() {
        return this.floor;
    }

    public BlockStateProvider getFluid() {
        return this.fluid;
    }

    public BlockStateProvider getSolidStairs() {
        return this.solidStairs;
    }

    public BlockStateProvider getStairs() {
        return this.stairs;
    }

    public BlockStateProvider getMaterial() {
        return this.material;
    }

    public BlockStateProvider getWall() {
        return this.wall;
    }

    public BlockStateProvider getSlab() {
        return this.slab;
    }

    public BlockStateProvider getSolidSlab() {
        return this.solidSlab;
    }

    public JsonObject serialize() {
        JsonObject object = new JsonObject();
        if (this.decorations != null) {
            JsonArray decorations = new JsonArray();

            for (DungeonDecoration decoration : this.decorations) {
                decorations.add(decoration.serialize());
            }

            object.add("decorations", decorations);
        }

        JsonObject theme = new JsonObject();
        theme.add("pillar", this.pillar.serialize());
        theme.add("solid", this.solid.serialize());
        theme.add("generic", this.generic.serialize());
        theme.add("fencing", this.fencing.serialize());
        theme.add("floor", this.floor.serialize());
        theme.add("fluid", this.fluid.serialize());
        theme.add("solid_stairs", this.solidStairs.serialize());
        theme.add("stairs", this.stairs.serialize());
        theme.add("material", this.material.serialize());
        theme.add("wall", this.wall.serialize());
        theme.add("slab", this.slab.serialize());
        theme.add("solid_slab", this.solidSlab.serialize());
        object.add("theme", theme);
        return object;
    }

    public static void loadJson(ResourceManager resourceManager) {
        ID_TO_THEME.clear();
        ID_TO_SECONDARY_THEME.clear();
        KEY_TO_THEME.clear();
        KEY_TO_SECONDARY_THEME.clear();
        BIOME_TO_THEME.clear();
        BIOME_TO_SECONDARY_THEME.clear();
        com.google.common.collect.ImmutableSet.Builder<Identifier> themeKeySetBuilder = new com.google.common.collect.ImmutableSet.Builder();
        com.google.common.collect.ImmutableSet.Builder<Identifier> secondaryThemeKeySetBuilder = new com.google.common.collect.ImmutableSet.Builder();
        resourceManager.listResources(DungeonsAll.locate("theming/secondary_themes").getPath(), s -> s.getPath().endsWith(".json"))
            .forEach((file, resource) -> {
                DungeonsAll.LOGGER.debug("Loading {}", file);

                try {
                    JsonReader reader = new JsonReader(new InputStreamReader(resource.open()));
                    Identifier key = DungeonsAll.key(file, "theming/secondary_themes", ".json");
                    JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                    if (JSONUtils.areRequirementsMet(json)) {
                        SecondaryTheme theme = JsonTheming.deserializeSecondaryTheme(json, file);
                        theme.key = key;
                        secondaryThemeKeySetBuilder.add(key);
                        KEY_TO_SECONDARY_THEME.put(key, theme);
                    }
                } catch (Exception e) {
                    DungeonsAll.LOGGER.error("Failed to load {}", resource.toString());
                    e.printStackTrace();
                }
            });
        resourceManager.listResources(DungeonsAll.locate("theming/primary_themes").getPath(), s -> s.getPath().endsWith(".json")).forEach((file, resource) -> {
            DungeonsAll.LOGGER.debug("Loading {}", file);

            try {
                JsonReader reader = new JsonReader(new InputStreamReader(resource.open()));
                Identifier key = DungeonsAll.key(file, "theming/primary_themes", ".json");
                JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
                if (JSONUtils.areRequirementsMet(json)) {
                    Theme theme = JsonTheming.deserializeTheme(json, file);
                    theme.key = key;
                    themeKeySetBuilder.add(key);
                    KEY_TO_THEME.put(key, theme);
                }
            } catch (Exception e) {
                DungeonsAll.LOGGER.error("Failed to load {}", resource.toString());
                e.printStackTrace();
            }
        });
        Hashtable<String, WeightedRandom.Builder<Theme>> themeMappingBuilders = new Hashtable();
        Hashtable<String, WeightedRandom.Builder<SecondaryTheme>> secondaryThemeMappingBuilders = new Hashtable();
        WeightedRandom.Builder<Theme> primaryDefaultBuilder = new WeightedRandom.Builder<>();
        WeightedRandom.Builder<SecondaryTheme> secondaryDefaultBuilder = new WeightedRandom.Builder<>();
        resourceManager.listResources("theming/mappings/primary", s -> s.getPath().endsWith(".json")).forEach((file, resource) -> {
            try {
                JsonReader reader = new JsonReader(new InputStreamReader(resource.open()));
                JsonTheming.deserializeThemeMapping(JsonParser.parseReader(reader).getAsJsonObject(), themeMappingBuilders, primaryDefaultBuilder, file);
            } catch (IOException e) {
                DungeonsAll.LOGGER.error("Failed to load {}", resource);
                e.printStackTrace();
            }
        });
        resourceManager.listResources("theming/mappings/secondary", s -> s.getPath().endsWith(".json"))
            .forEach(
                (file, resource) -> {
                    try {
                        JsonReader reader = new JsonReader(new InputStreamReader(resource.open()));
                        JsonTheming.deserializeSecondaryThemeMapping(
                            JsonParser.parseReader(reader).getAsJsonObject(), secondaryThemeMappingBuilders, secondaryDefaultBuilder, file
                        );
                    } catch (IOException e) {
                        DungeonsAll.LOGGER.error("Failed to load {}", resource);
                        e.printStackTrace();
                    }
                }
            );
        themeMappingBuilders.forEach((biome, builder) -> BIOME_TO_THEME.put(biome, builder.build()));
        secondaryThemeMappingBuilders.forEach((biome, builder) -> BIOME_TO_SECONDARY_THEME.put(biome, builder.build()));
        DEFAULT_TOP_THEME = primaryDefaultBuilder.build();
        DEFAULT_SECONDARY_TOP_THEME = secondaryDefaultBuilder.build();
        if (DEFAULT_TOP_THEME.isEmpty()) {
            throw new DatapackLoadException("No default primary themes are specified in the mappings.");
        }

        if (DEFAULT_SECONDARY_TOP_THEME.isEmpty()) {
            throw new DatapackLoadException("No default secondary themes are specified in the mappings.");
        }

        THEME_KEYS = themeKeySetBuilder.build();
        SECONDARY_THEME_KEYS = secondaryThemeKeySetBuilder.build();
        Pair<WeightedRandom<Theme>, WeightedRandom<SecondaryTheme>> catacombs = loadRandomThemeFiles("theming/lower_layers/upper_catacombs", resourceManager);
        Pair<WeightedRandom<Theme>, WeightedRandom<SecondaryTheme>> lowerCatacombs = loadRandomThemeFiles("theming/lower_layers/catacombs", resourceManager);
        Pair<WeightedRandom<Theme>, WeightedRandom<SecondaryTheme>> hell = loadRandomThemeFiles("theming/lower_layers/hell", resourceManager);
        CATACOMBS_THEME = catacombs.left();
        CATACOMBS_SECONDARY_THEME = catacombs.right();
        LOWER_CATACOMBS_THEME = lowerCatacombs.left();
        LOWER_CATACOMBS_SECONDARY_THEME = lowerCatacombs.right();
        HELL_THEME = hell.left();
        HELL_SECONDARY_THEME = hell.right();
    }

    private static Pair<WeightedRandom<Theme>, WeightedRandom<SecondaryTheme>> loadRandomThemeFiles(String directory, ResourceManager resourceManager) {
        WeightedRandom.Builder<Theme> primary = new WeightedRandom.Builder<>();
        WeightedRandom.Builder<SecondaryTheme> secondary = new WeightedRandom.Builder<>();
        resourceManager.listResources(directory, s -> s.getPath().endsWith(".json")).forEach((file, resource) -> {
            try {
                JsonReader reader = new JsonReader(new InputStreamReader(resource.open()));
                JsonTheming.deserializeRandomThemeFile(JsonParser.parseReader(reader).getAsJsonObject(), primary, secondary, file);
            } catch (IOException e) {
                DungeonsAll.LOGGER.error("Failed to load {}", resource);
                e.printStackTrace();
            }
        });
        if (primary.entries.isEmpty()) {
            throw new DatapackLoadException("No primary themes were present after loading " + directory);
        } else if (secondary.entries.isEmpty()) {
            throw new DatapackLoadException("No secondary themes were present after loading " + directory);
        } else {
            return new Pair<>(primary.build(), secondary.build());
        }
    }

    public static Theme getBuiltinDefaultTheme() {
        return (Theme)KEY_TO_THEME.getOrDefault(PRIMARY_THEME_FALLBACK, BUILTIN_DEFAULT_THEME);
    }

    public static SecondaryTheme getBuiltinDefaultSecondaryTheme() {
        return (SecondaryTheme)KEY_TO_SECONDARY_THEME.getOrDefault(SECONDARY_THEME_FALLBACK, BUILTIN_DEFAULT_SECONDARY_THEME);
    }

    public static Theme randomTheme(String biome, RandomSource rand) {
        return (Theme)((IRandom)BIOME_TO_THEME.getOrDefault(biome, DEFAULT_TOP_THEME)).roll(rand);
    }

    public static SecondaryTheme randomSecondaryTheme(String biome, RandomSource rand) {
        return (SecondaryTheme)((IRandom)BIOME_TO_SECONDARY_THEME.getOrDefault(biome, DEFAULT_SECONDARY_TOP_THEME)).roll(rand);
    }

    public static Theme randomCatacombsTheme(RandomSource rand) {
        return CATACOMBS_THEME.roll(rand);
    }

    public static SecondaryTheme randomCatacombsSecondaryTheme(RandomSource rand) {
        return CATACOMBS_SECONDARY_THEME.roll(rand);
    }

    public static Theme randomLowerCatacombsTheme(RandomSource rand) {
        return LOWER_CATACOMBS_THEME.roll(rand);
    }

    public static SecondaryTheme randomLowerCatacombsSecondaryTheme(RandomSource rand) {
        return LOWER_CATACOMBS_SECONDARY_THEME.roll(rand);
    }

    public static Theme randomHellTheme(RandomSource rand) {
        return HELL_THEME.roll(rand);
    }

    public static SecondaryTheme randomHellSecondaryTheme(RandomSource rand) {
        return HELL_SECONDARY_THEME.roll(rand);
    }

    public static Theme getTheme(Identifier key) {
        return (Theme)KEY_TO_THEME.getOrDefault(key, (Theme)KEY_TO_THEME.getOrDefault(PRIMARY_THEME_FALLBACK, BUILTIN_DEFAULT_THEME));
    }

    public static SecondaryTheme getSecondaryTheme(Identifier key) {
        return (SecondaryTheme)KEY_TO_SECONDARY_THEME.getOrDefault(
            key, (SecondaryTheme)KEY_TO_SECONDARY_THEME.getOrDefault(SECONDARY_THEME_FALLBACK, BUILTIN_DEFAULT_SECONDARY_THEME)
        );
    }

    public static Theme getThemeByID(int theme) {
        return (Theme)ID_TO_THEME.getOrDefault(theme, (Theme)ID_TO_THEME.getOrDefault(0, BUILTIN_DEFAULT_THEME));
    }

    public static SecondaryTheme getSecondaryThemeByID(int id) {
        return (SecondaryTheme)ID_TO_SECONDARY_THEME.getOrDefault(id, (SecondaryTheme)ID_TO_SECONDARY_THEME.getOrDefault(0, BUILTIN_DEFAULT_SECONDARY_THEME));
    }

    public static ImmutableSet<Identifier> getThemeKeys() {
        return THEME_KEYS;
    }

    public static ImmutableSet<Identifier> getSecondaryThemeKeys() {
        return SECONDARY_THEME_KEYS;
    }

    public static Theme.Builder builder() {
        return new Theme.Builder();
    }

    static {
        BUILTIN_DEFAULT_THEME.key = Identifier.parse("builtin:default");
        BUILTIN_DEFAULT_SECONDARY_THEME.key = Identifier.parse("builtin:default");
        KEY_TO_THEME.put(BUILTIN_DEFAULT_THEME.getKey(), BUILTIN_DEFAULT_THEME);
        KEY_TO_SECONDARY_THEME.put(BUILTIN_DEFAULT_SECONDARY_THEME.getKey(), BUILTIN_DEFAULT_SECONDARY_THEME);
    }

    public static class Builder {
        private BlockStateProvider pillar = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider solid = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider generic = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider floor = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider solidStairs = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider stairs = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider material = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider wall = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider slab = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider solidSlab = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider fencing = new SingleBlock(Blocks.AIR.defaultBlockState());
        private BlockStateProvider fluid = new SingleBlock(Blocks.AIR.defaultBlockState());
        private Integer id;
        private List<DungeonDecoration> decorations = new ArrayList();
        private IRandom<SecondaryTheme> secondaryTheme;

        public Theme.Builder legacyId(int id) {
            this.id = id;
            return this;
        }

        public Theme.Builder addDecoration(DungeonDecoration decoration) {
            this.decorations.add(decoration);
            return this;
        }

        public Theme.Builder secondaryTheme(IRandom<SecondaryTheme> secondaryTheme) {
            this.secondaryTheme = secondaryTheme;
            return this;
        }

        public Theme.Builder pillar(BlockStateProvider pillar) {
            this.pillar = pillar;
            return this;
        }

        public Theme.Builder solid(BlockStateProvider solid) {
            this.solid = solid;
            return this;
        }

        public Theme.Builder generic(BlockStateProvider generic) {
            this.generic = generic;
            return this;
        }

        public Theme.Builder floor(BlockStateProvider floor) {
            this.floor = floor;
            return this;
        }

        public Theme.Builder solidStairs(BlockStateProvider solidStairs) {
            this.solidStairs = solidStairs;
            return this;
        }

        public Theme.Builder stairs(BlockStateProvider stairs) {
            this.stairs = stairs;
            return this;
        }

        public Theme.Builder material(BlockStateProvider material) {
            this.material = material;
            return this;
        }

        public Theme.Builder wall(BlockStateProvider wall) {
            this.wall = wall;
            return this;
        }

        public Theme.Builder slab(BlockStateProvider slab) {
            this.slab = slab;
            return this;
        }

        public Theme.Builder solidSlab(BlockStateProvider solidSlab) {
            this.solidSlab = solidSlab;
            return this;
        }

        public Theme.Builder fencing(BlockStateProvider fencing) {
            this.fencing = fencing;
            return this;
        }

        public Theme.Builder fluid(BlockStateProvider fluid) {
            this.fluid = fluid;
            return this;
        }

        public Theme build() {
            Theme theme = new Theme(
                this.pillar,
                this.solid,
                this.generic,
                this.floor,
                this.solidStairs,
                this.stairs,
                this.material,
                this.wall,
                this.slab,
                this.solidSlab,
                this.fencing,
                this.fluid
            );
            if (this.id != null) {
                theme.id = this.id;
                Theme.ID_TO_THEME.put(this.id, theme);
            }

            if (!this.decorations.isEmpty()) {
                theme.decorations = (DungeonDecoration[])this.decorations.toArray(new DungeonDecoration[0]);
            }

            return theme;
        }
    }
}
