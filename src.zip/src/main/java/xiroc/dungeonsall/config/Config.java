package xiroc.dungeonsall.config;

import net.neoforged.neoforge.common.ModConfigSpec;
import net.neoforged.neoforge.common.ModConfigSpec.BooleanValue;
import net.neoforged.neoforge.common.ModConfigSpec.Builder;
import net.neoforged.neoforge.common.ModConfigSpec.IntValue;

public class Config {
    private static final Builder BUILDER = new Builder();
    public static final ModConfigSpec CONFIG = BUILDER.build();
    public static final IntValue SPAWNER_ENTITIES = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n The number of different entities per spawner. Increasing the number increases the diversity of the monster equipment.\n"
        )
        .defineInRange("spawner_entities", 6, 1, 128);
    public static final IntValue SPAWNER_RANGE = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n The activation range for the spawners in the dungeons.\n"
        )
        .defineInRange("spawner_activation_range", 12, 1, 64);
    public static final BooleanValue CUSTOM_SPAWNERS = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether custom mob spawners with equipment, etc.. should be used.\n"
        )
        .define("custom_spawners", true);
    public static final BooleanValue NO_NETHER_STUFF = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether the hell stage should be built with blocks from the overworld instead from the nether.\n"
        )
        .define("no_nether_blocks", false);
    public static final BooleanValue SOLID = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n When enabled, the dungeons will ignore caves instead of trying to adjust to them (by not generating specific blocks).\n"
        )
        .define("solid", false);
    public static final BooleanValue NATURAL_DESPAWN = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether mobs from spawners should despawn naturally or not.\n"
        )
        .define("natural_despawn", true);
    public static final BooleanValue EXTENDED_DEBUG = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Enables extended debug logging to help detecting errors. Enabled by default.\n"
        )
        .define("extended_debug", false);
    public static final BooleanValue TICK_FALLING_BLOCKS = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether falling blocks like sand or gravel should drop down after being placed during dungeon generation.\n"
        )
        .define("tick_falling_blocks", true);
    public static final BooleanValue OVERWRITE_ENTITY_LOOT_TABLES = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether loot tables of certain spawner entities should be overwritten.\n For example, wither skeletons from dungeon spawners will never drop skulls if this is enabled.\n"
        )
        .define("overwrite_entity_loot_tables", true);
    public static final BooleanValue SECRET_ROOMS = BUILDER.comment(
            "----------------------------------------------------------------------------------------------------+\n Whether the dungeons should have secret rooms or not.\n"
        )
        .define("secret_rooms", true);
    private static final String SEPARATOR_LINE = "----------------------------------------------------------------------------------------------------+\n";

    static {
        BUILDER.push("Miscellaneous Settings");
        BUILDER.pop();
        BUILDER.push("World Generation");
        BUILDER.pop();
        BUILDER.push("Dungeon Settings");
        BUILDER.pop();
    }
}
