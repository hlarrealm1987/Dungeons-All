package xiroc.dungeonsall.init;

import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.biome.Biome;
import xiroc.dungeonsall.DungeonsAll;

public class ModTags {
    public static final TagKey<Biome> HAS_DUNGEON = create("has_structure/dungeon");

    private static TagKey<Biome> create(String path) {
        return TagKey.create(Registries.BIOME, DungeonsAll.locate(path));
    }
}
