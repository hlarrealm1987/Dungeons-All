package xiroc.dungeonsall.init;

import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePieceType.ContextlessType;
import net.neoforged.neoforge.registries.DeferredHolder;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.piece.DungeonCorridor;
import xiroc.dungeonsall.dungeon.piece.DungeonEntrance;
import xiroc.dungeonsall.dungeon.piece.DungeonMultipartModelPiece;
import xiroc.dungeonsall.dungeon.piece.DungeonNodeConnector;
import xiroc.dungeonsall.dungeon.piece.DungeonStairs;
import xiroc.dungeonsall.dungeon.piece.room.DungeonMegaNodePart;
import xiroc.dungeonsall.dungeon.piece.room.DungeonNodeRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSecretRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSideRoom;
import xiroc.dungeonsall.dungeon.piece.room.DungeonSpiderRoom;

public interface ModStructurePieceTypes {
    DeferredHolder<StructurePieceType, ?> ENTRANCE = DungeonsAll.STRUCTURE_PIECE_TYPE.register("entrance", () -> noContext(DungeonEntrance::new));
    DeferredHolder<StructurePieceType, ?> ROOM = DungeonsAll.STRUCTURE_PIECE_TYPE.register("room", () -> noContext(DungeonRoom::new));
    DeferredHolder<StructurePieceType, ?> CORRIDOR = DungeonsAll.STRUCTURE_PIECE_TYPE.register("corridor", () -> noContext(DungeonCorridor::new));
    DeferredHolder<StructurePieceType, ?> STAIRS = DungeonsAll.STRUCTURE_PIECE_TYPE.register("stairs", () -> noContext(DungeonStairs::new));
    DeferredHolder<StructurePieceType, ?> SIDE_ROOM = DungeonsAll.STRUCTURE_PIECE_TYPE.register("side_room", () -> noContext(DungeonSideRoom::new));
    DeferredHolder<StructurePieceType, ?> NODE_ROOM = DungeonsAll.STRUCTURE_PIECE_TYPE.register("node_room", () -> noContext(DungeonNodeRoom::new));
    DeferredHolder<StructurePieceType, ?> NODE_CONNECTOR = DungeonsAll.STRUCTURE_PIECE_TYPE
        .register("node_connector", () -> noContext(DungeonNodeConnector::new));
    DeferredHolder<StructurePieceType, ?> SECRET_ROOM = DungeonsAll.STRUCTURE_PIECE_TYPE.register("secret_room", () -> noContext(DungeonSecretRoom::new));
    DeferredHolder<StructurePieceType, ?> SPIDER_ROOM = DungeonsAll.STRUCTURE_PIECE_TYPE.register("spider_room", () -> noContext(DungeonSpiderRoom::new));
    DeferredHolder<StructurePieceType, ?> MULTIPART_MODEL_PIECE = DungeonsAll.STRUCTURE_PIECE_TYPE
        .register("multipart_model_piece", () -> noContext(DungeonMultipartModelPiece::new));
    DeferredHolder<StructurePieceType, ?> MEGA_NODE_PART = DungeonsAll.STRUCTURE_PIECE_TYPE
        .register("mega_node_part", () -> noContext(DungeonMegaNodePart::new));

    private static StructurePieceType noContext(ContextlessType type) {
        return type;
    }

    static void init() {
    }
}
