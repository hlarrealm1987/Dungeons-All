package xiroc.dungeonsall.init;

import net.minecraft.world.level.levelgen.structure.StructureType;
import net.neoforged.neoforge.registries.DeferredHolder;
import xiroc.dungeonsall.DungeonsAll;
import xiroc.dungeonsall.dungeon.Dungeon;

public class ModStructureTypes {
    private static final DeferredHolder<StructureType<?>, ?> DUNGEON = DungeonsAll.STRUCTURE_TYPE.register("dungeon", () -> () -> Dungeon.CODEC);

    public static void init() {
    }

    public static StructureType<?> dungeon() {
        return (StructureType<?>)DUNGEON.get();
    }
}
